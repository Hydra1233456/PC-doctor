@echo off
title PC Doctor Pro - Repair Tool
cd /d "%~dp0"
python pc_doctor_fixer.py
echo.
pause
