"""PC Doctor Pro - interfaccia grafica Tkinter."""
