"""PC Doctor Pro - tema grafico scuro."""
import tkinter.font as tkfont

# Palette
BG = "#0b0e14"          # sfondo principale
BG_SIDEBAR = "#0e1320"  # barra laterale
CARD = "#141a26"        # sfondo card
CARD_HOVER = "#1a2233"
BORDER = "#232c40"      # bordi
TEXT = "#e6ebf4"        # testo principale
TEXT_DIM = "#8b95a9"    # testo secondario
ACCENT = "#34d399"      # verde principale
ACCENT_DARK = "#10b981"
ACCENT_BG = "#0d2b22"   # sfondo pulsante accento
WARN = "#fbbf24"
DANGER = "#f87171"
ORANGE = "#fb923c"

FONT_FAMILY = None  # deciso a runtime


def setup_fonts(root):
    global FONT_FAMILY
    families = set(tkfont.families(root))
    for f in ("Segoe UI", "DejaVu Sans", "Helvetica", "Arial"):
        if f in families:
            FONT_FAMILY = f
            break
    FONT_FAMILY = FONT_FAMILY or tkfont.nametofont("TkDefaultFont").actual("family")


def F(size, bold=False, semibold=False):
    # Tk supporta solo i pesi "normal" e "bold"
    weight = "bold" if bold else "normal"
    return (FONT_FAMILY or "TkDefaultFont", size, weight)


def configure_ttk(root):
    """Applica il tema scuro ai widget ttk (progressbar, treeview, scroll)."""
    import tkinter.ttk as ttk
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except Exception:
        pass

    style.configure("Accent.Horizontal.TProgressbar",
                    troughcolor=CARD, background=ACCENT,
                    bordercolor=CARD, lightcolor=ACCENT, darkcolor=ACCENT_DARK,
                    thickness=10)
    style.configure("Warn.Horizontal.TProgressbar",
                    troughcolor=CARD, background=WARN,
                    bordercolor=CARD, lightcolor=WARN, darkcolor=ORANGE,
                    thickness=10)

    style.configure("PDoctor.Treeview",
                    background=CARD, fieldbackground=CARD, foreground=TEXT,
                    bordercolor=BORDER, rowheight=30, font=F(10))
    style.configure("PDoctor.Treeview.Heading",
                    background=BG_SIDEBAR, foreground=ACCENT,
                    font=F(10, bold=True), bordercolor=BORDER, relief="flat")
    style.map("PDoctor.Treeview",
              background=[("selected", ACCENT_BG)],
              foreground=[("selected", ACCENT)])
    style.map("PDoctor.Treeview.Heading", background=[("active", CARD_HOVER)])

    style.configure("PDoctor.Vertical.TScrollbar",
                    background=CARD, troughcolor=BG, bordercolor=BG,
                    arrowcolor=TEXT_DIM)
    style.map("PDoctor.Vertical.TScrollbar", background=[("active", CARD_HOVER)])

    style.configure("PDoctor.Horizontal.TScrollbar",
                    background=CARD, troughcolor=BG, bordercolor=BG,
                    arrowcolor=TEXT_DIM)
