"""PC Doctor Pro - main window and application pages (English edition)."""
import os
import platform
import subprocess
import sys
import threading
import webbrowser
import tkinter as tk
from tkinter import ttk, messagebox

import psutil

from core import system_info, gpu as gpu_mod, drivers as drv_mod
from core import maintenance as maint_mod, benchmark as bench_mod
from core import admin as admin_mod, report as report_mod
from core import tuning as tun_mod
from core.utils import (APP_NAME, APP_VERSION, app_dir, gb, IS_WINDOWS,
                        install_crash_guard, safe_open_folder)

from . import theme as T
from .widgets import (
    ScrollFrame, Card, kv_row, metric_bar, make_button, ImageBox, section_title,
    LineChart,
)
from .page_specs import SpecsPageMixin

PAGES = [
    ("dashboard", "\U0001F3E0  Dashboard"),
    ("gpu", "\U0001F3AE  Graphics Card"),
    ("specs", "\U0001F4CA  Tech Specs"),
    ("tuning", "\U0001F39A  Overclock & UV"),
    ("drivers", "\U0001F9F0  Drivers"),
    ("maintenance", "\U0001F9F9  Maintenance"),
    ("benchmark", "\u26A1  Benchmark"),
    ("report", "\U0001F4C4  Report"),
    ("about", "\u2139\ufe0f  Info & System"),
]


class PCDoctorApp(SpecsPageMixin):
    def __init__(self, root):
        self.root = root
        self.root.title(f"{APP_NAME} v{APP_VERSION} - PC analysis & maintenance")
        self.root.geometry("1180x780")
        self.root.minsize(1000, 660)
        self.root.configure(bg=T.BG)

        self.data = {
            "system": None, "gpus": [], "drivers": None,
            "bench": {}, "maint": {}, "logos": {},
        }
        self._busy = threading.Semaphore(1)
        self._busy_flag = False
        self._built_pages = set()
        self._page_frames = {}
        self._current_page = None
        self._after_ids = []
        self._tun_monitoring = False

        T.setup_fonts(root)
        T.configure_ttk(root)
        self._set_window_icon()

        self._build_layout()
        self.show_page("dashboard")
        self.after(300, self.run_full_analysis)

    # ------------------------------------------------------------- utils
    def after(self, ms, fn):
        aid = self.root.after(ms, fn)
        self._after_ids.append(aid)
        return aid

    def run_in_thread(self, fn, on_done=None, on_error=None, progress=None):
        """Runs fn in a background thread; callbacks are marshalled to the UI."""
        def worker():
            try:
                result = fn()
                self.root.after(0, lambda: self._safe_call(on_done, result))
            except Exception as e:  # noqa: BLE001
                self.root.after(0, lambda: self._safe_call(on_error, e))
        threading.Thread(target=worker, daemon=True).start()

    def _safe_call(self, fn, *args):
        try:
            if fn:
                fn(*args)
        except Exception as e:  # noqa: BLE001
            self.set_status(f"Internal error: {e}")

    def set_status(self, text):
        self.status_var.set(f" {text}")

    def start_busy(self, msg="Working..."):
        if self._busy_flag:
            return False
        self._busy_flag = True
        self.root.configure(cursor="watch")
        self.set_status("\u23F3 " + msg)
        return True

    def end_busy(self, msg="Ready"):
        self._busy_flag = False
        self.root.configure(cursor="")
        self.set_status(msg)

    def check_busy(self):
        if self._busy_flag:
            messagebox.showinfo(
                APP_NAME, "Another operation is already running.\nPlease wait for it to finish."
            )
            return True
        return False

    def _set_window_icon(self):
        icon = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                            "assets", "icon.png")
        if os.path.exists(icon):
            try:
                from PIL import Image, ImageTk
                img = Image.open(icon).resize((64, 64), Image.LANCZOS)
                self._icon = ImageTk.PhotoImage(img)
                self.root.iconphoto(True, self._icon)
            except Exception:
                pass

    # ------------------------------------------------------------- layout
    def _build_layout(self):
        # Sidebar
        sidebar = tk.Frame(self.root, bg=T.BG_SIDEBAR, width=220)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)

        logo = tk.Frame(sidebar, bg=T.BG_SIDEBAR)
        logo.pack(fill="x", pady=(20, 4), padx=16)
        tk.Label(logo, text="\U0001F916", bg=T.BG_SIDEBAR, font=("Segoe UI Emoji", 26)
                 ).pack(side="left", padx=(0, 8))
        tk.Label(logo, text="PC Doctor", bg=T.BG_SIDEBAR, fg=T.TEXT,
                 font=T.F(17, bold=True)).pack(side="left")
        tk.Label(sidebar, text="PRO  \u00b7  v" + APP_VERSION, bg=T.BG_SIDEBAR,
                 fg=T.ACCENT, font=T.F(9, bold=True)).pack(anchor="w", padx=22)

        self.nav_buttons = {}
        for key, label in PAGES:
            btn = tk.Button(
                sidebar, text="   " + label, anchor="w", bg=T.BG_SIDEBAR,
                fg=T.TEXT_DIM, activebackground=T.CARD_HOVER, activeforeground=T.TEXT,
                font=T.F(11), relief="flat", bd=0, padx=16, pady=10, cursor="hand2",
                command=lambda k=key: self.show_page(k),
            )
            btn.pack(fill="x", pady=1)
            btn.bind("<Enter>", lambda e, b=btn: b.configure(fg=T.TEXT)
                     if not b._selected else None)  # noqa: SLF001
            btn.bind("<Leave>", lambda e, b=btn: b.configure(fg=T.TEXT_DIM)
                     if not b._selected else None)  # noqa: SLF001
            self.nav_buttons[key] = btn

        footer = tk.Frame(sidebar, bg=T.BG_SIDEBAR)
        footer.pack(side="bottom", fill="x", pady=14, padx=16)
        self.admin_lbl = tk.Label(footer, bg=T.BG_SIDEBAR, fg=T.TEXT_DIM,
                                  font=T.F(9), wraplength=170, justify="left")
        self.admin_lbl.pack(anchor="w")
        self._update_admin_label()

        # Main area
        main = tk.Frame(self.root, bg=T.BG)
        main.pack(side="left", fill="both", expand=True)

        # Status bar (packed first so content fills the right space)
        self.status_var = tk.StringVar(value=" Starting...")
        status = tk.Label(main, textvariable=self.status_var, bg=T.BG_SIDEBAR,
                          fg=T.TEXT_DIM, font=T.F(9), anchor="w")
        status.pack(side="bottom", fill="x", ipady=5)

        header = tk.Frame(main, bg=T.BG)
        header.pack(fill="x", padx=28, pady=(20, 0))
        self.page_title = tk.Label(header, text="Dashboard", bg=T.BG, fg=T.TEXT,
                                   font=T.F(20, bold=True))
        self.page_title.pack(side="left")
        self.btn_full = make_button(header, "\u2699  Full analysis",
                                    self.run_full_analysis, kind="accent")
        self.btn_full.pack(side="right")

        self.admin_banner = tk.Frame(main, bg="#33230a")
        self.admin_btn = make_button(self.admin_banner, "Restart as administrator",
                                     self._elevate, kind="warn")
        self.admin_btn.pack(side="right", padx=12, pady=8)
        tk.Label(self.admin_banner,
                 text="\u26A0  Some features (drivers, tuning, maintenance) need administrator rights.",
                 bg="#33230a", fg=T.WARN, font=T.F(10)).pack(side="left", padx=12, pady=8)
        if not (admin_mod.is_admin() or not IS_WINDOWS):
            self.admin_banner.pack(fill="x", padx=28, pady=(10, 0))

        self.content = tk.Frame(main, bg=T.BG)
        self.content.pack(fill="both", expand=True, padx=28)

    def _update_admin_label(self):
        if admin_mod.is_admin():
            self.admin_lbl.configure(
                text="\u2705 Administrator rights active", fg=T.ACCENT)
        elif IS_WINDOWS:
            self.admin_lbl.configure(
                text="User mode: driver/tuning features are limited", fg=T.WARN)
        else:
            self.admin_lbl.configure(
                text="System: " + platform.system(), fg=T.TEXT_DIM)

    def _elevate(self):
        if admin_mod.elevate():
            self.root.destroy()
        else:
            messagebox.showerror(
                APP_NAME,
                "Could not restart with administrator rights.\n"
                "Start the app manually: right-click \u2192 'Run as administrator'.",
            )

    def show_page(self, key):
        self._current_page = key
        for k, b in self.nav_buttons.items():
            if k == key:
                b.configure(bg=T.CARD, fg=T.ACCENT)
                b._selected = True  # noqa: SLF001
            else:
                b.configure(bg=T.BG_SIDEBAR, fg=T.TEXT_DIM)
                b._selected = False  # noqa: SLF001
        title = dict(PAGES).get(key, "")
        self.page_title.configure(text=title.split("  ")[-1])

        for child in self.content.winfo_children():
            child.pack_forget()
        if key not in self._page_frames:
            builder = getattr(self, f"_page_{key}")
            self._page_frames[key] = builder(self.content)
            self._built_pages.add(key)
        self._page_frames[key].pack(fill="both", expand=True)
        if key == "tuning":
            self._tun_refresh()

    # ------------------------------------------------------------- data
    def run_full_analysis(self):
        if not self.start_busy("Full analysis in progress..."):
            return
        self.btn_full.configure(state="disabled", bg=T.CARD, fg=T.TEXT_DIM)

        def work():
            system = system_info.get_full_system_info()
            gpus = gpu_mod.get_gpus()
            return system, gpus

        def done(result):
            system, gpus = result
            self.data["system"] = system
            self.data["gpus"] = gpus
            for g in gpus:
                self.data["logos"][g["vendor"]] = gpu_mod.logo_for_vendor(g["vendor"])
            self.end_busy(f"Analysis complete \u00b7 {system['cpu']['name']}")
            self.btn_full.configure(state="normal", bg=T.ACCENT_BG, fg=T.ACCENT)
            self._refresh_page_data()

        def error(e):
            self.end_busy("Error during analysis")
            self.btn_full.configure(state="normal", bg=T.ACCENT_BG, fg=T.ACCENT)
            messagebox.showerror(APP_NAME, f"Error during analysis:\n{e}")

        self.run_in_thread(work, done, error)

    def _refresh_page_data(self):
        if self._current_page == "dashboard" and self.data["system"]:
            self._fill_dashboard(self.data["system"], self.data["gpus"])
        elif self._current_page == "gpu" and self.data["gpus"]:
            self._fill_gpu_cards()
        elif self._current_page == "about" and self.data["system"]:
            self._fill_about()

    # =========================================================== DASHBOARD
    def _page_dashboard(self, parent):
        frame = ScrollFrame(parent)
        self.dash_body = tk.Frame(frame.inner, bg=T.BG)
        self.dash_body.pack(fill="both", expand=True)
        if self.data["system"]:
            self._fill_dashboard(self.data["system"], self.data["gpus"])
        else:
            tk.Label(self.dash_body, text="\n\u23F3 First analysis running...",
                     bg=T.BG, fg=T.TEXT_DIM, font=T.F(13)).pack(pady=60)
        self.after(2500, self._live_update)
        return frame

    def _fill_dashboard(self, s, gpus):
        for w in self.dash_body.winfo_children():
            w.destroy()
        cpu, ram, os_i = s["cpu"], s["ram"], s["os"]
        board, bios, net = s.get("board", {}), s.get("bios", {}), s.get("network", {})

        # Row 1: CPU + RAM
        r1 = tk.Frame(self.dash_body, bg=T.BG)
        r1.pack(fill="x")
        c_cpu = Card(r1, "Processor", "\u2699")
        c_cpu.pack(side="left", fill="both", expand=True, padx=(0, 8))
        kv_row(c_cpu.body, "Model", cpu.get("name", "N/A"))
        kv_row(c_cpu.body, "Cores", f"{cpu.get('cores_physical', '?')} physical \u00b7 "
                                   f"{cpu.get('cores_logical', '?')} logical")
        kv_row(c_cpu.body, "Clock", f"{cpu.get('current_ghz', 'N/A')} GHz"
               + (f" (max {cpu.get('max_ghz')} GHz)" if cpu.get('max_ghz') else ""))
        var, txt = metric_bar(c_cpu.body, "CPU usage")
        self.dash_cpu_var, self.dash_cpu_txt = var, txt
        if cpu.get("per_core"):
            pc = tk.Frame(c_cpu.body, bg=T.CARD)
            pc.pack(fill="x", pady=(6, 0))
            cols = 8
            for i, v in enumerate(cpu["per_core"][:16]):
                cell = tk.Frame(pc, bg=T.CARD)
                cell.grid(row=0, column=i % cols, padx=2, sticky="ew")
                pc.columnconfigure(i % cols, weight=1)
                b = ttk.Progressbar(cell, value=v, maximum=100, length=60,
                                    style="Accent.Horizontal.TProgressbar")
                b.pack()
                tk.Label(cell, text=f"C{i}", bg=T.CARD, fg=T.TEXT_DIM,
                         font=T.F(7)).pack()

        c_ram = Card(r1, "Memory (RAM)", "\U0001F4BF")
        c_ram.pack(side="left", fill="both", expand=True, padx=(8, 0))
        kv_row(c_ram.body, "Total", f"{ram.get('total_gb', 'N/A')} GB")
        kv_row(c_ram.body, "Used", f"{ram.get('used_gb', 'N/A')} GB")
        kv_row(c_ram.body, "Available", f"{ram.get('available_gb', 'N/A')} GB")
        if ram.get("speeds"):
            kv_row(c_ram.body, "Modules", f"{ram.get('modules', '?')} \u00b7 {ram.get('speeds')}")
        if ram.get("slots_total"):
            kv_row(c_ram.body, "Total slots", ram.get("slots_total"))
        var, txt = metric_bar(c_ram.body, "RAM usage")
        var.set(ram.get("percent", 0))
        txt.set(f"{ram.get('percent', 0):.0f}%")

        # Row 2: GPU + OS
        r2 = tk.Frame(self.dash_body, bg=T.BG)
        r2.pack(fill="x", pady=10)
        c_gpu = Card(r2, "Graphics Card", "\U0001F3AE")
        c_gpu.pack(side="left", fill="both", expand=True, padx=(0, 8))
        if gpus:
            for g in gpus[:2]:
                kv_row(c_gpu.body, g["vendor"], g["name"], wrap=260)
                drv = f"{g.get('driver_version', 'N/A')}"
                if g.get("nvidia_live"):
                    nv = g["nvidia_live"]
                    drv += f" \u00b7 {nv.get('temp_c', '?')} \u00b0C"
                kv_row(c_gpu.body, "Driver", drv, wrap=260)
        else:
            kv_row(c_gpu.body, "GPU", "No card detected")
        make_button(c_gpu.body, "\u2192  GPU details", lambda: self.show_page("gpu"))

        c_os = Card(r2, "Operating System", "\U0001F4BB")
        c_os.pack(side="left", fill="both", expand=True, padx=(8, 0))
        kv_row(c_os.body, "System", f"{os_i.get('edition', 'N/A')}")
        kv_row(c_os.body, "Architecture", os_i.get("arch", "N/A"))
        kv_row(c_os.body, "Hostname", os_i.get("hostname", "N/A"))
        kv_row(c_os.body, "Last boot", os_i.get("boot_time", "N/A"))
        kv_row(c_os.body, "Uptime", f"{os_i.get('uptime_hours', 'N/A')} h")

        # Row 3: disks + motherboard/network
        r3 = tk.Frame(self.dash_body, bg=T.BG)
        r3.pack(fill="x")
        c_disk = Card(r3, "Disks", "\U0001F4BE")
        c_disk.pack(side="left", fill="both", expand=True, padx=(0, 8))
        for d in s.get("disks", [])[:4]:
            var, txt = metric_bar(c_disk.body, f"{d['device']}  ({d['total_gb']} GB)")
            var.set(d["percent"])
            txt.set(f"{d['percent']:.0f}%")
            kv_row(c_disk.body, "Free", f"{d['free_gb']} GB")

        c_mb = Card(r3, "Motherboard & Network", "\U0001F50C")
        c_mb.pack(side="left", fill="both", expand=True, padx=(8, 0))
        kv_row(c_mb.body, "Motherboard", f"{board.get('manufacturer', 'N/A')} "
                                        f"{board.get('product', '')}".strip())
        kv_row(c_mb.body, "BIOS", f"{bios.get('vendor', 'N/A')} "
                                  f"{bios.get('version', '')}".strip())
        kv_row(c_mb.body, "Public IP", net.get("public_ip") or "N/A")
        bat = s.get("battery")
        if bat:
            kv_row(c_mb.body, "Battery", f"{bat['percent']}% "
                    + ("(charging)" if bat["plugged"] else f"({bat['time_left']})"))

    def _live_update(self):
        try:
            if (self._current_page == "dashboard" and self.data.get("system")
                    and hasattr(self, "dash_cpu_var")):
                cpu = psutil.cpu_percent(interval=None)
                self.dash_cpu_var.set(cpu)
                self.dash_cpu_txt.set(f"{cpu:.0f}%")
        except Exception:
            pass
        self._after_ids.clear()
        self.after(2500, self._live_update)

    # =========================================================== GPU
    def _page_gpu(self, parent):
        frame = ScrollFrame(parent)
        self.gpu_body = tk.Frame(frame.inner, bg=T.BG)
        self.gpu_body.pack(fill="both", expand=True)
        top = tk.Frame(self.gpu_body, bg=T.BG)
        top.pack(fill="x", pady=(0, 8))
        make_button(top, "\U0001F504  Detect again", self._reload_gpus)
        if self.data["gpus"]:
            self._fill_gpu_cards()
        else:
            tk.Label(self.gpu_body, text="\n\u23F3 Detecting GPUs...",
                     bg=T.BG, fg=T.TEXT_DIM, font=T.F(13)).pack(pady=60)
        return frame

    def _reload_gpus(self):
        if self.check_busy():
            return
        self.start_busy("Detecting GPUs...")

        def work():
            gpus = gpu_mod.get_gpus()
            logos = {g["vendor"]: gpu_mod.logo_for_vendor(g["vendor"]) for g in gpus}
            return gpus, logos

        def done(res):
            gpus, logos = res
            self.data["gpus"] = gpus
            self.data["logos"].update(logos)
            self.end_busy("GPU list updated")
            self._fill_gpu_cards()

        def error(e):
            self.end_busy("GPU detection failed")
            messagebox.showerror(APP_NAME, str(e))

        self.run_in_thread(work, done, error)

    def _fill_gpu_cards(self):
        for w in self.gpu_body.winfo_children():
            if w.winfo_name() != "!frame":
                w.destroy()
        gpus = self.data["gpus"]
        if not gpus:
            tk.Label(self.gpu_body, text="\nNo graphics card detected.",
                     bg=T.BG, fg=T.TEXT_DIM, font=T.F(13)).pack(pady=60)
            return
        for g in gpus:
            self._gpu_card(g)
        hint = tk.Label(
            self.gpu_body,
            text="\u2139  Brand images shown are generated; the official logo is downloaded "
                 "when available (internet connection required).",
            bg=T.BG, fg=T.TEXT_DIM, font=T.F(9), wraplength=900, justify="left")
        hint.pack(anchor="w", pady=(10, 4))

    def _gpu_card(self, g):
        card = Card(self.gpu_body, None, padding=0)
        card.pack(fill="x", pady=(0, 14))
        art_box = ImageBox(card, g.get("art"), width=880, height=180,
                           fallback_text=f"{g['vendor']}  \u00b7  {g['name']}",
                           fallback_color=g.get("brand_color", T.ACCENT))
        art_box.pack(fill="x")

        inner = tk.Frame(card, bg=T.CARD)
        inner.pack(fill="x", padx=16, pady=(0, 16))

        head = tk.Frame(inner, bg=T.CARD)
        head.pack(fill="x", pady=(10, 6))
        tk.Label(head, text=g["name"], bg=T.CARD, fg=T.TEXT,
                 font=T.F(15, bold=True)).pack(side="left")
        vendor_badge = tk.Label(head, text=f"  {g['vendor']}  ", bg=g.get("brand_color", T.ACCENT),
                                fg="#0b0e14", font=T.F(10, bold=True))
        vendor_badge.pack(side="right")
        logo_path = self.data["logos"].get(g["vendor"])
        if logo_path and os.path.exists(logo_path):
            try:
                from PIL import Image, ImageTk
                img = Image.open(logo_path)
                img.thumbnail((110, 36), Image.LANCZOS)
                photo = ImageTk.PhotoImage(img)
                self.data.setdefault("_photos", []).append(photo)
                tk.Label(head, image=photo, bg=T.CARD).pack(side="right", padx=10)
            except Exception:
                pass

        cols = tk.Frame(inner, bg=T.CARD)
        cols.pack(fill="x")
        left = tk.Frame(cols, bg=T.CARD)
        left.pack(side="left", fill="both", expand=True)
        right = tk.Frame(cols, bg=T.CARD)
        right.pack(side="left", fill="both", expand=True)

        kv_row(left, "Brand", g["vendor"], bg=T.CARD)
        kv_row(left, "VRAM", gpu_mod.vram_label(g.get("vram_mb")), bg=T.CARD)
        kv_row(left, "Status", g.get("status", "N/A"), bg=T.CARD)
        kv_row(left, "Resolution", g.get("resolution") or "N/A", bg=T.CARD)
        age = g.get("driver_age_years")
        date_lbl = g.get("driver_date") or "N/A"
        if age is not None and age > 3:
            date_lbl += f"  ({age} years \u26A0)"
        kv_row(right, "Driver version", g.get("driver_version", "N/A"), bg=T.CARD)
        kv_row(right, "Driver date", date_lbl, bg=T.CARD,
               val_fg=(T.WARN if (age is not None and age > 3) else T.TEXT))

        nv = g.get("nvidia_live")
        if nv:
            lrow = tk.Frame(cols, bg=T.CARD)
            lrow.pack(fill="x", pady=(8, 0))
            v1, t1 = metric_bar(lrow, "GPU temperature (\u00b0C)", color="Warn")
            v1.set(min(nv.get("temp_c") or 0, 100))
            t1.set(f"{nv.get('temp_c', '?')} \u00b0C")
            v2, t2 = metric_bar(lrow, "GPU usage")
            v2.set(nv.get("util_percent") or 0)
            t2.set(f"{nv.get('util_percent', 0):.0f}%")
            if nv.get("fan_percent") is not None:
                v3, t3 = metric_bar(lrow, "Fan")
                v3.set(nv.get("fan_percent") or 0)
                t3.set(f"{nv.get('fan_percent', 0):.0f}%")
            if nv.get("power_w") is not None:
                kv_row(lrow, "Power draw", f"{nv.get('power_w')} W", bg=T.CARD)

        btns = tk.Frame(inner, bg=T.CARD)
        btns.pack(fill="x", pady=(12, 0))
        if g.get("driver_page"):
            make_button(btns, "\U0001F310  Download official drivers",
                        lambda u=g["driver_page"]: webbrowser.open(u), kind="accent"
                        ).pack(side="left", padx=(0, 8))
        if g.get("assistant_winget"):
            make_button(btns, "\u2B07  Install GPU companion app",
                        lambda wids=g["assistant_winget"]: self._install_gpu_app(wids)
                        ).pack(side="left", padx=(0, 8))
        make_button(btns, "\U0001F39A  Overclock / Undervolt", self._goto_tuning,
                    kind="ghost")
        btns_last = btns.winfo_children()[-1]
        btns_last.pack(side="left", padx=(0, 8))
        make_button(btns, "\U0001F9F0  Device manager", self._open_devmgr)

    def _goto_tuning(self):
        self.show_page("tuning")

    def _install_gpu_app(self, winget_ids):
        if self.check_busy():
            return
        if not messagebox.askyesno(
            APP_NAME,
            "The official companion software for your GPU will be installed\n"
            "(NVIDIA App / AMD Adrenalin / Intel tools) via winget.\n\n"
            "Continue? (requires winget and an internet connection)",
        ):
            return
        self.start_busy("Installing GPU software via winget...")

        def work():
            from core.utils import run_cmd
            for wid in winget_ids:
                rc, out, err = run_cmd(
                    ["winget", "install", "--id", wid, "-e", "--silent",
                     "--accept-source-agreements", "--accept-package-agreements"],
                    timeout=1800,
                )
                if rc == 0:
                    return True, f"Successfully installed: {wid}"
            return False, ("winget is not available or the package was not found.\n"
                           "Download it manually from your GPU vendor's website.")

        def done(res):
            ok, msg = res
            self.end_busy("Installation finished")
            (messagebox.showinfo if ok else messagebox.showwarning)(APP_NAME, msg)

        def error(e):
            self.end_busy("Installation error")
            messagebox.showerror(APP_NAME, str(e))

        self.run_in_thread(work, done, error)

    def _open_devmgr(self):
        ok, err = drv_mod.open_device_manager()
        if not ok:
            messagebox.showwarning(APP_NAME, f"Could not open Device Manager:\n{err}")

    # =========================================================== TUNING
    def _page_tuning(self, parent):
        frame = ScrollFrame(parent)
        body = frame.inner

        warn = tk.Label(
            body,
            text="\u26A0  Overclocking/undervolting changes how your hardware runs. "
                 "Always test stability afterwards (run the Benchmark page) and keep temps "
                 "under control. Laptop GPUs often lock these options.",
            bg="#33230a", fg=T.WARN, font=T.F(10), wraplength=860, justify="left")
        warn.pack(fill="x", ipady=8, padx=2, pady=(0, 12))

        # ---- GPU live status + charts
        c_live = Card(body, "GPU live status", "\U0001F3AE")
        c_live.pack(fill="x", pady=(0, 12))
        head = tk.Frame(c_live.body, bg=T.CARD)
        head.pack(fill="x")
        self.tun_name_lbl = tk.Label(head, text="No NVIDIA GPU detected via nvidia-smi",
                                     bg=T.CARD, fg=T.TEXT, font=T.F(13, bold=True))
        self.tun_name_lbl.pack(side="left")
        make_button(head, "\U0001F504  Refresh", self._tun_refresh).pack(side="right")

        self.tun_kv = tk.Frame(c_live.body, bg=T.CARD)
        self.tun_kv.pack(fill="x", pady=(6, 0))
        charts = tk.Frame(c_live.body, bg=T.CARD)
        charts.pack(fill="x", pady=(8, 0))
        self.tun_temp_chart = LineChart(charts, "Temperature", color=T.WARN,
                                        unit="\u00b0C", max_val=100, height=130)
        self.tun_temp_chart.pack(side="left", fill="both", expand=True, padx=(0, 8))
        self.tun_clock_chart = LineChart(charts, "Core clock", color=T.ACCENT,
                                         unit="MHz", height=130)
        self.tun_clock_chart.pack(side="left", fill="both", expand=True)

        # ---- Manual mode
        c_man = Card(body, "Manual mode (advanced users)", "\U0001F527")
        c_man.pack(fill="x", pady=(0, 12))
        tk.Label(c_man.body, text="Set the values below and press Apply. "
                                  "Set a clock to 0 to leave it unlocked/default.",
                 bg=T.CARD, fg=T.TEXT_DIM, font=T.F(10)).pack(anchor="w")
        srow = tk.Frame(c_man.body, bg=T.CARD)
        srow.pack(fill="x", pady=(8, 0))

        # sliders column
        self.tun_pl_var = tk.IntVar(value=0)
        self.tun_core_var = tk.IntVar(value=0)
        self.tun_mem_var = tk.IntVar(value=0)
        self.tun_pl_lbl = tk.Label(c_man.body, text="Power limit: N/A", bg=T.CARD,
                                   fg=T.TEXT, font=T.F(10, bold=True))
        self.tun_pl_lbl.pack(anchor="w")
        self.tun_pl_scale = tk.Scale(c_man.body, from_=0, to=400, orient="horizontal",
                                     variable=self.tun_pl_var, bg=T.CARD, fg=T.TEXT_DIM,
                                     troughcolor=T.BG_SIDEBAR, highlightthickness=0, bd=0,
                                     activebackground=T.ACCENT, length=520, resolution=1,
                                     command=lambda _v: self._tun_slider_labels())
        self.tun_pl_scale.pack(fill="x")
        self.tun_core_lbl = tk.Label(c_man.body, text="Core clock lock (MHz, 0 = default)",
                                     bg=T.CARD, fg=T.TEXT, font=T.F(10, bold=True))
        self.tun_core_lbl.pack(anchor="w", pady=(6, 0))
        self.tun_core_scale = tk.Scale(c_man.body, from_=0, to=2500, orient="horizontal",
                                       variable=self.tun_core_var, bg=T.CARD, fg=T.TEXT_DIM,
                                       troughcolor=T.BG_SIDEBAR, highlightthickness=0, bd=0,
                                       activebackground=T.ACCENT, length=520, resolution=15,
                                       command=lambda _v: self._tun_slider_labels())
        self.tun_core_scale.pack(fill="x")
        self.tun_mem_lbl = tk.Label(c_man.body, text="Memory clock lock (MHz, 0 = default)",
                                    bg=T.CARD, fg=T.TEXT, font=T.F(10, bold=True))
        self.tun_mem_lbl.pack(anchor="w", pady=(6, 0))
        self.tun_mem_scale = tk.Scale(c_man.body, from_=0, to=12000, orient="horizontal",
                                      variable=self.tun_mem_var, bg=T.CARD, fg=T.TEXT_DIM,
                                      troughcolor=T.BG_SIDEBAR, highlightthickness=0, bd=0,
                                      activebackground=T.ACCENT, length=520, resolution=50,
                                      command=lambda _v: self._tun_slider_labels())
        self.tun_mem_scale.pack(fill="x")

        brow = tk.Frame(c_man.body, bg=T.CARD)
        brow.pack(anchor="w", pady=(8, 0))
        make_button(brow, "\u2705  Apply manual settings", self._tun_apply_manual,
                    kind="accent").pack(side="left")
        make_button(brow, "\u21A9  Reset to defaults", self._tun_reset, kind="danger"
                    ).pack(side="left", padx=8)

        # ---- Automatic profiles
        c_auto = Card(body, "Automatic profiles (one click, recommended)", "\U0001F916")
        c_auto.pack(fill="x", pady=(0, 12))
        tk.Label(c_auto.body, text="Choose a goal and PC Doctor applies a safe, tested set of values:",
                 bg=T.CARD, fg=T.TEXT_DIM, font=T.F(10)).pack(anchor="w")
        arow = tk.Frame(c_auto.body, bg=T.CARD)
        arow.pack(anchor="w", pady=8)
        make_button(arow, "\U0001F343  ECO / UNDERVOLT\n(cooler \u00b7 quieter \u00b7 less power)",
                    lambda: self._tun_profile("eco"), kind="accent", width=32
                    ).pack(side="left", padx=(0, 8))
        make_button(arow, "\u2696  BALANCED\n(factory defaults)",
                    lambda: self._tun_profile("balanced"), width=32
                    ).pack(side="left", padx=(0, 8))
        make_button(arow, "\U0001F680  PERFORMANCE\n(max safe power \u00b7 more FPS)",
                    lambda: self._tun_profile("performance"), kind="warn", width=32
                    ).pack(side="left")
        prow = tk.Frame(c_auto.body, bg=T.CARD)
        prow.pack(anchor="w", pady=(4, 0))
        make_button(prow, "\U0001F6E1  Create Windows restore point",
                    self._tun_restore_point, kind="ghost").pack(side="left")
        make_button(prow, "\U0001F50D  Start 20s stability monitor",
                    self._tun_monitor_start).pack(side="left", padx=8)
        self.tun_monitor_lbl = tk.Label(prow, text="", bg=T.CARD, fg=T.ACCENT,
                                        font=T.F(10, bold=True))
        self.tun_monitor_lbl.pack(side="left", padx=8)

        # ---- AMD / Intel GPUs
        c_vend = Card(body, "AMD / Intel GPUs", "\U0001F4A1")
        c_vend.pack(fill="x", pady=(0, 12))
        self.tun_vendor_lbl = tk.Label(c_vend.body, text="", bg=T.CARD, fg=T.TEXT_DIM,
                                       font=T.F(10), wraplength=860, justify="left")
        self.tun_vendor_lbl.pack(anchor="w")
        self.tun_vendor_btns = tk.Frame(c_vend.body, bg=T.CARD)
        self.tun_vendor_btns.pack(anchor="w", pady=(8, 0))

        # ---- CPU power tuning
        c_cpu = Card(body, "CPU power tuning (Windows)", "\u2699")
        c_cpu.pack(fill="x", pady=(0, 12))
        self.cpu_plan_lbl = tk.Label(c_cpu.body, text="", bg=T.CARD, fg=T.TEXT,
                                     font=T.F(11, bold=True))
        self.cpu_plan_lbl.pack(anchor="w")
        crow = tk.Frame(c_cpu.body, bg=T.CARD)
        crow.pack(anchor="w", pady=6)
        make_button(crow, "\U0001F680  High performance", lambda: self._cpu_plan("SCHEME_MIN")
                    ).pack(side="left")
        make_button(crow, "\u2696  Balanced", lambda: self._cpu_plan("SCHEME_BALANCED")
                    ).pack(side="left", padx=8)
        make_button(crow, "\U0001F343  Power saver", lambda: self._cpu_plan("SCHEME_MAX")
                    ).pack(side="left")
        brow2 = tk.Frame(c_cpu.body, bg=T.CARD)
        brow2.pack(anchor="w", pady=(0, 6))
        make_button(brow2, "\u26A1  Boost mode: aggressive",
                    lambda: self._cpu_boost(2)).pack(side="left")
        make_button(brow2, "\U0001F343  Boost mode: normal",
                    lambda: self._cpu_boost(1)).pack(side="left", padx=8)
        tk.Label(c_cpu.body,
                 text="Real CPU/GPU voltage curves (undervolt offsets) need vendor tools: "
                      "Intel XTU, AMD Ryzen Master, ThrottleStop. PC Doctor links them here "
                      "so you can download the official one for your CPU.",
                 bg=T.CARD, fg=T.TEXT_DIM, font=T.F(10), wraplength=860,
                 justify="left").pack(anchor="w")
        xvrow = tk.Frame(c_cpu.body, bg=T.CARD)
        xvrow.pack(anchor="w", pady=(6, 0))
        make_button(xvrow, "Intel XTU", lambda: webbrowser.open(
            "https://www.intel.com/content/www/us/en/download/17881/intel-extreme-tuning-utility-intel-xtu.html"
        )).pack(side="left")
        make_button(xvrow, "AMD Ryzen Master", lambda: webbrowser.open(
            "https://www.amd.com/en/technologies/ryzen-master")
        ).pack(side="left", padx=8)
        make_button(xvrow, "ThrottleStop", lambda: webbrowser.open(
            "https://www.techpowerup.com/download/techpowerup-throttlestop/")
        ).pack(side="left")

        self._tun_refresh()
        self._cpu_plan_lbl_update()
        return frame

    # ------------------------------------------------ tuning internals
    def _tun_refresh(self):
        def work():
            return tun_mod.gpu_caps()

        def done(caps):
            self._tun_fill(caps)

        self.run_in_thread(work, done, lambda e: None)

    def _tun_fill(self, caps):
        if not caps:
            self.tun_name_lbl.configure(
                text="No NVIDIA GPU detected (nvidia-smi unavailable) - "
                     "automatic/manual tuning works on NVIDIA GPUs only")
            for w in self.tun_kv.winfo_children():
                w.destroy()
            return
        self._tun_caps = caps
        self.tun_name_lbl.configure(
            text=f"{caps['name']}  \u00b7  index {caps['index']}")
        for w in self.tun_kv.winfo_children():
            w.destroy()
        left = tk.Frame(self.tun_kv, bg=T.CARD)
        left.pack(side="left", fill="both", expand=True)
        right = tk.Frame(self.tun_kv, bg=T.CARD)
        right.pack(side="left", fill="both", expand=True)
        kv_row(left, "Core clock", f"{caps.get('core_clock_mhz') or 'N/A'} MHz "
                                   f"(max {caps.get('core_clock_max_mhz') or 'N/A'})", bg=T.CARD)
        kv_row(left, "Memory clock", f"{caps.get('mem_clock_mhz') or 'N/A'} MHz "
                                     f"(max {caps.get('mem_clock_max_mhz') or 'N/A'})", bg=T.CARD)
        kv_row(left, "Temperature", f"{caps.get('temp_c') or 'N/A'} \u00b0C", bg=T.CARD,
               val_fg=(T.DANGER if (caps.get("temp_c") or 0) >= 80 else T.ACCENT))
        kv_row(left, "Fan", f"{caps.get('fan_percent') or 'N/A'} %", bg=T.CARD)
        kv_row(right, "Power draw", f"{caps.get('power_w') or 'N/A'} W "
                                     f"of {caps.get('power_limit_w') or 'N/A'} W", bg=T.CARD)
        kv_row(right, "Power limit range",
               f"{caps.get('power_min_w') or 'N/A'} - {caps.get('power_max_w') or 'N/A'} W "
               f"(default {caps.get('power_default_w') or 'N/A'} W)", bg=T.CARD, wrap=300)
        kv_row(right, "VRAM", f"{caps.get('vram_used_mb') or 0:.0f} / "
                               f"{caps.get('vram_total_mb') or 0:.0f} MB", bg=T.CARD)
        kv_row(right, "Usage", f"{caps.get('util_percent') or 0:.0f} %", bg=T.CARD)
        self.tun_temp_chart.push(caps.get("temp_c"))
        self.tun_clock_chart.push(caps.get("core_clock_mhz"))

        # configure sliders from real limits
        lo = int(caps.get("power_min_w") or 50)
        hi = int(caps.get("power_max_w") or 400)
        cur = int(caps.get("power_limit_w") or hi)
        self.tun_pl_scale.configure(from_=lo, to=hi)
        self.tun_pl_var.set(cur)
        core_hi = int((caps.get("core_clock_max_mhz") or 2000) + 150)
        self.tun_core_scale.configure(to=core_hi)
        mem_hi = int((caps.get("mem_clock_max_mhz") or 8000) + 500)
        self.tun_mem_scale.configure(to=mem_hi)
        self._tun_slider_labels()

        # vendor hint (AMD/Intel)
        self._tun_vendor_hint()

    def _tun_slider_labels(self):
        if not hasattr(self, "_tun_caps") or not self._tun_caps:
            return
        caps = self._tun_caps
        pl = self.tun_pl_var.get()
        dflt = int(caps.get("power_default_w") or 0)
        suffix = " (default)" if dflt and pl == dflt else ""
        self.tun_pl_lbl.configure(text=f"Power limit: {pl} W{suffix}")
        core = self.tun_core_var.get()
        self.tun_core_lbl.configure(
            text=("Core clock lock: unlocked/default" if core == 0
                  else f"Core clock lock: {core} MHz"))
        mem = self.tun_mem_var.get()
        self.tun_mem_lbl.configure(
            text=("Memory clock lock: unlocked/default" if mem == 0
                  else f"Memory clock lock: {mem} MHz"))

    def _tun_apply_manual(self):
        if not hasattr(self, "_tun_caps") or not self._tun_caps:
            messagebox.showwarning(
                APP_NAME,
                "No NVIDIA GPU detected. Manual tuning needs nvidia-smi "
                "(NVIDIA GPUs only).\nFor AMD/Intel use the vendor tools linked below.")
            return
        caps = self._tun_caps
        idx = caps["index"]
        self.start_busy("Applying manual tuning...")

        def work():
            msgs = []
            ok_all = True
            ok, msg = tun_mod.apply_power_limit(idx, self.tun_pl_var.get())
            ok_all &= ok
            msgs.append(msg)
            core = self.tun_core_var.get()
            if core > 0:
                ok, msg = tun_mod.lock_core_clock(idx, core)
                ok_all &= ok
                msgs.append(msg)
            mem = self.tun_mem_var.get()
            if mem > 0:
                ok, msg = tun_mod.lock_mem_clock(idx, mem)
                ok_all &= ok
                msgs.append(msg)
            return ok_all, "\n".join(msgs)

        def done(res):
            ok_all, msg = res
            self.end_busy("Manual tuning applied" if ok_all else "Some settings failed")
            self.after(600, self._tun_refresh)
            if ok_all:
                messagebox.showinfo(APP_NAME,
                                    "Settings applied!\n\n" + msg +
                                    "\n\nTip: run the Benchmark page and watch the "
                                    "temperature chart to validate stability.")
            else:
                messagebox.showwarning(APP_NAME, msg)

        self.run_in_thread(work, done,
                           lambda e: (self.end_busy("Error"),
                                      messagebox.showerror(APP_NAME, str(e))))

    def _tun_reset(self):
        if not hasattr(self, "_tun_caps") or not self._tun_caps:
            return
        idx = self._tun_caps["index"]
        self.start_busy("Resetting GPU to defaults...")

        def work():
            return tun_mod.reset_gpu_defaults(idx)

        def done(res):
            ok, msg = res
            self.end_busy("GPU reset to defaults" if ok else "Reset failed")
            self.after(600, self._tun_refresh)
            (messagebox.showinfo if ok else messagebox.showwarning)(APP_NAME, msg)

        self.run_in_thread(work, done,
                           lambda e: (self.end_busy("Error"),
                                      messagebox.showerror(APP_NAME, str(e))))

    def _tun_profile(self, name):
        self.start_busy(f"Applying {name} profile...")

        def work():
            return tun_mod.apply_profile(name)

        def done(res):
            ok, msg = res
            self.end_busy("Profile applied" if ok else "Profile failed")
            self.after(600, self._tun_refresh)
            if ok:
                messagebox.showinfo(APP_NAME, msg + "\n\nTip: start the 20s stability "
                                    "monitor to verify temperatures.")
            else:
                messagebox.showwarning(APP_NAME, msg)

        self.run_in_thread(work, done,
                           lambda e: (self.end_busy("Error"),
                                      messagebox.showerror(APP_NAME, str(e))))

    def _tun_monitor_start(self):
        if self._tun_monitoring:
            return
        if not hasattr(self, "_tun_caps") or not self._tun_caps:
            messagebox.showwarning(APP_NAME, "No NVIDIA GPU to monitor.")
            return
        self._tun_monitoring = True
        self.tun_temp_chart.data.clear()
        self.tun_clock_chart.data.clear()
        self.tun_monitor_lbl.configure(text="Monitoring...", fg=T.WARN)
        self.start_busy("Stability monitor running (20s)...")

        def work():
            def prog(caps):
                self.root.after(0, lambda: self._tun_monitor_tick(caps))
            max_temp, samples = tun_mod.monitor_gpu(seconds=20, progress=prog)
            return max_temp, len(samples)

        def done(res):
            max_temp, n = res
            self._tun_monitoring = False
            self.end_busy(f"Monitor done: max {max_temp:.0f} \u00b0C")
            if max_temp >= tun_mod.TEMP_MAX_C:
                self.tun_monitor_lbl.configure(
                    text=f"\u274C Max {max_temp:.0f} \u00b0C - too hot!", fg=T.DANGER)
                if messagebox.askyesno(
                    APP_NAME,
                    f"GPU reached {max_temp:.0f} \u00b0C during the monitor.\n"
                    "Restore safe defaults now?",
                ):
                    self._tun_reset()
            elif max_temp >= tun_mod.TEMP_SAFE_C:
                self.tun_monitor_lbl.configure(
                    text=f"\u26A0 Max {max_temp:.0f} \u00b0C - keep an eye on it", fg=T.WARN)
            else:
                self.tun_monitor_lbl.configure(
                    text=f"\u2705 Max {max_temp:.0f} \u00b0C over {n}s - looks stable",
                    fg=T.ACCENT)

        def error(e):
            self._tun_monitoring = False
            self.end_busy("Monitor error")
            messagebox.showerror(APP_NAME, str(e))

        self.run_in_thread(work, done, error)

    def _tun_monitor_tick(self, caps):
        try:
            self.tun_temp_chart.push(caps.get("temp_c"))
            self.tun_clock_chart.push(caps.get("core_clock_mhz"))
            self.tun_monitor_lbl.configure(
                text=f"{caps.get('temp_c') or 0:.0f} \u00b0C \u00b7 "
                     f"{caps.get('power_w') or 0:.0f} W \u00b7 "
                     f"{caps.get('core_clock_mhz') or 0:.0f} MHz")
        except Exception:
            pass

    def _tun_restore_point(self):
        self.start_busy("Creating Windows restore point...")

        def work():
            return drv_mod.create_restore_point()

        def done(res):
            ok, msg = res
            self.end_busy("Restore point created" if ok else "Restore point failed")
            (messagebox.showinfo if ok else messagebox.showwarning)(APP_NAME, msg)

        self.run_in_thread(work, done,
                           lambda e: (self.end_busy("Error"),
                                      messagebox.showerror(APP_NAME, str(e))))

    def _tun_vendor_hint(self):
        gpus = self.data.get("gpus") or []
        vendors = [g["vendor"] for g in gpus if g["vendor"] in ("AMD", "Intel")]
        for w in self.tun_vendor_btns.winfo_children():
            w.destroy()
        if not vendors:
            self.tun_vendor_lbl.configure(
                text="No AMD/Intel GPU detected. On AMD use Adrenalin (Performance > Tuning); "
                     "on Intel use Intel Graphics Software or XTU.")
            return
        parts = []
        for v in dict.fromkeys(vendors):
            info = tun_mod.VENDOR_TUNING_APPS.get(v)
            if info:
                parts.append(f"{v}: {info['how']}")
                make_button(self.tun_vendor_btns, f"\u2B07  Download {info['app']}",
                            lambda u=info["url"]: webbrowser.open(u)).pack(side="left",
                                                                           padx=(0, 8))
        self.tun_vendor_lbl.configure(text="  \u00b7  ".join(parts))

    # ------------------------------------------------ CPU tuning
    def _cpu_plan_lbl_update(self):
        if not IS_WINDOWS:
            self.cpu_plan_lbl.configure(text="CPU power plans are Windows-only")
            return

        def work():
            return tun_mod.cpu_power_report()

        def done(txt):
            try:
                self.cpu_plan_lbl.configure(text="Active plan: " + (txt or "unknown"))
            except Exception:
                pass

        self.run_in_thread(work, done, lambda e: None)

    def _cpu_plan(self, alias):
        self.start_busy("Changing power plan...")

        def work():
            return tun_mod.set_power_plan(alias)

        def done(res):
            ok, msg = res
            self.end_busy("Power plan changed" if ok else "Power plan failed")
            if not ok:
                messagebox.showwarning(APP_NAME, msg)
            self._cpu_plan_lbl_update()

        self.run_in_thread(work, done,
                           lambda e: (self.end_busy("Error"),
                                      messagebox.showerror(APP_NAME, str(e))))

    def _cpu_boost(self, mode):
        self.start_busy("Setting CPU boost mode...")

        def work():
            return tun_mod.set_boost_mode(mode)

        def done(res):
            ok, msg = res
            self.end_busy(msg if ok else "Boost mode failed")
            (messagebox.showinfo if ok else messagebox.showwarning)(APP_NAME, msg)

        self.run_in_thread(work, done,
                           lambda e: (self.end_busy("Error"),
                                      messagebox.showerror(APP_NAME, str(e))))

    # =========================================================== DRIVERS
    def _page_drivers(self, parent):
        frame = tk.Frame(parent, bg=T.BG)

        toolbar = tk.Frame(frame, bg=T.BG)
        toolbar.pack(fill="x", pady=(0, 10))
        make_button(toolbar, "\U0001F50D  Scan drivers", self._scan_drivers,
                    kind="accent").pack(side="left")
        make_button(toolbar, "\u2B07  Update drivers (Windows Update)",
                    self._update_drivers, kind="warn").pack(side="left", padx=8)
        make_button(toolbar, "\U0001F504  Rescan hardware", self._rescan_hw).pack(side="left", padx=(0, 8))
        make_button(toolbar, "\U0001F310  GPU vendor website",
                    self._open_gpu_page).pack(side="left")

        # Stats
        self.drv_stats_lbl = tk.Label(frame, text="", bg=T.BG, fg=T.TEXT_DIM,
                                      font=T.F(10))
        self.drv_stats_lbl.pack(anchor="w", pady=(0, 6))

        # Filter
        frow = tk.Frame(frame, bg=T.BG)
        frow.pack(fill="x", pady=(0, 8))
        tk.Label(frow, text="\U0001F50E Search:", bg=T.BG, fg=T.TEXT,
                 font=T.F(10)).pack(side="left")
        self.drv_search_var = tk.StringVar()
        entry = tk.Entry(frow, textvariable=self.drv_search_var, bg=T.CARD,
                         fg=T.TEXT, insertbackground=T.TEXT, relief="flat",
                         font=T.F(10), width=30)
        entry.pack(side="left", padx=8, ipady=5)
        self.drv_search_var.trace_add("write", lambda *a: self._apply_driver_filter())
        tk.Label(frow, text="Show:", bg=T.BG, fg=T.TEXT, font=T.F(10)).pack(side="left", padx=(16, 4))
        self.drv_filter_var = tk.StringVar(value="All")
        combo = ttk.Combobox(frow, textvariable=self.drv_filter_var, state="readonly",
                             values=["All", "Outdated", "OK"], width=10)
        combo.pack(side="left")
        combo.bind("<<ComboboxSelected>>", lambda e: self._apply_driver_filter())

        # Table
        table_wrap = tk.Frame(frame, bg=T.BORDER)
        table_wrap.pack(fill="both", expand=True)
        cols = ("device", "manufacturer", "version", "date", "status")
        self.drv_tree = ttk.Treeview(table_wrap, columns=cols, show="headings",
                                     style="PDoctor.Treeview")
        headers = ("Device", "Manufacturer", "Version", "Date", "Status")
        widths = (330, 190, 130, 110, 100)
        for c, h, w in zip(cols, headers, widths):
            self.drv_tree.heading(c, text=h)
            self.drv_tree.column(c, width=w, anchor="w")
        vsb = ttk.Scrollbar(table_wrap, orient="vertical", command=self.drv_tree.yview,
                            style="PDoctor.Vertical.TScrollbar")
        self.drv_tree.configure(yscrollcommand=vsb.set)
        self.drv_tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        self.drv_tree.tag_configure("old", foreground=T.ORANGE)
        self.drv_tree.tag_configure("ok", foreground=T.TEXT)

        if self.data["drivers"]:
            self._fill_drivers()
        else:
            tk.Label(frame, text="Run a scan to see the list of installed drivers.",
                     bg=T.BG, fg=T.TEXT_DIM, font=T.F(11)).pack(anchor="w", pady=(14, 0))
        return frame

    def _scan_drivers(self):
        if self.check_busy():
            return
        self.start_busy("Driver scan in progress...")

        def work():
            drivers, err = drv_mod.scan_drivers()
            return drivers, err

        def done(res):
            drivers, err = res
            self.end_busy("Scan complete")
            if err:
                messagebox.showwarning(APP_NAME, err)
                return
            self.data["drivers"] = drivers
            self._fill_drivers()
            stats = drv_mod.driver_stats(drivers)
            if stats["old"] > 0:
                messagebox.showinfo(
                    APP_NAME,
                    f"Found {stats['old']} outdated drivers out of {stats['total']}.\n"
                    "Use 'Update drivers (Windows Update)' to look for newer versions.",
                )

        def error(e):
            self.end_busy("Scan error")
            messagebox.showerror(APP_NAME, str(e))

        self.run_in_thread(work, done, error)

    def _fill_drivers(self):
        self.drv_tree.delete(*self.drv_tree.get_children())
        drivers = self.data["drivers"] or []
        for d in drivers:
            tag = "old" if d["status"] == "Outdated" else "ok"
            self.drv_tree.insert("", "end", values=(
                d["device"], d["manufacturer"], d["version"],
                d["date"] or "N/A", d["status"],
            ), tags=(tag,))
        self._update_driver_stats()
        self._apply_driver_filter()

    def _update_driver_stats(self):
        drivers = self.data["drivers"] or []
        if not drivers:
            self.drv_stats_lbl.configure(text="")
            return
        stats = drv_mod.driver_stats(drivers)
        self.drv_stats_lbl.configure(
            text=f"Total: {stats['total']}   \u00b7   Signed: {stats['signed']}   \u00b7   "
                 f"Outdated (> {drv_mod.OLD_DRIVER_YEARS} years): {stats['old']}"
        )

    def _apply_driver_filter(self):
        text = self.drv_search_var.get().lower().strip()
        filt = self.drv_filter_var.get()
        if text or filt != "All":
            self._refilter_drivers(text, filt)
            return
        for item in self.drv_tree.get_children():
            try:
                self.drv_tree.move(item, "", "end")
            except tk.TclError:
                pass

    def _refilter_drivers(self, text, filt):
        """Rebuilds the filtered view from the data source."""
        self.drv_tree.delete(*self.drv_tree.get_children())
        for d in (self.data["drivers"] or []):
            ok_text = (not text or text in d["device"].lower()
                       or text in d["manufacturer"].lower())
            ok_filt = (filt == "All" or d["status"] == filt)
            if ok_text and ok_filt:
                tag = "old" if d["status"] == "Outdated" else "ok"
                self.drv_tree.insert("", "end", values=(
                    d["device"], d["manufacturer"], d["version"],
                    d["date"] or "N/A", d["status"]), tags=(tag,))

    def _update_drivers(self):
        if self.check_busy():
            return
        if not IS_WINDOWS:
            messagebox.showinfo(APP_NAME,
                                "Driver updates are only available on Windows.\n"
                                "On Linux try: ubuntu-drivers autoinstall")
            return
        if not admin_mod.is_admin():
            if messagebox.askyesno(
                APP_NAME,
                "Installing drivers requires administrator rights.\n"
                "Restart PC Doctor Pro as administrator?",
            ):
                self._elevate()
            return
        if not messagebox.askyesno(
            APP_NAME,
            "PC Doctor Pro:\n\n"
            "1. Creates a Windows restore point (safety)\n"
            "2. Searches Windows Update for driver updates\n"
            "3. Installs them automatically\n\n"
            "This may take several minutes. Continue?",
        ):
            return
        self.start_busy("Restore point + searching drivers...")

        def work():
            rp_ok, rp_msg = drv_mod.create_restore_point()
            updates, err = drv_mod.search_driver_updates()
            return rp_ok, rp_msg, updates, err

        def done(res):
            rp_ok, rp_msg, updates, err = res
            if err:
                self.end_busy("Search failed")
                messagebox.showwarning(APP_NAME, f"Update search failed:\n{err}")
                return
            if not updates:
                self.end_busy("No updates available")
                messagebox.showinfo(
                    APP_NAME,
                    "No driver updates available on Windows Update.\n"
                    "Your drivers are already up to date! \u2705"
                    + (f"\n\n{rp_msg}" if rp_ok else ""),
                )
                return
            titles = "\n".join(f"  \u2022 {u.get('Title', 'Driver')}" for u in updates[:10])
            more = f"\n  ... and {len(updates) - 10} more" if len(updates) > 10 else ""
            if not messagebox.askyesno(
                APP_NAME,
                f"Found {len(updates)} driver updates:\n\n{titles}{more}\n\n"
                "Install them now? (this may take a few minutes)",
            ):
                self.end_busy("Update cancelled")
                return
            self.start_busy("Installing drivers (up to 10 minutes)...")

            def work2():
                ok, msg = drv_mod.install_driver_updates()
                return ok, msg

            def done2(res):
                ok, msg = res
                self.end_busy("Update finished")
                if ok:
                    messagebox.showinfo(
                        APP_NAME, f"{msg}\n\nA reboot is recommended."
                    )
                    self._scan_drivers()
                else:
                    messagebox.showwarning(APP_NAME, msg)

            self.run_in_thread(work2, done2,
                               lambda e: (self.end_busy("Error"),
                                          messagebox.showerror(APP_NAME, str(e))))

        def error(e):
            self.end_busy("Error")
            messagebox.showerror(APP_NAME, str(e))

        self.run_in_thread(work, done, error)

    def _rescan_hw(self):
        if self.check_busy():
            return
        self.start_busy("Rescanning hardware...")

        def work():
            return drv_mod.rescan_devices()

        def done(res):
            ok, msg = res
            self.end_busy("Rescan complete" if ok else "Rescan failed")
            (messagebox.showinfo if ok else messagebox.showwarning)(APP_NAME, msg)

        self.run_in_thread(work, done,
                           lambda e: (self.end_busy("Error"),
                                      messagebox.showerror(APP_NAME, str(e))))

    def _open_gpu_page(self):
        gpus = self.data.get("gpus") or []
        urls = [g["driver_page"] for g in gpus if g.get("driver_page")]
        if urls:
            webbrowser.open(urls[0])
        else:
            webbrowser.open("https://www.nvidia.com/en-us/drivers/")

    # =========================================================== MAINTENANCE
    def _page_maintenance(self, parent):
        frame = ScrollFrame(parent)
        body = frame.inner

        # One-click maintenance
        big = Card(body, "Automatic maintenance (1 click)", "\u2699")
        big.pack(fill="x", pady=(0, 12))
        tk.Label(big.body, text="Runs automatically: temp file cleanup, DNS cache flush, "
                                "hardware rescan and a Windows Update check.",
                 bg=T.CARD, fg=T.TEXT_DIM, font=T.F(10), wraplength=800,
                 justify="left").pack(anchor="w")
        make_button(big.body, "\u25B6  Run automatic maintenance",
                    self._auto_maintenance, kind="accent").pack(anchor="w", pady=(10, 0))
        self.maint_result = tk.Label(big.body, text="", bg=T.CARD, fg=T.TEXT,
                                     font=T.F(10), wraplength=800, justify="left")
        self.maint_result.pack(anchor="w", pady=(8, 0))
        if self.data["maint"].get("steps"):
            self.maint_result.configure(
                text="\n".join(f"\u2705 {n}: {m}" for n, m in self.data["maint"]["steps"]))

        row = tk.Frame(body, bg=T.BG)
        row.pack(fill="x")

        c_clean = Card(row, "Temp file cleanup", "\U0001F9F9")
        c_clean.pack(side="left", fill="both", expand=True, padx=(0, 8))
        self.temp_usage_lbl = tk.Label(c_clean.body, text="Calculating...",
                                       bg=T.CARD, fg=T.TEXT, font=T.F(10))
        self.temp_usage_lbl.pack(anchor="w")
        make_button(c_clean.body, "Clean now", self._clean_temp).pack(anchor="w", pady=8)

        c_dns = Card(row, "Network", "\U0001F310")
        c_dns.pack(side="left", fill="both", expand=True, padx=(8, 0))
        tk.Label(c_dns.body, text="Flush the DNS cache to fix browsing issues.",
                 bg=T.CARD, fg=T.TEXT_DIM, font=T.F(10), wraplength=360,
                 justify="left").pack(anchor="w")
        make_button(c_dns.body, "Flush DNS cache", self._flush_dns).pack(anchor="w", pady=8)

        # Disk health
        c_health = Card(body, "Disk health", "\U0001F5A5")
        c_health.pack(fill="x", pady=10)
        self.health_tree_holder = tk.Frame(c_health.body, bg=T.CARD)
        self.health_tree_holder.pack(fill="x")
        make_button(c_health.body, "\U0001F504  Check disk health",
                    self._check_disk_health).pack(anchor="w", pady=(10, 0))

        # Battery (Windows)
        if IS_WINDOWS:
            c_bat = Card(body, "Battery", "\U0001F50B")
            c_bat.pack(fill="x", pady=(0, 10))
            tk.Label(c_bat.body, text="Generates the official Windows battery report "
                                      "(powercfg /batteryreport).",
                     bg=T.CARD, fg=T.TEXT_DIM, font=T.F(10),
                     wraplength=800, justify="left").pack(anchor="w")
            make_button(c_bat.body, "Generate battery report",
                        self._battery_report).pack(anchor="w", pady=8)

        # Startup programs
        c_start = Card(body, "Startup programs", "\U0001F680")
        c_start.pack(fill="x", pady=(0, 10))
        tb = tk.Frame(c_start.body, bg=T.BORDER)
        tb.pack(fill="x")
        cols = ("name", "location", "status")
        self.start_tree = ttk.Treeview(tb, columns=cols, show="headings",
                                       style="PDoctor.Treeview", height=6)
        for c, h in zip(cols, ("Program", "Origin", "Status")):
            self.start_tree.heading(c, text=h)
            self.start_tree.column(c, width=(280, 160, 120)[cols.index(c)], anchor="w")
        vsb = ttk.Scrollbar(tb, orient="vertical", command=self.start_tree.yview,
                            style="PDoctor.Vertical.TScrollbar")
        self.start_tree.configure(yscrollcommand=vsb.set)
        self.start_tree.pack(side="left", fill="x", expand=True)
        vsb.pack(side="right", fill="y")
        self.start_tree.tag_configure("disabled", foreground=T.TEXT_DIM)
        srow = tk.Frame(c_start.body, bg=T.CARD)
        srow.pack(fill="x", pady=8)
        make_button(srow, "Reload list", self._load_startup).pack(side="left")
        make_button(srow, "Disable selected", lambda: self._toggle_startup(False),
                    kind="warn").pack(side="left", padx=8)
        make_button(srow, "Re-enable selected", lambda: self._toggle_startup(True)
                    ).pack(side="left")
        self._load_startup()
        return frame

    def _auto_maintenance(self):
        if self.check_busy():
            return
        if not messagebox.askyesno(
            APP_NAME,
            "Start automatic maintenance?\n\n"
            "\u2022 Temp file cleanup\n"
            "\u2022 DNS cache flush\n"
            "\u2022 Hardware rescan\n"
            "\u2022 Windows Update check\n\n"
            "No personal files are touched.",
        ):
            return
        self.start_busy("Automatic maintenance...")

        def work():
            return maint_mod.auto_maintenance(progress=lambda m: None)

        def done(res):
            self.data["maint"] = res
            self.end_busy("Maintenance complete")
            self.maint_result.configure(
                text="\n".join(f"\u2705 {n}: {m}" for n, m in res["steps"]))
            self._update_temp_usage()

        def error(e):
            self.end_busy("Maintenance error")
            messagebox.showerror(APP_NAME, str(e))

        self.run_in_thread(work, done, error)

    def _update_temp_usage(self):
        def work():
            return maint_mod.temp_usage()

        def done(res):
            self.temp_usage_lbl.configure(
                text=f"Used: {res['bytes'] / (1024 ** 2):.0f} MB "
                     f"({res['files']} files) in {', '.join(res['dirs'])}")

        self.run_in_thread(work, done, lambda e: None)

    def _clean_temp(self):
        if self.check_busy():
            return
        if not messagebox.askyesno(
            APP_NAME,
            "Clean system temp files?\n\n"
            "Only temporary files are removed: no personal documents.",
        ):
            return
        self.start_busy("Cleaning temp files...")

        def work():
            return maint_mod.clean_temp()

        def done(res):
            self.end_busy("Cleanup complete")
            self.temp_usage_lbl.configure(
                text=f"Freed: {res['bytes_freed_label']} "
                     f"({res['files_removed']} files removed)")
            messagebox.showinfo(
                APP_NAME,
                f"Cleanup complete!\n\nFreed: {res['bytes_freed_label']}\n"
                f"Files removed: {res['files_removed']}\n"
                f"Locked files skipped: {res['errors']}",
            )

        self.run_in_thread(work, done,
                           lambda e: (self.end_busy("Error"),
                                      messagebox.showerror(APP_NAME, str(e))))
        self.after(200, self._update_temp_usage)

    def _flush_dns(self):
        def work():
            return maint_mod.flush_dns()

        def done(res):
            ok, msg = res
            (messagebox.showinfo if ok else messagebox.showwarning)(APP_NAME, msg)

        self.run_in_thread(work, done,
                           lambda e: messagebox.showerror(APP_NAME, str(e)))

    def _check_disk_health(self):
        if self.check_busy():
            return
        self.start_busy("Checking disk health...")

        def work():
            return maint_mod.disk_health()

        def done(res):
            disks, err = res
            self.end_busy("Check complete")
            for w in self.health_tree_holder.winfo_children():
                w.destroy()
            if err:
                tk.Label(self.health_tree_holder, text=err, bg=T.CARD, fg=T.TEXT_DIM,
                         font=T.F(10)).pack(anchor="w")
                return
            cols = ("name", "media", "health", "size")
            tree = ttk.Treeview(self.health_tree_holder, columns=cols, show="headings",
                                style="PDoctor.Treeview", height=max(2, len(disks)))
            for c, h in zip(cols, ("Disk", "Type", "Health", "Capacity")):
                tree.heading(c, text=h)
                tree.column(c, width=(200, 120, 120, 120)[cols.index(c)], anchor="w")
            tree.pack(fill="x")
            for d in disks:
                health = d.get("health", "N/A")
                color = T.TEXT
                if health.lower() in ("healthy", "ok"):
                    color = T.ACCENT
                elif health.lower() in ("warning", "unhealthy"):
                    color = T.DANGER
                tree.insert("", "end", values=(
                    d.get("name"), d.get("media"), health,
                    f"{d.get('size_gb', 'N/A')} GB" if d.get("size_gb") else d.get("size_gb", "N/A")),
                    tags=("h",))
                tree.tag_configure("h", foreground=color)

        self.run_in_thread(work, done,
                           lambda e: (self.end_busy("Error"),
                                      messagebox.showerror(APP_NAME, str(e))))

    def _battery_report(self):
        def work():
            return maint_mod.battery_report()

        def done(res):
            ok, msg, path = res
            if ok and path:
                if messagebox.askyesno(APP_NAME, f"{msg}.\n\nOpen the report folder?"):
                    from core.utils import safe_open_folder
                    safe_open_folder(os.path.dirname(path))
            else:
                messagebox.showwarning(APP_NAME, msg)

        self.run_in_thread(work, done,
                           lambda e: messagebox.showerror(APP_NAME, str(e)))

    def _load_startup(self):
        def work():
            return maint_mod.list_startup()

        def done(items):
            self.start_tree.delete(*self.start_tree.get_children())
            self._startup_items = items
            for it in items:
                self.start_tree.insert("", "end", values=(
                    it["name"], it.get("location", ""),
                    "Enabled" if it.get("enabled") else "Disabled"),
                    tags=("disabled",) if not it.get("enabled") else ())

        self.run_in_thread(work, done, lambda e: None)

    def _toggle_startup(self, enable):
        sel = self.start_tree.selection()
        if not sel:
            messagebox.showinfo(APP_NAME, "Select a program from the list first.")
            return
        vals = self.start_tree.item(sel[0], "values")
        name = vals[0]
        item = next((i for i in getattr(self, "_startup_items", [])
                     if i["name"] == name), None)
        if not item:
            return
        if not enable:
            if not messagebox.askyesno(
                APP_NAME,
                f"Disable '{name}' at Windows startup?\n"
                "(You can re-enable it here at any time)",
            ):
                return
        ok, msg = maint_mod.set_startup_enabled(item, enable)
        if ok:
            self._load_startup()
        else:
            messagebox.showwarning(APP_NAME, msg)

    # =========================================================== BENCHMARK
    def _page_benchmark(self, parent):
        frame = ScrollFrame(parent)
        body = frame.inner

        c = Card(body, "System benchmark", "\u26A1")
        c.pack(fill="x")
        tk.Label(c.body, text="Measures the real performance of your PC. Total duration: ~10-20s. "
                              "Close heavy applications for reliable results.",
                 bg=T.CARD, fg=T.TEXT_DIM, font=T.F(10), wraplength=800,
                 justify="left").pack(anchor="w")
        brow = tk.Frame(c.body, bg=T.CARD)
        brow.pack(anchor="w", pady=10)
        make_button(brow, "\u25B6  Run full benchmark", self._run_bench,
                    kind="accent").pack(side="left")
        make_button(brow, "CPU only", lambda: self._run_bench(only="cpu")).pack(side="left", padx=8)
        make_button(brow, "Disk only", lambda: self._run_bench(only="disk")).pack(side="left")

        self.bench_progress = ttk.Progressbar(c.body, maximum=100,
                                              style="Accent.Horizontal.TProgressbar")
        self.bench_progress.pack(fill="x", pady=(6, 10))
        self.bench_lbl = tk.Label(c.body, text="", bg=T.CARD, fg=T.TEXT, font=T.F(11))
        self.bench_lbl.pack(anchor="w")

        res_card = Card(body, "Results", "\U0001F3C6")
        res_card.pack(fill="x", pady=10)
        self.bench_result_body = res_card.body
        tk.Label(self.bench_result_body, text="No benchmark run yet.",
                 bg=T.CARD, fg=T.TEXT_DIM, font=T.F(11)).pack(anchor="w")
        return frame

    def _run_bench(self, only=None):
        if self.check_busy():
            return
        self.start_busy("Benchmark running...")
        self.bench_lbl.configure(text="\u23F3 Starting benchmark...")
        self.bench_progress["value"] = 3

        def work():
            res = {}
            if only in (None, "cpu"):
                self.root.after(0, lambda: (self.bench_lbl.configure(
                    text="\u23F3 CPU test (single & multi-core)..."),
                    self.bench_progress.configure(value=15)))
                res["cpu"] = bench_mod.run_cpu_benchmark()
                self.root.after(0, lambda: self.bench_progress.configure(value=55))
            if only in (None, "ram"):
                res["ram"] = bench_mod.run_ram_benchmark()
                self.root.after(0, lambda: self.bench_progress.configure(value=75))
            if only in (None, "disk"):
                res["disk"] = bench_mod.run_disk_benchmark()
                self.root.after(0, lambda: self.bench_progress.configure(value=95))
            return res

        def done(res):
            self.bench_progress["value"] = 100
            self.bench_lbl.configure(text="\u2705 Benchmark complete!")
            self.data["bench"].update(res)
            self.end_busy("Benchmark complete")
            self.after(600, lambda: self.bench_progress.configure(value=0))
            self._show_bench_results()

        def error(e):
            self.end_busy("Benchmark error")
            self.bench_lbl.configure(text=f"\u274C Error: {e}")

        self.run_in_thread(work, done, error)

    def _show_bench_results(self):
        for w in self.bench_result_body.winfo_children():
            w.destroy()
        b = self.data["bench"]
        if not b:
            tk.Label(self.bench_result_body, text="No benchmark run yet.",
                     bg=T.CARD, fg=T.TEXT_DIM, font=T.F(11)).pack(anchor="w")
            return
        cpu = b.get("cpu")
        if cpu:
            tk.Label(self.bench_result_body, text="\u2699  CPU", bg=T.CARD, fg=T.ACCENT,
                     font=T.F(12, bold=True)).pack(anchor="w", pady=(4, 0))
            kv_row(self.bench_result_body, "Single-core score", cpu["single_score"])
            kv_row(self.bench_result_body, "Multi-core score", cpu["multi_score"])
            kv_row(self.bench_result_body, "Single/multi time",
                   f"{cpu['single_seconds']}s / {cpu['multi_seconds']}s")
        ram = b.get("ram")
        if ram:
            tk.Label(self.bench_result_body, text="\U0001F4BF  RAM", bg=T.CARD, fg=T.ACCENT,
                     font=T.F(12, bold=True)).pack(anchor="w", pady=(8, 0))
            kv_row(self.bench_result_body, "Read", f"{ram['read_gbps']} GB/s")
            kv_row(self.bench_result_body, "Write", f"{ram['write_gbps']} GB/s")
            kv_row(self.bench_result_body, "Average", f"{ram['avg_gbps']} GB/s")
        disk = b.get("disk")
        if disk:
            tk.Label(self.bench_result_body, text="\U0001F4BE  Disk", bg=T.CARD, fg=T.ACCENT,
                     font=T.F(12, bold=True)).pack(anchor="w", pady=(8, 0))
            kv_row(self.bench_result_body, "Sequential read", f"{disk['read_mbps']} MB/s")
            kv_row(self.bench_result_body, "Sequential write", f"{disk['write_mbps']} MB/s")

    # =========================================================== REPORT
    def _page_report(self, parent):
        frame = ScrollFrame(parent)
        body = frame.inner
        c = Card(body, "Export full report", "\U0001F4C4")
        c.pack(fill="x")
        tk.Label(c.body, text="Create a report with all collected information: system, "
                              "GPUs with images, disks, drivers, benchmark and maintenance. "
                              "The file is saved to your Desktop.",
                 bg=T.CARD, fg=T.TEXT_DIM, font=T.F(10), wraplength=800,
                 justify="left").pack(anchor="w")
        frow = tk.Frame(c.body, bg=T.CARD)
        frow.pack(anchor="w", pady=10)
        self.fmt_vars = {}
        for fmt, label in (("html", "HTML (recommended)"), ("txt", "TXT"),
                           ("json", "JSON")):
            v = tk.BooleanVar(value=fmt == "html")
            self.fmt_vars[fmt] = v
            tk.Checkbutton(frow, text=label, variable=v, bg=T.CARD, fg=T.TEXT,
                           selectcolor=T.BG_SIDEBAR, activebackground=T.CARD,
                           activeforeground=T.TEXT, font=T.F(10)).pack(side="left", padx=8)
        make_button(c.body, "\U0001F4BE  Generate report", self._generate_report,
                    kind="accent").pack(anchor="w")
        self.report_lbl = tk.Label(c.body, text="", bg=T.CARD, fg=T.ACCENT,
                                   font=T.F(10), wraplength=800, justify="left")
        self.report_lbl.pack(anchor="w", pady=(10, 0))
        return frame

    def _generate_report(self):
        if self.check_busy():
            return
        formats = tuple(f for f, v in self.fmt_vars.items() if v.get())
        if not formats:
            messagebox.showwarning(APP_NAME, "Select at least one format.")
            return
        self.start_busy("Generating report...")

        def work():
            if not self.data["system"]:
                self.data["system"] = system_info.get_full_system_info()
                self.data["gpus"] = gpu_mod.get_gpus()
            data = report_mod.build_report_data(
                self.data["system"], self.data["gpus"],
                self.data["drivers"], self.data["bench"], self.data["maint"])
            paths = report_mod.export_all(data, formats)
            return paths

        def done(paths):
            self.end_busy("Report generated")
            txt = "\n".join(paths)
            self.report_lbl.configure(text="\u2705 Report created:\n" + txt)
            if messagebox.askyesno(APP_NAME, "Report generated!\n\nOpen the folder?"):
                from core.utils import safe_open_folder, desktop_dir
                safe_open_folder(desktop_dir())

        self.run_in_thread(work, done,
                           lambda e: (self.end_busy("Error"),
                                      messagebox.showerror(APP_NAME, str(e))))

    # =========================================================== ABOUT
    def _page_about(self, parent):
        frame = ScrollFrame(parent)
        body = frame.inner
        c = Card(body, "System information", "\u2139")
        c.pack(fill="x")
        self.about_body = c.body
        if self.data["system"]:
            self._fill_about()
        else:
            tk.Label(c.body, text="Analysis running...", bg=T.CARD, fg=T.TEXT_DIM,
                     font=T.F(11)).pack(anchor="w")

        c2 = Card(body, "About the app", "\U0001F916")
        c2.pack(fill="x", pady=10)
        tk.Label(c2.body,
                 text=f"{APP_NAME} v{APP_VERSION} (English edition)\n\n"
                      "An app that analyses your PC hardware, shows detailed GPU info with "
                      "brand images, manages drivers safely (with restore points), runs "
                      "benchmarks, one-click maintenance and GPU overclock / undervolt "
                      "profiles with a live stability monitor.\n\n"
                      "Stack: Python \u00b7 Tkinter \u00b7 psutil \u00b7 Pillow \u00b7 "
                      "PowerShell/WMI \u00b7 nvidia-smi\n\n"
                      "License: MIT (see the LICENSE file).\n\n"
                      "\u26A0  Sensitive operations always ask for confirmation. "
                      "Use 'Maintenance' to free up space and fix network issues.",
                 bg=T.CARD, fg=T.TEXT_DIM, font=T.F(10), wraplength=820,
                 justify="left").pack(anchor="w")

        c3 = Card(body, "Repair & fix (one-click)", "\U0001F527")
        c3.pack(fill="x", pady=(0, 10))
        tk.Label(c3.body,
                 text="Runs pc_doctor_fixer.py: installs missing dependencies, cleans caches,\n"
                      "verifies every app file, analyses the crash log and applies quick fixes\n"
                      "(including the fix for the Python >>> terminal crash).",
                 bg=T.CARD, fg=T.TEXT_DIM, font=T.F(10),
                 justify="left").pack(anchor="w")
        row = tk.Frame(c3.body, bg=T.CARD)
        row.pack(anchor="w", pady=8)
        make_button(row, "\U0001F6E0  Run repair tool", self._run_fixer,
                    kind="accent").pack(side="left", padx=(0, 8))
        make_button(row, "\U0001F40D  Fix Python >>> crash",
                    lambda: self._run_fixer(("--repl-fix",))).pack(
            side="left", padx=(0, 8))
        make_button(row, "\U0001F4C2  Open app folder",
                    self._open_app_folder).pack(side="left")

        return frame

    def _fill_about(self):
        s = self.data["system"]
        for w in self.about_body.winfo_children():
            w.destroy()
        for k, v in [
            ("Operating system", f"{s['os'].get('edition', 'N/A')} ({s['os'].get('arch', '')})"),
            ("Build", s["os"].get("build", "N/A")),
            ("CPU", s["cpu"].get("name", "N/A")),
            ("Cores", f"{s['cpu'].get('cores_physical', '?')} physical / {s['cpu'].get('cores_logical', '?')} logical"),
            ("RAM", f"{s['ram'].get('total_gb', 'N/A')} GB"),
            ("Python", s["os"].get("python", "N/A")),
            ("Admin rights", "Yes" if admin_mod.is_admin() else "No"),
            ("App version", APP_VERSION),
        ]:
            kv_row(self.about_body, k, v)

    # ------------------------------------------------------ REPAIR TOOL
    def _run_fixer(self, extra_args=()):
        """Runs the standalone repair tool (pc_doctor_fixer.py)."""
        path = os.path.join(app_dir(), "pc_doctor_fixer.py")
        if not os.path.exists(path):
            messagebox.showerror(APP_NAME, "pc_doctor_fixer.py not found "
                                           "next to the app.")
            return
        args = ([sys.executable, path, "--auto", "--no-launch"]
                + list(extra_args))
        try:
            if IS_WINDOWS:
                subprocess.Popen(args,
                                 creationflags=subprocess.CREATE_NEW_CONSOLE)
                self.set_status("Repair tool opened - follow the new window")
                messagebox.showinfo(
                    APP_NAME,
                    "The repair tool opened in a new window.\n\n"
                    "It installs dependencies, cleans caches, verifies the "
                    "app files, analyses the crash log and applies quick "
                    "fixes. When it finishes, restart PC Doctor Pro.")
            else:
                res = subprocess.run(args, capture_output=True, text=True,
                                     timeout=300)
                out = (res.stdout or "")[-1500:]
                messagebox.showinfo(APP_NAME, "Repair finished.\n\n"
                                              + (out or "No output."))
        except Exception as e:
            messagebox.showerror(APP_NAME, "Could not run the repair tool:\n"
                                           + str(e))

    def _open_app_folder(self):
        if not safe_open_folder(app_dir()):
            messagebox.showinfo(APP_NAME, "App folder:\n" + app_dir())


def run_gui():
    root = tk.Tk()
    install_crash_guard(root)
    if IS_WINDOWS:
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    try:
        PCDoctorApp(root)
    except Exception:
        from core.utils import log_error
        import traceback
        msg = traceback.format_exc()
        log_error(msg)
        messagebox.showerror(
            APP_NAME,
            "The app could not start, but nothing was lost.\n"
            "The error details are shown below and saved in 'pcdoctor_error.log'.\n\n"
            + msg[-1200:],
        )
        raise
    root.mainloop()
