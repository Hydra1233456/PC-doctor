"""PC Doctor Pro - 'Tech Specs' page (CPU-Z / GPU-Z level deep hardware info)."""
import tkinter as tk
from tkinter import messagebox

from core import deepinfo as deep_mod
from core.utils import APP_NAME

from . import theme as T
from .widgets import ScrollFrame, Card, kv_row, make_button, section_title, chip


class SpecsPageMixin:
    """Mixin for PCDoctorApp: adds the `specs` page (def _page_specs).

    Data is collected by core.deepinfo inside the app background thread
    (run_in_thread) and stored in self.data["deep"].
    """

    # ------------------------------------------------------------- page
    def _page_specs(self, parent):
        frame = ScrollFrame(parent)
        self.specs_body = tk.Frame(frame.inner, bg=T.BG)
        self.specs_body.pack(fill="both", expand=True)

        toolbar = tk.Frame(self.specs_body, bg=T.BG)
        toolbar.pack(fill="x", pady=(0, 4))
        make_button(toolbar, "\U0001F504  Refresh", self._reload_specs,
                    kind="accent").pack(side="left")
        make_button(toolbar, "\U0001F4CB  Copy report",
                    self._copy_specs_report).pack(side="left", padx=8)
        self._specs_toolbar = toolbar

        section_title(self.specs_body, "Tech Specs")

        if self.data.get("deep"):
            self._fill_specs(self.data["deep"])
        else:
            tk.Label(self.specs_body, text="\n\u23F3 Collecting deep specs...",
                     bg=T.BG, fg=T.TEXT_DIM, font=T.F(13)).pack(pady=60)
            self.after(150, lambda: self._reload_specs(auto=True))
        return frame

    # ------------------------------------------------------------- data
    def _reload_specs(self, auto=False):
        if not auto and self.check_busy():
            return
        if not self.start_busy("Collecting deep specs..."):
            return

        def work():
            return deep_mod.get_deep_summary()

        def done(res):
            self.data["deep"] = res
            self.end_busy("Deep specs collected")
            self._fill_specs(res)

        def error(e):
            self.end_busy("Deep specs collection failed")
            messagebox.showerror(APP_NAME, f"Deep specs failed:\n{e}")

        self.run_in_thread(work, done, error)

    def _copy_specs_report(self):
        deep = self.data.get("deep")
        if not deep:
            messagebox.showinfo(
                APP_NAME,
                "Deep specs are not collected yet.\nClick 'Refresh' first.")
            return
        try:
            text = deep_mod.build_report_text(deep)
            self.root.clipboard_clear()
            self.root.clipboard_append(text)
            self.root.update_idletasks()
            self.set_status("\u2705 Tech Specs report copied to clipboard")
        except Exception as e:  # noqa: BLE001
            messagebox.showerror(APP_NAME, f"Could not copy to clipboard:\n{e}")

    # ------------------------------------------------------------- render
    def _fill_specs(self, deep):
        for w in self.specs_body.winfo_children():
            if w is not self._specs_toolbar:
                w.destroy()
        try:
            self._cpu_card(deep.get("cpu") or {})
            self._gpu_cards(deep.get("gpus") or [])
            self._ram_card(deep.get("ram") or {})
            tk.Label(
                self.specs_body,
                text="\u2139  'Spec table' rows come from the built-in reference "
                     "database (founders-edition figures); live readings come "
                     "from the drivers (nvidia-smi / WMI).",
                bg=T.BG, fg=T.TEXT_DIM, font=T.F(9), wraplength=900,
                justify="left").pack(anchor="w", pady=(10, 6))
        except Exception as e:  # noqa: BLE001
            tk.Label(self.specs_body, text=f"\nCould not render specs: {e}",
                     bg=T.BG, fg=T.DANGER, font=T.F(11)).pack(pady=40)

    @staticmethod
    def _mhz(value):
        try:
            return f"{int(value)} MHz" if value else "N/A"
        except Exception:
            return str(value)

    def _cpu_card(self, cpu):
        card = Card(self.specs_body, "Processor", "\u2699")
        card.pack(fill="x", pady=(0, 12))
        body = card.body
        kv_row(body, "Name", cpu.get("name", "N/A"))
        kv_row(body, "Cores / Threads",
               f"{cpu.get('cores_physical', 'N/A')} cores \u00b7 "
               f"{cpu.get('cores_logical', 'N/A')} threads")
        kv_row(body, "Base clock", cpu.get("base_clock", "N/A"))
        kv_row(body, "Max clock", cpu.get("max_clock", "N/A"))
        kv_row(body, "Advertised clock", cpu.get("advertised_clock", "N/A"))
        kv_row(body, "Socket", cpu.get("socket", "N/A"))
        kv_row(body, "L1 cache (data / inst)",
               f"{cpu.get('l1_data', 'N/A')} / "
               f"{cpu.get('l1_instruction', 'N/A')}")
        kv_row(body, "L2 cache", cpu.get("l2_cache", "N/A"))
        kv_row(body, "L3 cache", cpu.get("l3_cache", "N/A"))
        kv_row(body, "TDP", cpu.get("tdp", "N/A"))
        kv_row(body, "Architecture",
               f"{cpu.get('architecture', 'N/A')} \u00b7 "
               f"{cpu.get('bits', 'N/A')}")
        kv_row(body, "Virtualization", cpu.get("virtualization", "N/A"))

        chips_row = tk.Frame(body, bg=T.CARD)
        chips_row.pack(fill="x", pady=(10, 0))
        tk.Label(chips_row, text="Instruction sets:", bg=T.CARD,
                 fg=T.TEXT_DIM, font=T.F(10)).pack(side="left", padx=(0, 8))
        for label, ok in (
                ("SSE4.2", cpu.get("sse42")), ("AVX", cpu.get("avx")),
                ("AVX2", cpu.get("avx2")), ("AVX-512", cpu.get("avx512")),
                ("AES-NI", cpu.get("aes_ni")), ("FMA3", cpu.get("fma3"))):
            if ok:
                chip(chips_row, label).pack(side="left", padx=(0, 6))
            else:
                chip(chips_row, label, bg=T.CARD_HOVER,
                     fg=T.TEXT_DIM).pack(side="left", padx=(0, 6))

    def _gpu_cards(self, gpus):
        section_title(self.specs_body, "Graphics")
        if not gpus:
            card = Card(self.specs_body, "Graphics Card", "\U0001F3AE")
            card.pack(fill="x", pady=(0, 12))
            kv_row(card.body, "GPU", "No graphics card detected")
            return
        for i, g in enumerate(gpus, 1):
            card = Card(self.specs_body,
                        f"GPU {i} \u00b7 {g.get('name', '?')}", "\U0001F3AE")
            card.pack(fill="x", pady=(0, 12))
            body = card.body
            kv_row(body, "Name", g.get("name", "N/A"))
            kv_row(body, "Vendor",
                   f"{g.get('vendor', 'N/A')} "
                   f"({g.get('vendor_id') or 'N/A'})")
            vram = deep_mod.vram_label(g.get("vram_mb"))
            if g.get("vram_source"):
                vram += f"  (from {g['vram_source']})"
            kv_row(body, "VRAM", vram)
            driver = g.get("driver_version", "N/A")
            if g.get("driver_date"):
                driver += f"  ({g['driver_date']})"
            kv_row(body, "Driver", driver)
            res = g.get("resolution") or "N/A"
            if g.get("refresh_rate"):
                res += f" @ {g['refresh_rate']} Hz"
            kv_row(body, "Resolution / Refresh", res)
            if g.get("video_processor"):
                kv_row(body, "Video processor", g["video_processor"])

            spec = g.get("spec")
            if spec:
                sub = tk.Frame(body, bg=T.CARD)
                sub.pack(fill="x", pady=(10, 0))
                tk.Label(sub, text=f"Spec table \u00b7 matched "
                                   f"'{g.get('spec_matched')}'",
                         bg=T.CARD, fg=T.TEXT_DIM,
                         font=T.F(9, bold=True)).pack(anchor="w")
                kv_row(body, "Architecture", spec.get("architecture", "\u2014"))
                kv_row(body, "Shader cores",
                       str(spec.get("shader_cores", "\u2014")))
                kv_row(body, "Memory type", spec.get("mem_type", "\u2014"))
                kv_row(body, "Memory bus", spec.get("mem_bus", "\u2014"))
                boost = spec.get("boost_mhz")
                kv_row(body, "Boost clock",
                       f"{boost} MHz" if boost else "\u2014")
                tdp = spec.get("tdp_w")
                kv_row(body, "Board power", f"{tdp} W" if tdp else "\u2014")
            else:
                kv_row(body, "Spec table", "No entry in the local database")

            nv = g.get("nvidia")
            if nv:
                sub = tk.Frame(body, bg=T.CARD)
                sub.pack(fill="x", pady=(10, 0))
                tk.Label(sub, text="Live readings (nvidia-smi)",
                         bg=T.CARD, fg=T.TEXT_DIM,
                         font=T.F(9, bold=True)).pack(anchor="w")
                kv_row(body, "GPU clock",
                       f"{self._mhz(nv.get('clock_graphics_mhz'))} "
                       f"(max {self._mhz(nv.get('clock_graphics_max_mhz'))})")
                if nv.get("clock_graphics_default_mhz"):
                    kv_row(body, "Default app clock",
                           self._mhz(nv.get("clock_graphics_default_mhz")))
                kv_row(body, "Memory clock",
                       f"{self._mhz(nv.get('clock_mem_mhz'))} "
                       f"(max {self._mhz(nv.get('clock_mem_max_mhz'))})")
                temp = f"{nv.get('temp_c', 'N/A')} \u00b0C"
                if nv.get("temp_slowdown_c") or nv.get("temp_shutdown_c"):
                    temp += (f"  (slowdown {nv.get('temp_slowdown_c', '?')} \u00b0C, "
                             f"shutdown {nv.get('temp_shutdown_c', '?')} \u00b0C)")
                kv_row(body, "Temperature", temp)
                kv_row(body, "Power draw",
                       f"{nv.get('power_draw_w', 'N/A')} W  "
                       f"(min {nv.get('power_min_limit_w', '?')} / "
                       f"default {nv.get('power_default_limit_w', '?')} / "
                       f"max {nv.get('power_max_limit_w', '?')} W)")
                kv_row(body, "PCIe link",
                       f"Gen {nv.get('pcie_gen_current', 'N/A')} "
                       f"x{nv.get('pcie_width_current', 'N/A')} "
                       f"(max Gen {nv.get('pcie_gen_max', 'N/A')} "
                       f"x{nv.get('pcie_width_max', 'N/A')})")
                if nv.get("fan_percent") is not None:
                    kv_row(body, "Fan", f"{nv['fan_percent']} %")
                if nv.get("util_gpu_percent") is not None:
                    kv_row(body, "GPU utilization",
                           f"{nv['util_gpu_percent']} %")
                if nv.get("vram_used_mb") is not None:
                    used = nv.get("vram_used_mb")
                    total = nv.get("vram_total_mb")
                    kv_row(body, "VRAM usage",
                           f"{used} MB / {total} MB" if total
                           else f"{used} MB")
                if nv.get("pstate"):
                    kv_row(body, "Performance state", nv["pstate"])
                if nv.get("cuda_version"):
                    kv_row(body, "CUDA version", nv["cuda_version"])
                if nv.get("vbios"):
                    kv_row(body, "VBIOS", nv["vbios"])

    def _ram_card(self, ram):
        section_title(self.specs_body, "Memory")
        card = Card(self.specs_body, "Memory (RAM)", "\U0001F4BF")
        card.pack(fill="x", pady=(0, 12))
        body = card.body
        if ram.get("total_gb"):
            kv_row(body, "Total installed", f"{ram['total_gb']} GB")
        kv_row(body, "Modules", ram.get("sticks") or "N/A")
        if ram.get("slots"):
            kv_row(body, "Slots", ram["slots"])
            if ram.get("free_slots") is not None:
                kv_row(body, "Free slots", ram["free_slots"])
        if ram.get("speeds"):
            kv_row(body, "Configured speeds",
                   ", ".join(f"{s} MHz" for s in ram["speeds"]))
        for i, m in enumerate(ram.get("modules") or [], 1):
            size = f"{m['size_gb']} GB" if m.get("size_gb") else "N/A"
            spd = m.get("configured_mhz") or m.get("speed_mhz")
            kv_row(body, f"Stick {i} \u00b7 {m.get('slot', '?')}",
                   f"{size} {m.get('type', 'N/A')} \u00b7 "
                   f"{self._mhz(spd) if spd else 'N/A'} \u00b7 "
                   f"{m.get('manufacturer', 'N/A')} \u00b7 "
                   f"{m.get('part_number', 'N/A')}")
        if ram.get("mismatch"):
            tk.Label(body, text="\u26A0  " + ram["mismatch"], bg=T.CARD,
                     fg=T.WARN, font=T.F(10), wraplength=820,
                     justify="left").pack(anchor="w", pady=(8, 0))
        if not ram.get("modules") and not ram.get("total_gb"):
            kv_row(body, "Details",
                   "Per-module details unavailable on this system")
