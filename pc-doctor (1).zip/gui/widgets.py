"""PC Doctor Pro - widget riutilizzabili (card, scroll, barre, pulsanti)."""
import os
import tkinter as tk
from tkinter import ttk

from . import theme as T


class ScrollFrame(tk.Frame):
    """Frame scrollabile con canvas e rotellina del mouse."""

    def __init__(self, parent, bg=T.BG, **kwargs):
        super().__init__(parent, bg=bg, **kwargs)
        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0, bd=0)
        self.vbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview,
                                  style="PDoctor.Vertical.TScrollbar")
        self.inner = tk.Frame(self.canvas, bg=bg)
        self.inner.bind("<Configure>", self._on_inner_configure)
        self.canvas.bind("<Configure>", self._on_canvas_configure)
        self.canvas.create_window((0, 0), window=self.inner, anchor="nw", tags="inner")
        self.canvas.configure(yscrollcommand=self.vbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.vbar.pack(side="right", fill="y")
        # Rotellina
        self.canvas.bind_all("<MouseWheel>", self._on_wheel_windows)
        self.canvas.bind_all("<Button-4>", self._on_wheel_linux)
        self.canvas.bind_all("<Button-5>", self._on_wheel_linux)
        self._bg = bg

    def _on_inner_configure(self, _e):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas_configure(self, e):
        self.canvas.itemconfigure("inner", width=e.width)

    def _on_wheel_windows(self, e):
        try:
            self.canvas.yview_scroll(int(-e.delta / 120), "units")
        except tk.TclError:
            pass

    def _on_wheel_linux(self, e):
        try:
            self.canvas.yview_scroll(-1 if e.num == 4 else 1, "units")
        except tk.TclError:
            pass


class Card(tk.Frame):
    """Card con titolo e corpo, stile scuro."""

    def __init__(self, parent, title=None, icon="", bg=T.CARD, padding=16, **kwargs):
        super().__init__(parent, bg=bg, highlightbackground=T.BORDER,
                         highlightthickness=1, **kwargs)
        header = tk.Frame(self, bg=bg)
        header.pack(fill="x", padx=padding, pady=(padding, 4 if title else 0))
        if title:
            text = (icon + "  " + title) if icon else title
            tk.Label(header, text=text, bg=bg, fg=T.ACCENT,
                     font=T.F(12, bold=True)).pack(anchor="w")
        self.body = tk.Frame(self, bg=bg)
        self.body.pack(fill="both", expand=True, padx=padding, pady=(4, padding))


def kv_row(parent, key, value, bg=T.CARD, key_fg=T.TEXT_DIM, val_fg=T.TEXT, wrap=430):
    """Riga chiave-valore all'interno di una card."""
    row = tk.Frame(parent, bg=bg)
    row.pack(fill="x", pady=2)
    tk.Label(row, text=key, bg=bg, fg=key_fg, font=T.F(10),
             anchor="w").pack(side="left", fill="x", expand=True)
    lbl = tk.Label(row, text=str(value), bg=bg, fg=val_fg, font=T.F(10, semibold=True),
                   anchor="e", wraplength=wrap, justify="right")
    lbl.pack(side="right")
    return lbl


def metric_bar(parent, label, bg=T.CARD, color=None, show_percent=True):
    """Etichetta + progressbar + percentuale. Ritorna (var, label_var)."""
    row = tk.Frame(parent, bg=bg)
    row.pack(fill="x", pady=4)
    var = tk.DoubleVar(value=0)
    txt_var = tk.StringVar(value="")
    tk.Label(row, text=label, bg=bg, fg=T.TEXT, font=T.F(10),
             anchor="w").pack(side="top", fill="x")
    sub = tk.Frame(row, bg=bg)
    sub.pack(fill="x")
    bar = ttk.Progressbar(sub, variable=var, maximum=100,
                          style=(color or "Accent") + ".Horizontal.TProgressbar")
    bar.pack(side="left", fill="x", expand=True, pady=6)
    if show_percent:
        tk.Label(sub, textvariable=txt_var, bg=bg, fg=T.TEXT_DIM,
                 font=T.F(10), width=7, anchor="e").pack(side="right")
    return var, txt_var


def make_button(parent, text, command, kind="normal", width=None, disabled=False):
    """Pulsante flat con stile dell'app."""
    colors = {
        "accent": (T.ACCENT_BG, T.ACCENT, T.ACCENT),
        "normal": (T.CARD, T.TEXT, T.ACCENT),
        "warn": ("#33230a", T.WARN, T.WARN),
        "danger": ("#331414", T.DANGER, T.DANGER),
        "ghost": (T.BG, T.TEXT_DIM, T.TEXT),
    }
    bg, fg, hover = colors.get(kind, colors["normal"])
    if disabled:
        bg, fg, hover = T.CARD, T.TEXT_DIM, T.CARD_HOVER

    def on_enter(e):
        btn.configure(bg=hover)

    def on_leave(e):
        btn.configure(bg=bg)

    btn = tk.Button(
        parent, text=text, command=command, bg=bg, fg=fg,
        activebackground=hover, activeforeground=fg,
        font=T.F(10, semibold=True), relief="flat", bd=0,
        padx=14, pady=8, cursor="hand2", width=width,
    )
    if not disabled:
        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)
    return btn


class ImageBox(tk.Label):
    """Mostra un'immagine PNG con PIL; se PIL non c'e', mostra un badge colorato."""

    def __init__(self, parent, path=None, width=340, height=180, fallback_text="",
                 fallback_color=T.ACCENT, bg=T.CARD, **kwargs):
        self._bg = bg
        self._w, self._h = width, height
        self._fallback_text = fallback_text
        self._fallback_color = fallback_color
        super().__init__(parent, bg=bg, **kwargs)
        self.set_image(path)

    def set_image(self, path):
        if not path or not os.path.exists(path):
            self._show_fallback()
            return
        try:
            from PIL import Image, ImageTk
            img = Image.open(path)
            ratio = max(self._w / img.width, self._h / img.height)
            img = img.resize(
                (int(img.width * ratio) + 1, int(img.height * ratio) + 1),
                Image.LANCZOS,
            )
            left = (img.width - self._w) // 2
            top = (img.height - self._h) // 2
            img = img.crop((left, top, left + self._w, top + self._h))
            self._photo = ImageTk.PhotoImage(img)
            self.configure(image=self._photo, text="")
        except Exception:
            self._show_fallback()

    def _show_fallback(self):
        self.configure(
            text=(self._fallback_text or "GPU"),
            font=T.F(16, bold=True), fg=self._fallback_color,
            justify="center",
        )


def section_title(parent, text, bg=T.BG):
    tk.Label(parent, text=text, bg=bg, fg=T.TEXT, font=T.F(15, bold=True),
             anchor="w").pack(fill="x", pady=(18, 8))


class LineChart(tk.Canvas):
    """Grafico a linea in tempo reale (stile HWiNFO)."""

    def __init__(self, parent, title, color=T.ACCENT, unit="%",
                 max_val=100, height=150, bg=T.CARD, **kwargs):
        super().__init__(parent, bg=bg, height=height, highlightthickness=0, **kwargs)
        self._color = color
        self._title = title
        self._unit = unit
        self._max = max_val
        self._bg = bg
        from collections import deque
        self.data = deque(maxlen=90)
        self.min_v = None
        self.max_v = None
        self.bind("<Configure>", lambda e: self.redraw())

    def push(self, value):
        if value is None:
            return
        self.data.append(value)
        vals = list(self.data)
        self.min_v = min(vals)
        self.max_v = max(vals)
        self.redraw()

    def redraw(self):
        self.delete("all")
        w = max(self.winfo_width(), 10)
        h = max(self.winfo_height(), 10)
        pad = 26
        # titolo e valore attuale
        self.create_text(10, 8, anchor="w", text=self._title,
                         fill=T.TEXT_DIM, font=T.F(9))
        if self.data:
            cur = list(self.data)[-1]
            unit_txt = f" MHz" if self._unit == "MHz" else f"{self._unit}"
            self.create_text(
                w - 10, 8, anchor="e", text=f"{cur:.0f}{unit_txt}",
                fill=self._color, font=T.F(11, bold=True))
        # griglia
        for i in range(1, 4):
            y = pad + (h - pad - 14) * i / 4
            self.create_line(0, y, w, y, fill=T.BORDER, dash=(2, 4))
        # linea dati
        n = len(self.data)
        if n >= 2:
            usable_h = h - pad - 14
            top = max(self.max_v, self._max if self._unit == "%" else self.max_v) or 1
            pts = []
            for i, v in enumerate(self.data):
                x = 10 + (w - 20) * i / (n - 1)
                y = pad + usable_h * (1 - min(v, top) / top)
                pts += [x, y]
            self.create_line(*pts, fill=self._color, width=2, smooth=True)
            # riempimento sotto la linea
            fill_pts = pts + [pts[-2], h - 14, pts[0], h - 14]
            self.create_polygon(*fill_pts, fill=self._color, outline="",
                                stipple="gray20")
        # min/max
        if self.min_v is not None:
            self.create_text(10, h - 12, anchor="w",
                             text=f"min {self.min_v:.0f}  max {self.max_v:.0f}",
                             fill=T.TEXT_DIM, font=T.F(8))


def chip(parent, text, bg=T.ACCENT_BG, fg=T.ACCENT):
    """Etichetta pillola di stato."""
    return tk.Label(parent, text=f" {text} ", bg=bg, fg=fg,
                    font=T.F(9, bold=True), padx=8, pady=3)


def mini_core_bar(parent, index, bg=T.CARD):
    """Cella compatta per l'utilizzo di un singolo core."""
    var = tk.DoubleVar(value=0)
    cell = tk.Frame(parent, bg=bg)
    bar = ttk.Progressbar(cell, variable=var, maximum=100, length=54,
                          style="Accent.Horizontal.TProgressbar")
    bar.pack()
    tk.Label(cell, text=f"C{index}", bg=bg, fg=T.TEXT_DIM,
             font=T.F(7)).pack()
    return cell, var


def big_stat(parent, label, value, color=T.ACCENT, bg=T.CARD, sub=""):
    """Numero grande con etichetta (per benchmark e riepilogo)."""
    box = tk.Frame(parent, bg=bg)
    tk.Label(box, text=label, bg=bg, fg=T.TEXT_DIM, font=T.F(10)).pack(anchor="w")
    tk.Label(box, text=value, bg=bg, fg=color, font=T.F(22, bold=True),
             anchor="w").pack(anchor="w")
    if sub:
        tk.Label(box, text=sub, bg=bg, fg=T.TEXT_DIM, font=T.F(9)).pack(anchor="w")
    return box
