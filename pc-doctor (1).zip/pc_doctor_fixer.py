#!/usr/bin/env python3
"""
PC Doctor Pro - One-Click Repair Tool (standalone, stdlib only)
================================================================
Run this file when ANYTHING goes wrong. It fixes, installs, cleans,
checks and launches - all by itself:

    python pc_doctor_fixer.py              -> fix everything + menu
    python pc_doctor_fixer.py --auto       -> fix everything, no questions
    python pc_doctor_fixer.py --check-only -> diagnose only, change nothing
    python pc_doctor_fixer.py --no-launch  -> do not start the app at the end
    python pc_doctor_fixer.py --repl-fix   -> also disable the new Python REPL
    python pc_doctor_fixer.py --json       -> machine-readable summary

What it does, in order:
  1. Checks the Python environment (version, tkinter, pip)
  2. Installs / repairs missing dependencies (psutil, Pillow)
  3. Cleans corrupted caches (__pycache__, logo cache)
  4. Verifies that every app file compiles (finds corrupted installs)
  5. Analyses the crash log (pcdoctor_error.log) and explains the last error
  6. Applies Windows quick fixes (Python REPL crash, missing launchers)
  7. Self-tests all app modules
  8. Starts PC Doctor Pro

Double-click FIX_PC_DOCTOR.bat on Windows to run this with one click.

License: MIT - see the LICENSE file.
"""
from __future__ import annotations

import argparse
import datetime
import json
import os
import platform
import py_compile
import re
import shutil
import subprocess
import sys

APP_NAME = "PC Doctor Pro"
FIXER_VERSION = "1.1"
APP_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_FILE = os.path.join(APP_DIR, "pcdoctor_error.log")
ENTRY_CANDIDATES = ("main.py", "pcdoctor.py")
DEPS = ["psutil>=5.9", "Pillow>=10.0"]

# ----------------------------------------------------------------- output
_TTY = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()
if os.name == "nt":  # enable ANSI on Windows 10+ consoles
    os.system("")


def _c(code: str, text: str) -> str:
    return f"\033[{code}m{text}\033[0m" if _TTY else text


def p_ok(msg):   print(_c("92", "  [OK]   ") + msg)
def p_fix(msg):  print(_c("96", "  [FIX]  ") + msg)
def p_warn(msg): print(_c("93", "  [WARN] ") + msg)
def p_fail(msg): print(_c("91", "  [FAIL] ") + msg)
def p_info(msg): print(_c("90", "  [i]    ") + msg)


def head(title: str) -> None:
    pad = "-" * max(0, 50 - len(title))
    print("\n" + _c("1;36", f"--- {title} {pad}"))


RESULTS = {"fixer_version": FIXER_VERSION, "when": "", "steps": [],
           "fixed": 0, "warnings": 0, "errors": 0}


def record(step: str, status: str, detail: str = "") -> None:
    """status: ok | fixed | warning | error"""
    RESULTS["steps"].append({"step": step, "status": status, "detail": detail})
    if status == "fixed":
        RESULTS["fixed"] += 1
    elif status == "warning":
        RESULTS["warnings"] += 1
    elif status == "error":
        RESULTS["errors"] += 1


def banner() -> None:
    print(_c("1;92", "=" * 58))
    print(_c("1;92", f"   {APP_NAME}  -  ONE-CLICK REPAIR TOOL  v{FIXER_VERSION}"))
    print(_c("1;92", "   It fixes, installs, cleans, checks and launches."))
    print(_c("1;92", "=" * 58))
    print(f"   Folder : {APP_DIR}")
    print(f"   Python : {platform.python_version()}  ({platform.system()})")


def run(cmd, timeout=120):
    """Runs a command; returns (returncode, stdout, stderr). Never raises."""
    try:
        res = subprocess.run(cmd, capture_output=True, text=True,
                             timeout=timeout, encoding="utf-8",
                             errors="ignore")
        return res.returncode, (res.stdout or "").strip(), \
            (res.stderr or "").strip()
    except FileNotFoundError:
        return -1, "", f"command not found: {cmd[0] if cmd else cmd}"
    except subprocess.TimeoutExpired:
        return -2, "", f"timeout after {timeout}s"
    except Exception as exc:
        return -1, "", str(exc)


# ------------------------------------------------------------ 1. environment
def check_environment() -> bool:
    """Returns True when tkinter is usable."""
    head("STEP 1/7 - Environment check")
    tkinter_ok = True

    v = sys.version_info
    if v < (3, 9):
        p_fail(f"Python {v.major}.{v.minor} is too old. Install Python 3.10+ "
               f"from python.org (tick 'Add to PATH').")
        record("python-version", "error", f"{v.major}.{v.minor}")
    else:
        p_ok(f"Python {v.major}.{v.minor}.{v.micro} (64-bit: "
             f"{platform.machine()})")
        record("python-version", "ok")

    try:
        import tkinter  # noqa: F401
        p_ok("tkinter (GUI library) is present")
        record("tkinter", "ok")
    except Exception as exc:
        tkinter_ok = False
        p_fail("tkinter is MISSING - the graphical interface cannot start.")
        if os.name == "nt":
            p_info("Fix: reinstall Python from python.org and keep "
                   "'tcl/tk and IDLE' ticked in the installer.")
        else:
            p_info("Fix: sudo apt install python3-tk  (Debian/Ubuntu)")
        record("tkinter", "error", str(exc))

    rc, out, _ = run([sys.executable, "-m", "pip", "--version"])
    if rc == 0:
        p_ok(f"pip available ({out.splitlines()[0][:60]})")
        record("pip", "ok")
    else:
        p_warn("pip is not available - dependencies cannot be auto-installed.")
        record("pip", "warning")
    return tkinter_ok


# ------------------------------------------------------------ 2. dependencies
def install_dependencies(check_only: bool) -> None:
    head("STEP 2/7 - Dependencies (psutil, Pillow)")
    missing = []
    for mod, pipname in (("psutil", "psutil"), ("PIL", "Pillow")):
        try:
            __import__(mod)
            p_ok(f"{pipname} already installed")
        except Exception:
            missing.append(pipname)

    if not missing:
        record("dependencies", "ok", "all present")
        if check_only:
            return
        rc, _, err = run([sys.executable, "-m", "pip", "install", "--upgrade",
                          "--quiet"] + DEPS)
        if rc == 0:
            p_ok("Dependencies refreshed (upgraded when a newer "
                 "version exists)")
            record("dependencies-upgrade", "ok")
        else:
            p_warn("Could not upgrade (maybe offline) - but the existing "
                   "versions work.")
            record("dependencies-upgrade", "warning", err[-120:])
        return

    if check_only:
        p_fail(f"MISSING: {', '.join(missing)} (run without --check-only "
               f"to install them)")
        record("dependencies", "error", "missing " + ",".join(missing))
        return

    p_info(f"Installing: {', '.join(missing)} ...")
    rc, out, err = run([sys.executable, "-m", "pip", "install"] + DEPS,
                       timeout=300)
    if rc != 0:
        p_info("Standard install failed, retrying with --user ...")
        rc, out, err = run([sys.executable, "-m", "pip", "install", "--user"]
                           + DEPS, timeout=300)
    if rc == 0:
        p_ok("Dependencies installed")
        record("dependencies", "fixed", ",".join(missing))
    else:
        p_fail("Automatic install failed. Fix manually with:")
        p_info(f"    {sys.executable} -m pip install {' '.join(DEPS)}")
        p_info("(check your internet connection)")
        record("dependencies", "error", err[-160:])


# ------------------------------------------------------------ 3. cleanup
def cleanup_caches() -> None:
    head("STEP 3/7 - Cache cleanup")
    removed = 0
    for root_dir in (APP_DIR,
                     os.path.join(APP_DIR, "core"),
                     os.path.join(APP_DIR, "gui")):
        cache = os.path.join(root_dir, "__pycache__")
        if os.path.isdir(cache):
            try:
                shutil.rmtree(cache)
                removed += 1
            except Exception:
                pass
    logo_cache = os.path.join(APP_DIR, "assets", "cache")
    if os.path.isdir(logo_cache):
        for name in os.listdir(logo_cache):
            try:
                os.remove(os.path.join(logo_cache, name))
                removed += 1
            except Exception:
                pass
    if removed:
        p_fix(f"Removed {removed} stale cache items (rebuilt automatically)")
        record("cleanup", "fixed", f"{removed} items")
    else:
        p_ok("Caches already clean")
        record("cleanup", "ok")


# ------------------------------------------------------------ 4. integrity
def verify_files() -> None:
    head("STEP 4/7 - File integrity")
    targets = []
    for folder in ("", "core", "gui"):
        base = os.path.join(APP_DIR, folder) if folder else APP_DIR
        if not os.path.isdir(base):
            continue
        for name in sorted(os.listdir(base)):
            if name.endswith(".py") and not name.startswith("_build"):
                targets.append(os.path.join(base, name))
    broken = []
    for path in targets:
        try:
            py_compile.compile(path, doraise=True)
        except Exception as exc:
            broken.append((os.path.relpath(path, APP_DIR), str(exc)[-100:]))
    if broken:
        for name, why in broken:
            p_fail(f"CORRUPTED FILE: {name}  -> {why}")
        p_info("Fix: re-extract pc-doctor.zip completely (or re-download it).")
        record("integrity", "error", f"{len(broken)} broken file(s)")
    else:
        p_ok(f"All {len(targets)} Python files compile correctly")
        record("integrity", "ok", f"{len(targets)} files")


# ------------------------------------------------------------ 5. crash log
CRASH_HINTS = [
    ("no module named 'psutil'",
     "Missing psutil - STEP 2 above just installed it. Restart the app."),
    ("no module named 'pil'",
     "Missing Pillow - STEP 2 above just installed it. Restart the app."),
    ("_pyrepl",
     "Python's new interactive REPL crashed. Use menu option [2] (or "
     "--repl-fix) to switch to the stable classic REPL."),
    ("permissionerror", "Permission problem - right-click and 'Run as "
     "administrator'."),
    ("access is denied", "Permission problem - run as administrator."),
    ("tclerror", "Display/GUI problem - on Linux you need a desktop "
     "environment; on Windows reinstall Python keeping tcl/tk."),
    ("nvidia-smi", "nvidia-smi not found - NVIDIA live stats stay disabled; "
     "install/update the GeForce driver (app still works)."),
    ("winerror 2", "A file was not found - re-extract the zip completely, "
     "do not move single files out of the folder."),
]


def analyze_crash_log() -> str:
    head("STEP 5/7 - Crash log analysis")
    if not os.path.exists(LOG_FILE):
        p_ok("No crash log found - the app never crashed here. "
             "Nothing to analyse.")
        record("crash-log", "ok", "empty")
        return ""

    try:
        with open(LOG_FILE, "r", encoding="utf-8", errors="ignore") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - 8000))
            content = f.read()
    except Exception as exc:
        p_warn(f"Could not read the crash log: {exc}")
        record("crash-log", "warning")
        return ""

    entries = re.split(r"\n(?=\[\d{2}/\d{2}/\d{4} )", content)
    last = entries[-1].strip() if entries else content.strip()
    when = ""
    m = re.match(r"\[([^\]]+)\]", last)
    if m:
        when = m.group(1)
    shown = last[:1000] + ("\n   ... (truncated)" if len(last) > 1000 else "")
    print(_c("90", "   Last recorded error"
                 + (f" ({when})" if when else "") + ":"))
    for line in shown.splitlines():
        print(_c("90", "   | " + line))

    low = last.lower()
    matched = False
    for needle, hint in CRASH_HINTS:
        if needle in low:
            p_info("Likely cause: " + hint)
            matched = True
            break
    if not matched:
        p_info("Unrecognised error - if it keeps happening, send the log "
               "lines above to who gave you this app.")
    record("crash-log", "ok", f"1 entry ({when})")
    return last


# ------------------------------------------------------------ 6. windows fixes
RUN_WINDOWS_BAT = """@echo off
title PC Doctor Pro
cd /d "%~dp0"

echo ============================================
echo   PC Doctor Pro - starting...
echo ============================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python not found! Install Python from python.org
    echo         and check "Add Python to PATH" during setup.
    pause
    exit /b 1
)

echo Checking dependencies (psutil, Pillow)...
python -c "import psutil" >nul 2>nul
if errorlevel 1 (
    echo Installing missing dependencies...
    python -m pip install psutil Pillow
)

echo Starting PC Doctor Pro...
python pcdoctor.py
if errorlevel 1 pause
"""

FIX_BAT = """@echo off
title PC Doctor Pro - Repair Tool
cd /d "%~dp0"
python pc_doctor_fixer.py
echo.
pause
"""


def windows_quick_fixes(args, last_error: str, tkinter_ok: bool) -> None:
    head("STEP 6/7 - Quick fixes")
    if not os.name == "nt":
        p_info("Skipped (Windows-only fixes) - this is "
               f"{platform.system()}.")
        record("quick-fixes", "ok", "not windows")
        return

    # 6a. Python REPL crash guard ------------------------------------
    repl_wanted = (
        args.repl_fix
        or "_pyrepl" in last_error.lower()
        or (args.auto and sys.version_info >= (3, 13))
    )
    if os.environ.get("PYTHON_BASIC_REPL") == "1":
        p_ok("Python REPL crash guard already active (PYTHON_BASIC_REPL=1)")
        record("repl-guard", "ok")
    elif repl_wanted:
        if args.check_only:
            p_info("Would enable PYTHON_BASIC_REPL=1 (stable classic REPL).")
            record("repl-guard", "warning", "check-only")
        else:
            rc, _, err = run(["setx", "PYTHON_BASIC_REPL", "1"])
            if rc == 0:
                p_fix("Python REPL crash guard ENABLED "
                      "(PYTHON_BASIC_REPL=1). The >>> terminal of Python will "
                      "use the stable classic shell - no more reader.py "
                      "crashes. Open a NEW terminal to apply.")
                p_info("Undo anytime with: reg delete "
                       "\"HKCU\\Environment\" /v PYTHON_BASIC_REPL /f")
                record("repl-guard", "fixed")
            else:
                p_warn(f"Could not set the variable ({err[-80:]}). Set it "
                       "manually: setx PYTHON_BASIC_REPL 1")
                record("repl-guard", "warning")
    else:
        p_ok("Python REPL: no crash detected, nothing to change")

    # 6b. launchers ----------------------------------------------------
    bat_dir = APP_DIR
    run_bat = os.path.join(bat_dir, "run_windows.bat")
    fix_bat = os.path.join(bat_dir, "FIX_PC_DOCTOR.bat")
    try:
        if not os.path.exists(run_bat):
            with open(run_bat, "w", encoding="utf-8") as f:
                f.write(RUN_WINDOWS_BAT)
            p_fix("Recreated missing run_windows.bat")
            record("run_windows.bat", "fixed")
        if not os.path.exists(fix_bat):
            with open(fix_bat, "w", encoding="utf-8") as f:
                f.write(FIX_BAT)
            p_fix("Recreated missing FIX_PC_DOCTOR.bat")
            record("fix_bat", "fixed")
    except Exception as exc:
        p_warn(f"Could not write launcher files: {exc}")
        record("launchers", "warning")


# ------------------------------------------------------------ 7. self-test
SELF_TEST_MODULES = [
    "core.utils", "core.system_info", "core.gpu", "core.drivers",
    "core.maintenance", "core.benchmark", "core.admin", "core.report",
    "core.tuning", "core.deepinfo", "gui.theme", "gui.widgets",
    "gui.page_specs", "gui.app",
]


def self_test() -> None:
    head("STEP 7/7 - Self test")
    sys.path.insert(0, APP_DIR)
    failed = []
    for mod in SELF_TEST_MODULES:
        try:
            __import__(mod)
        except Exception:
            failed.append(mod)
    if failed:
        p_fail("Modules that failed to load: " + ", ".join(failed))
        record("self-test", "error", ",".join(failed))
    else:
        p_ok(f"All {len(SELF_TEST_MODULES)} app modules load correctly")

    try:
        import psutil
        mem = psutil.virtual_memory()
        p_ok(f"Hardware read test: {psutil.cpu_count(logical=True)} logical "
             f"cores, {mem.total / (1024**3):.1f} GB RAM")
        record("hardware-read", "ok")
    except Exception as exc:
        p_warn(f"Hardware read test failed: {exc}")
        record("hardware-read", "warning", str(exc)[-80:])


# ------------------------------------------------------------ launch
def find_entry():
    for name in ENTRY_CANDIDATES:
        p = os.path.join(APP_DIR, name)
        if os.path.exists(p):
            return p
    return None


def launch_app(tkinter_ok: bool, check_only: bool, no_launch: bool) -> None:
    head("Launch")
    if check_only:
        p_info("Check-only mode: nothing launched.")
        return
    if no_launch:
        p_info("Launch skipped (--no-launch). Start the app with "
               "run_windows.bat or: python main.py")
        return
    if not tkinter_ok:
        p_fail("Cannot launch: tkinter is missing (see STEP 1 fix).")
        return
    if sys.platform.startswith("linux") and not os.environ.get("DISPLAY"):
        p_warn("No graphical display detected - start the app from a "
               "desktop session.")
        return
    entry = find_entry()
    if not entry:
        p_fail("pcdoctor.py / main.py not found in " + APP_DIR)
        record("launch", "error")
        return
    try:
        subprocess.Popen([sys.executable, entry], cwd=APP_DIR,
                         close_fds=True)
        p_ok(f"{APP_NAME} started ({os.path.basename(entry)})")
        record("launch", "ok")
    except Exception as exc:
        p_fail(f"Launch failed: {exc}")
        record("launch", "error", str(exc)[-100:])


# ------------------------------------------------------------ menu
def create_desktop_shortcut() -> None:
    desktop = os.path.join(os.path.expanduser("~"), "Desktop")
    if not os.path.isdir(desktop):
        desktop = os.path.join(os.path.expanduser("~"), "Scrivania")
    if not os.path.isdir(desktop):
        desktop = os.path.expanduser("~")
    target = os.path.join(desktop, "PC Doctor Pro.bat")
    try:
        with open(target, "w", encoding="utf-8") as f:
            f.write(f'@echo off\r\ncd /d "{APP_DIR}"\r\n'
                    f'start "" pythonw main.py\r\n')
        p_fix(f"Desktop shortcut created: {target}")
        record("shortcut", "fixed")
    except Exception as exc:
        p_fail(f"Could not create the shortcut: {exc}")


def menu(tkinter_ok: bool, last_error: str) -> None:
    while True:
        print()
        print(_c("1;96", "  What now?"))
        print("   [1] Start PC Doctor Pro")
        print("   [2] Fix the Python >>> terminal crash (classic REPL)")
        print("   [3] Create desktop shortcut")
        print("   [4] Show the last crash report again")
        print("   [0] Exit")
        try:
            choice = input(_c("1;96", "  Select an option: ")).strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if choice == "1":
            launch_app(tkinter_ok, check_only=False, no_launch=False)
        elif choice == "2":
            args = argparse.Namespace(repl_fix=True, check_only=False,
                                      auto=False, no_launch=True, json=False)
            windows_quick_fixes(args, last_error, tkinter_ok)
        elif choice == "3":
            if os.name == "nt":
                create_desktop_shortcut()
            else:
                p_info("Shortcut creation is a Windows feature.")
        elif choice == "4":
            if last_error:
                print(_c("90", "   " + last_error[:1500]))
            else:
                p_info("No crash recorded.")
        elif choice == "0":
            return


# ------------------------------------------------------------ main
def main() -> int:
    parser = argparse.ArgumentParser(
        prog="pc_doctor_fixer",
        description=f"{APP_NAME} one-click repair tool: installs "
                    "dependencies, cleans, verifies, fixes and launches.")
    parser.add_argument("--auto", action="store_true",
                        help="fix everything and skip the final menu")
    parser.add_argument("--check-only", action="store_true",
                        help="diagnose without changing anything")
    parser.add_argument("--no-launch", action="store_true",
                        help="do not start the app at the end")
    parser.add_argument("--repl-fix", action="store_true",
                        help="disable the new Python REPL (stable classic "
                             "shell)")
    parser.add_argument("--json", action="store_true",
                        help="print a JSON summary at the end")
    args = parser.parse_args()

    banner()
    RESULTS["when"] = datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    RESULTS["check_only"] = bool(args.check_only)

    tkinter_ok = check_environment()
    install_dependencies(check_only=args.check_only)
    if not args.check_only:
        cleanup_caches()
    else:
        head("STEP 3/7 - Cache cleanup")
        p_info("Skipped (--check-only)")
    verify_files()
    last_error = analyze_crash_log()
    windows_quick_fixes(args, last_error, tkinter_ok)
    self_test()

    print()
    head("Summary")
    color = "92" if RESULTS["errors"] == 0 else "91"
    print(_c(color, f"   Fixed: {RESULTS['fixed']}   |   "
                    f"Warnings: {RESULTS['warnings']}   |   "
                    f"Errors: {RESULTS['errors']}"))
    if RESULTS["errors"] == 0 and RESULTS["warnings"] == 0:
        print(_c("92", "   Everything is fine - PC Doctor Pro is ready."))
    elif RESULTS["errors"] == 0:
        print(_c("93", "   App is usable, but read the warnings above."))

    launch_app(tkinter_ok, check_only=args.check_only,
               no_launch=args.no_launch or args.check_only)

    if args.json:
        print(json.dumps(RESULTS, indent=2))

    if not args.auto and not args.check_only and _TTY:
        menu(tkinter_ok, last_error)

    if RESULTS["errors"]:
        return 2
    if RESULTS["warnings"]:
        return 1
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nInterrupted.")
        sys.exit(130)
