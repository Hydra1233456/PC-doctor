"""PC Doctor Pro - full hardware and system analysis."""
import os
import re
import socket
import datetime
import platform

import psutil

from .utils import (
    IS_WINDOWS, IS_LINUX, IS_MACOS, run_cmd, ps_json, parse_wmi_date, gb, fmt_bytes
)


def _cpu_name_windows():
    try:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"HARDWARE\DESCRIPTION\System\CentralProcessor\0",
        )
        name, _ = winreg.QueryValueEx(key, "ProcessorNameString")
        winreg.CloseKey(key)
        return name.strip()
    except Exception:
        return None


def _cpu_name_linux():
    try:
        with open("/proc/cpuinfo", "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                if "model name" in line:
                    return line.split(":", 1)[1].strip()
    except Exception:
        pass
    return None


def _cpu_name_macos():
    rc, out, _ = run_cmd(["sysctl", "-n", "machdep.cpu.brand_string"])
    return out if rc == 0 and out else None


def get_cpu_name():
    for fn in (_cpu_name_windows, _cpu_name_linux, _cpu_name_macos):
        name = fn()
        if name:
            return re.sub(r"\s+", " ", name)
    return platform.processor() or platform.machine() or "Sconosciuto"


def _cpu_windows_extra():
    extra = {}
    data = ps_json(
        "Get-CimInstance Win32_Processor | Select-Object Name, Manufacturer, "
        "MaxClockSpeed, CurrentClockSpeed, NumberOfCores, NumberOfLogicalProcessors, "
        "LoadPercentage, L2CacheSize, L3CacheSize, SocketDesignation, Caption, "
        "VirtualizationFirmwareEnabled, Description"
    )
    if data:
        d = data[0]
        extra["vendor"] = d.get("Manufacturer")
        try:
            extra["base_mhz"] = int(d.get("MaxClockSpeed") or 0)
        except Exception:
            extra["base_mhz"] = 0
        try:
            extra["current_mhz"] = int(d.get("CurrentClockSpeed") or 0)
        except Exception:
            extra["current_mhz"] = 0
        l2 = int(d.get("L2CacheSize") or 0)
        l3 = int(d.get("L3CacheSize") or 0)
        if l2:
            extra["l2_cache"] = f"{round(l2 / 1024, 1)} MB"
        if l3:
            extra["l3_cache"] = f"{round(l3 / 1024, 1)} MB" if l3 >= 1024 else f"{l3} KB"
        if d.get("SocketDesignation"):
            extra["socket"] = d.get("SocketDesignation")
        if d.get("Caption"):
            extra["caption"] = d.get("Caption")
        if d.get("Description"):
            extra["description"] = d.get("Description")
        extra["virtualization"] = bool(d.get("VirtualizationFirmwareEnabled"))
    return extra


def _cpu_linux_extra():
    extra = {}
    rc, out, _ = run_cmd(["lscpu"])
    if rc == 0:
        for line in out.splitlines():
            low = line.lower()
            if low.startswith("model name:"):
                extra["name"] = line.split(":", 1)[1].strip()
            elif low.startswith("cpu max mhz:"):
                try:
                    extra["max_ghz"] = round(float(line.split(":")[1]) / 1000, 2)
                except Exception:
                    pass
            elif low.startswith("vendor id:"):
                extra["vendor"] = line.split(":", 1)[1].strip()
            elif low.startswith("l3 cache:"):
                extra["l3_cache"] = line.split(":", 1)[1].strip()
            elif low.startswith("l2 cache:"):
                extra["l2_cache"] = line.split(":", 1)[1].strip()
            elif low.startswith("virtualization:"):
                extra["virtualization"] = line.split(":", 1)[1].strip()
            elif low.startswith("cpu family:"):
                extra["cpu_family"] = line.split(":", 1)[1].strip()
            elif low.startswith("socket"):
                extra["socket"] = line.split(":", 1)[1].strip()
    # Istruzioni (SSE/AVX/...) da /proc/cpuinfo
    try:
        with open("/proc/cpuinfo", "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                if line.startswith("flags"):
                    flags = line.split(":", 1)[1].split()
                    notable = [fl for fl in flags if fl in (
                        "sse", "sse2", "sse3", "ssse3", "sse4_1", "sse4_2",
                        "avx", "avx2", "avx512f", "fma3", "aes", "vmx", "svm")]
                    extra["instructions"] = ", ".join(notable).upper() or "N/A"
                    if "vmx" in flags or "svm" in flags:
                        extra["virtualization"] = "Sì (VT-x/AMD-V)"
                    break
    except Exception:
        pass
    return extra


def _board_windows():
    board, bios = {}, {}
    data = ps_json(
        "Get-CimInstance Win32_BaseBoard | Select-Object Manufacturer, Product, "
        "Version, SerialNumber"
    )
    if data:
        d = data[0]
        board = {
            "manufacturer": d.get("Manufacturer") or "N/A",
            "product": d.get("Product") or "N/A",
            "version": d.get("Version") or "",
        }
    data = ps_json(
        "Get-CimInstance Win32_BIOS | Select-Object Manufacturer, SMBIOSBIOSVersion, "
        "ReleaseDate, SerialNumber"
    )
    if data:
        d = data[0]
        date = parse_wmi_date(d.get("ReleaseDate"))
        bios = {
            "vendor": d.get("Manufacturer") or "N/A",
            "version": d.get("SMBIOSBIOSVersion") or "N/A",
            "date": date.isoformat() if date else "N/A",
        }
    return {"board": board, "bios": bios}


def _board_linux():
    def read(path):
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read().strip()
        except Exception:
            return "N/A"
    base = "/sys/class/dmi/id"
    return {
        "board": {
            "manufacturer": read(os.path.join(base, "board_vendor")),
            "product": read(os.path.join(base, "board_name")),
            "version": read(os.path.join(base, "board_version")),
        },
        "bios": {
            "vendor": read(os.path.join(base, "bios_vendor")),
            "version": read(os.path.join(base, "bios_version")),
            "date": read(os.path.join(base, "bios_date")),
        },
    }


def _board_macos():
    rc, out, _ = run_cmd(
        ["system_profiler", "SPHardwareDataType"], timeout=20
    )
    board, bios = {"manufacturer": "Apple", "product": "N/A"}, {"vendor": "Apple"}
    if rc == 0 and out:
        for line in out.splitlines():
            if "Model Name" in line:
                board["product"] = line.split(":", 1)[-1].strip()
            if "Chip" in line:
                bios["version"] = line.split(":", 1)[-1].strip()
    return {"board": board, "bios": bios}


def _windows_edition():
    try:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Windows NT\CurrentVersion",
        )
        name, _ = winreg.QueryValueEx(key, "ProductName")
        try:
            build, _ = winreg.QueryValueEx(key, "CurrentBuildNumber")
        except Exception:
            build = ""
        winreg.CloseKey(key)
        return name, build
    except Exception:
        return None, ""


def get_os_info():
    uptime_s = 0
    try:
        uptime_s = int(datetime.datetime.now().timestamp() - psutil.boot_time())
    except Exception:
        pass
    edition, build = platform.system(), platform.version()
    if IS_WINDOWS:
        e, b = _windows_edition()
        edition = e or f"Windows {platform.release()}"
        build = b or build
    return {
        "system": platform.system() or "N/A",
        "edition": edition,
        "release": platform.release(),
        "build": build,
        "arch": platform.machine(),
        "hostname": socket.gethostname(),
        "python": platform.python_version(),
        "uptime_hours": round(uptime_s / 3600, 1),
        "boot_time": datetime.datetime.fromtimestamp(
            psutil.boot_time()
        ).strftime("%d/%m/%Y %H:%M") if uptime_s else "N/A",
    }


def get_cpu_info():
    freq = None
    try:
        f = psutil.cpu_freq()
        if f:
            freq = {"current_mhz": round(f.current), "max_mhz": round(f.max or 0)}
    except Exception:
        pass
    info = {
        "name": get_cpu_name(),
        "cores_physical": psutil.cpu_count(logical=False) or 0,
        "cores_logical": psutil.cpu_count(logical=True) or 0,
        "usage_percent": psutil.cpu_percent(interval=0.3),
        "per_core": psutil.cpu_percent(interval=0.3, percpu=True),
        "architecture": platform.machine(),
    }
    if freq:
        info["current_ghz"] = round(freq["current_mhz"] / 1000, 2)
        info["max_ghz"] = round(freq["max_mhz"] / 1000, 2) if freq["max_mhz"] else None
    if IS_WINDOWS:
        info.update(_cpu_windows_extra())
    elif IS_LINUX:
        info.update(_cpu_linux_extra())
    return info


def get_ram_info():
    vm = psutil.virtual_memory()
    swap = psutil.swap_memory()
    info = {
        "total_gb": gb(vm.total),
        "used_gb": gb(vm.used),
        "available_gb": gb(vm.available),
        "percent": vm.percent,
        "swap_total_gb": gb(swap.total),
        "swap_used_gb": gb(swap.used),
        "swap_percent": swap.percent,
    }
    if IS_WINDOWS:
        data = ps_json(
            "Get-CimInstance Win32_PhysicalMemory | Select-Object Manufacturer, "
            "Capacity, Speed, ConfiguredClockSpeed, PartNumber"
        )
        if data:
            total_slots_modules = len(data)
            speeds = []
            for d in data:
                s = d.get("ConfiguredClockSpeed") or d.get("Speed")
                if s:
                    speeds.append(f"{s} MHz")
            info["modules"] = total_slots_modules
            info["speeds"] = ", ".join(sorted(set(speeds))) or "N/A"
            vendors = [d.get("Manufacturer") for d in data if d.get("Manufacturer")]
            info["vendors"] = ", ".join(sorted(set(vendors))) or "N/A"
        slots = ps_json(
            "Get-CimInstance Win32_PhysicalMemoryArray | Select-Object MemoryDevices"
        )
        if slots:
            try:
                info["slots_total"] = int(slots[0].get("MemoryDevices") or 0)
            except Exception:
                pass
    return info


def get_disks():
    parts = psutil.disk_partitions(all=False)
    if not parts:
        # fallback for restricted environments: whitelist of real filesystems
        real_fs = ("ext2", "ext3", "ext4", "xfs", "btrfs", "f2fs", "ntfs",
                   "vfat", "exfat", "fuseblk", "zfs", "apfs", "hfs", "jfs",
                   "reiserfs", "udf", "iso9660", "exfat")
        parts = [p for p in psutil.disk_partitions(all=True)
                 if p.fstype and p.fstype.lower().startswith(real_fs)]
    disks = []
    for part in parts:
        if "cdrom" in part.opts or not part.fstype:
            continue
        try:
            usage = psutil.disk_usage(part.mountpoint)
        except Exception:
            continue
        disks.append({
            "device": part.device,
            "mountpoint": part.mountpoint,
            "fstype": part.fstype,
            "total_gb": gb(usage.total),
            "used_gb": gb(usage.used),
            "free_gb": gb(usage.free),
            "percent": usage.percent,
        })
    if IS_WINDOWS:
        phys = ps_json(
            "Get-PhysicalDisk | Select-Object FriendlyName, MediaType, BusType, "
            "HealthStatus, @{n='SizeGB';e={[math]::Round($_.Size/1GB,1)}}"
        )
        if phys:
            for p in phys:
                for d in disks:
                    if p.get("HealthStatus"):
                        d.setdefault("health", p.get("HealthStatus"))
                        break
                p.setdefault("_seen", True)
            for p in phys:
                for d in disks:
                    name = (p.get("FriendlyName") or "").strip()
                    if name and name not in d.get("device", ""):
                        continue
                    if p.get("MediaType"):
                        d["media"] = p["MediaType"]
                    if p.get("BusType"):
                        d["bus"] = p["BusType"]
                    if p.get("HealthStatus"):
                        d["health"] = p["HealthStatus"]
                    break
    return disks


def _public_ip(timeout=4):
    for url_cmd in (
        ["curl", "-s", "--maxtime", str(timeout), "https://api.ipify.org"],
        ["curl", "-s", "--maxtime", str(timeout), "https://ifconfig.me"],
    ):
        rc, out, _ = run_cmd(url_cmd, timeout=timeout + 2)
        if rc == 0 and out and re.match(r"^\d+\.\d+\.\d+\.\d+$", out.strip()):
            return out.strip()
    return None


def get_network_info():
    net = psutil.net_io_counters()
    interfaces = []
    try:
        stats = psutil.net_if_addrs()
        for name, addrs in stats.items():
            ipv4, mac = None, None
            for a in addrs:
                fam = getattr(a.family, "name", a.family)
                if fam in ("AF_INET", 2) and not ipv4:
                    ipv4 = a.address
                if fam in ("AF_PACKET", "AF_LINK", 17, 18) and not mac:
                    mac = a.address
            if ipv4 or mac:
                interfaces.append({"name": name, "ip": ipv4, "mac": mac})
    except Exception:
        pass
    counters = {}
    try:
        for name, c in psutil.net_io_counters(pernic=True).items():
            if c.bytes_sent or c.bytes_recv:
                counters[name] = {
                    "sent_mb": round(c.bytes_sent / (1024 ** 2), 1),
                    "recv_mb": round(c.bytes_recv / (1024 ** 2), 1),
                }
    except Exception:
        pass
    return {
        "hostname": socket.gethostname(),
        "public_ip": _public_ip(),
        "interfaces": interfaces,
        "counters": counters,
        "total_sent_mb": round(net.bytes_sent / (1024 ** 2), 1),
        "total_recv_mb": round(net.bytes_recv / (1024 ** 2), 1),
    }


def get_battery():
    try:
        bat = psutil.sensors_battery()
    except Exception:
        bat = None
    if not bat:
        return None
    secs = bat.power_plugged and -1 or (bat.secsleft if bat.secsleft and bat.secsleft > 0 else -1)
    return {
        "percent": round(bat.percent),
        "plugged": bool(bat.power_plugged),
        "time_left": (
            "Charging" if bat.power_plugged
            else (f"{secs // 3600}h {(secs % 3600) // 60}m" if secs > 0 else "N/A")
        ),
    }


def get_audio_devices():
    if IS_WINDOWS:
        data = ps_json("Get-CimInstance Win32_SoundDevice | Select-Object Name, Status")
        if data:
            return [f"{d.get('Name')} ({d.get('Status') or '?'})" for d in data]
    elif IS_LINUX:
        rc, out, _ = run_cmd(["bash", "-c", "aplay -l 2>/dev/null | grep -i 'card '"])
        if rc == 0 and out:
            return [l.strip() for l in out.splitlines()[:8]]
    return []


def get_ram_modules():
    """Per-module RAM details (CPU-Z SPD style, full on Windows only)."""
    modules = []
    if IS_WINDOWS:
        data = ps_json(
            "Get-CimInstance Win32_PhysicalMemory | Select-Object DeviceLocator, "
            "BankLabel, Capacity, Speed, ConfiguredClockSpeed, Manufacturer, "
            "PartNumber, SMBIOSMemoryType"
        )
        mem_types = {20: "DDR", 21: "DDR2", 24: "DDR3", 26: "DDR4", 34: "DDR5"}
        if data:
            for d in data:
                try:
                    cap = int(d.get("Capacity") or 0)
                    cap_gb = round(cap / (1024 ** 3), 1) if cap else None
                except Exception:
                    cap_gb = None
                speed = d.get("ConfiguredClockSpeed") or d.get("Speed")
                mtype = mem_types.get(d.get("SMBIOSMemoryType"), "")
                modules.append({
                    "slot": d.get("DeviceLocator") or d.get("BankLabel") or "?",
                    "size_gb": cap_gb,
                    "speed": f"{speed} MHz" if speed else "N/A",
                    "type": mtype or "N/A",
                    "manufacturer": d.get("Manufacturer") or "N/A",
                    "part": (d.get("PartNumber") or "N/A").strip(),
                })
    elif IS_LINUX:
        rc, out, _ = run_cmd(["bash", "-c", "which dmidecode"])
        if rc != 0:
            return modules, "Per i dettagli per-modulo serve dmidecode (sudo)"
        rc, out, _ = run_cmd(
            ["bash", "-c", "sudo dmidecode -t memory 2>/dev/null | grep -A6 'Memory Device'"],
            timeout=20)
        if rc != 0:
            return modules, "Per i dettagli per-modulo serve sudo"
        cur = {}
        for line in out.splitlines():
            if "Size:" in line:
                if cur:
                    modules.append(cur)
                cur = {"slot": "?", "size_gb": None, "speed": "N/A", "type": "N/A",
                       "manufacturer": "N/A", "part": "N/A"}
                size = line.split(":", 1)[1].strip()
                if size.endswith("GB"):
                    try:
                        cur["size_gb"] = float(size.replace("GB", ""))
                    except Exception:
                        pass
                elif "MB" in size:
                    try:
                        cur["size_gb"] = round(float(size.replace("MB", "")) / 1024, 1)
                    except Exception:
                        pass
            elif "Type:" in line and cur:
                cur["type"] = line.split(":", 1)[1].strip()
            elif "Speed:" in line and cur:
                cur["speed"] = line.split(":", 1)[1].strip()
            elif "Manufacturer:" in line and cur:
                cur["manufacturer"] = line.split(":", 1)[1].strip()
            elif "Part Number:" in line and cur:
                cur["part"] = line.split(":", 1)[1].strip()
            elif "Locator:" in line and cur and cur["slot"] == "?":
                cur["slot"] = line.split(":", 1)[1].strip()
        if cur:
            modules.append(cur)
        modules = [m for m in modules if m.get("size_gb")]
    return modules, None


def get_monitors():
    """Monitor collegati (nome produttore/modello, risoluzione)."""
    monitors = []
    if IS_WINDOWS:
        data = ps_json(
            "Get-CimInstance -Namespace root\\wmi -ClassName WmiMonitorID | "
            "Select-Object UserFriendlyName, ManufacturerName, InstanceName",
            timeout=30)
        if data:
            for d in data:
                def decode(arr):
                    try:
                        return "".join(chr(c) for c in arr if c).strip()
                    except Exception:
                        return ""
                name = decode(d.get("UserFriendlyName") or [])
                manuf = decode(d.get("ManufacturerName") or [])
                monitors.append({"manufacturer": manuf or "N/A", "model": name or "?"})
        gpus = ps_json(
            "Get-CimInstance Win32_VideoController | Select-Object "
            "CurrentHorizontalResolution, CurrentVerticalResolution, "
            "CurrentRefreshRate, CurrentBitsPerPixel, MinRefreshRate, MaxRefreshRate")
        res = None
        if gpus:
            g = gpus[0]
            if g.get("CurrentHorizontalResolution"):
                res = {
                    "width": g.get("CurrentHorizontalResolution"),
                    "height": g.get("CurrentVerticalResolution"),
                    "refresh": g.get("CurrentRefreshRate"),
                    "bpp": g.get("CurrentBitsPerPixel"),
                    "min_refresh": g.get("MinRefreshRate"),
                    "max_refresh": g.get("MaxRefreshRate"),
                }
        if not monitors and res:
            monitors.append({"manufacturer": "N/A", "model": "Monitor principale"})
        return monitors, res
    if IS_LINUX:
        rc, out, _ = run_cmd(["bash", "-c", "xrandr --current 2>/dev/null | grep ' connected'"])
        if rc == 0 and out:
            for line in out.splitlines():
                parts = line.split()
                name = parts[0]
                res = None
                if len(parts) >= 3 and "x" in parts[2] and "+" in parts[2]:
                    res = parts[2].split("+")[0]
                monitors.append({"manufacturer": "N/A", "model": name,
                                 "resolution": res})
    return monitors, None


def get_system_slots():
    """Motherboard expansion slots (Windows)."""
    if not IS_WINDOWS:
        return []
    data = ps_json(
        "Get-CimInstance Win32_SystemSlot | Select-Object SlotDesignation, "
        "CurrentUsage")
    if not data:
        return []
    usage_map = {3: "Free", 4: "Used"}
    slots = []
    for d in data[:12]:
        slots.append({
            "name": d.get("SlotDesignation") or "Slot",
            "usage": usage_map.get(d.get("CurrentUsage"), "N/A"),
        })
    return slots


def get_temperatures():
    temps = {}
    try:
        sensors = psutil.sensors_temperatures()
        for name, entries in (sensors or {}).items():
            for e in entries:
                label = e.label or name
                if e.current:
                    temps[label] = round(e.current, 1)
    except Exception:
        pass
    return temps


def get_full_system_info():
    """Collects ALL system information into a single dictionary."""
    info = {
        "os": get_os_info(),
        "cpu": get_cpu_info(),
        "ram": get_ram_info(),
        "disks": get_disks(),
        "network": get_network_info(),
        "battery": get_battery(),
        "audio": get_audio_devices(),
        "temperatures": get_temperatures(),
        "ram_modules": [],
        "monitors": [],
        "display": None,
        "slots": [],
    }
    try:
        mods, _err = get_ram_modules()
        info["ram_modules"] = mods
    except Exception:
        pass
    try:
        mons, res = get_monitors()
        info["monitors"] = mons
        info["display"] = res
    except Exception:
        pass
    try:
        info["slots"] = get_system_slots()
    except Exception:
        pass
    if IS_WINDOWS:
        info.update(_board_windows())
    elif IS_LINUX:
        info.update(_board_linux())
    elif IS_MACOS:
        info.update(_board_macos())
    else:
        info.update({"board": {}, "bios": {}})
    return info
