"""PC Doctor Pro - quick benchmarks: CPU (single/multi), RAM, disk."""
import os
import time
import math
import shutil
import tempfile
import multiprocessing

from .utils import IS_WINDOWS, fmt_bytes


def _cpu_worker(n):
    """Calcolo pesante legato alla CPU (primalita' + radici quadrate)."""
    total = 0.0
    count = 0
    for i in range(3, n, 7):
        limit = int(math.isqrt(i))
        prime = True
        for j in range(3, limit + 1, 2):
            if i % j == 0:
                prime = False
                break
        if prime:
            total += math.sqrt(i)
            count += 1
    return total + count


def run_cpu_benchmark(progress=None):
    """
    Benchmark CPU: prova singolo-core e multi-core.
    Ritorna dict con punteggi (piu' alti = piu' veloce).
    """
    n = 900_000  # ~1-3 s depending on the CPU
    if progress:
        progress("Single-core test...")
    t0 = time.perf_counter()
    _cpu_worker(n)
    single_s = time.perf_counter() - t0

    cores = multiprocessing.cpu_count() or 2
    if progress:
        progress(f"Multi-core test on {cores} threads...")
    t0 = time.perf_counter()
    try:
        ctx = multiprocessing.get_context("spawn" if IS_WINDOWS else "fork")
        with ctx.Pool(processes=min(cores, 16)) as pool:
            pool.map(_cpu_worker, [n] * min(cores, 16))
    except Exception:
        for _ in range(min(cores, 16)):
            _cpu_worker(n)
    multi_s = time.perf_counter() - t0

    base = single_s or 0.001
    return {
        "single_score": round(1000 / base, 1),
        "multi_score": round(1000 * min(cores, 16) / (multi_s or 0.001), 1),
        "single_seconds": round(single_s, 2),
        "multi_seconds": round(multi_s, 2),
        "cores": cores,
    }


def run_ram_benchmark(progress=None):
    """Benchmark larghezza di banda RAM (copia e calcolo su array grandi)."""
    if progress:
        progress("RAM bandwidth test...")
    size = 64 * 1024 * 1024  # 64M elementi = 512 MB per lista
    t0 = time.perf_counter()
    a = list(range(size // 8))  # 8M elementi
    t1 = time.perf_counter()
    b = a * 4  # copia grande
    t2 = time.perf_counter()
    s = sum(b[::4])
    t3 = time.perf_counter()
    del b, a, s
    build_gbps = (size / 8 * 8) / (t1 - t0) / 1e9
    copy_gbps = (size * 8) / (t2 - t1) / 1e9
    read_gbps = (size * 8) / (t3 - t2) / 1e9
    return {
        "write_gbps": round(build_gbps, 2),
        "copy_gbps": round(copy_gbps, 2),
        "read_gbps": round(read_gbps, 2),
        "avg_gbps": round((build_gbps + copy_gbps + read_gbps) / 3, 2),
    }


def run_disk_benchmark(progress=None):
    """Benchmark lettura/scrittura disco (file temporaneo da 512 MB)."""
    if progress:
        progress("Disk speed test (512 MB write + read)...")
    test_dir = os.path.join(tempfile.gettempdir(), "PCDoctor_bench")
    os.makedirs(test_dir, exist_ok=True)
    path = os.path.join(test_dir, "bench.bin")
    block = 1024 * 1024
    data = os.urandom(block)
    size_mb = 512
    try:
        t0 = time.perf_counter()
        with open(path, "wb") as f:
            for _ in range(size_mb):
                f.write(data)
            f.flush()
            os.fsync(f.fileno())
        write_s = time.perf_counter() - t0

        t0 = time.perf_counter()
        with open(path, "rb") as f:
            while f.read(block):
                pass
        read_s = time.perf_counter() - t0
    finally:
        try:
            os.remove(path)
            os.rmdir(test_dir)
        except OSError:
            pass
    return {
        "write_mbps": round(size_mb / max(write_s, 0.001), 1),
        "read_mbps": round(size_mb / max(read_s, 0.001), 1),
    }


def run_all_benchmarks(progress=None):
    """Esegue tutti i benchmark in sequenza."""
    res = {}
    res["cpu"] = run_cpu_benchmark(progress)
    res["ram"] = run_ram_benchmark(progress)
    res["disk"] = run_disk_benchmark(progress)
    res["cpu"]["tier"] = classify_cpu(res["cpu"])
    return res


# Class tier based on the scores of THIS suite (indicative values)
CPU_TIERS = [
    (500, "Entry - old office PC"),
    (1200, "Basic - everyday use"),
    (2200, "Mid-range - gaming & multitasking"),
    (3200, "High - heavy gaming & work"),
    (4500, "Enthusiast - rendering & streaming"),
    (10**9, "Flagship - workstation"),
]


def classify_cpu(cpu_res):
    """Assigns a class tier based on the multi-core score."""
    score = cpu_res.get("multi_score") or 0
    scaling = 0
    if cpu_res.get("single_score"):
        scaling = round(score / cpu_res["single_score"], 2)
    for threshold, label in CPU_TIERS:
        if score < threshold:
            return {"tier": label, "scaling": scaling}
    return {"tier": "Flagship - workstation", "scaling": scaling}


REFERENCE_CPUS = [
    ("Intel i3-10100 (4c/8t)", 2100, 6800),
    ("Intel i5-12400 (6c/12t)", 3400, 14500),
    ("Intel i7-13700K (16c/24t)", 4600, 24000),
    ("AMD Ryzen 5 5600 (6c/12t)", 3300, 14000),
    ("AMD Ryzen 7 7800X3D (8c/16t)", 4200, 19000),
    ("AMD Ryzen 9 7950X (16c/32t)", 4500, 34000),
]


def reference_comparison(cpu_res):
    """
    Returns a list of (name, reference_score, your_score, delta_pct)
    comparing the multi-core score with reference CPUs (indicative values).
    """
    mine = cpu_res.get("multi_score") or 0
    out = []
    for name, single, multi in REFERENCE_CPUS:
        if mine and multi:
            delta = round((mine - multi) / multi * 100, 1)
        else:
            delta = None
        out.append((name, multi, mine, delta))
    return out
