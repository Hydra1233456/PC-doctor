"""PC Doctor Pro - GPU overclock/undervolt and CPU power tuning.

NVIDIA GPUs are tuned through nvidia-smi (power limit, clock locks).
AMD / Intel GPUs get guided profiles (Adrenalin / Arc Control / XTU).
CPU power plans are managed through powercfg (Windows only).
Every apply* function returns (ok, message) and never raises.
"""
import time

from .utils import IS_WINDOWS, run_cmd

TEMP_SAFE_C = 83        # conservative safety threshold for auto-tune
TEMP_MAX_C = 90         # hard threshold: revert to defaults


# --------------------------------------------------------------------- GPU
def nvidia_gpu(index=None):
    """Return the first NVIDIA GPU dict from nvidia-smi, or None."""
    rc, out, _ = run_cmd(["nvidia-smi", "--query-gpu=index,name", "--format=csv,noheader"], timeout=8)
    if rc != 0 or not out:
        return None
    first = out.splitlines()[0].strip()
    idx = int(first.split(",")[0])
    name = first.split(",", 1)[1].strip()
    if index is not None:
        idx = index
    return {"index": idx, "name": name}


def gpu_caps():
    """
    Read tuning capabilities of the first NVIDIA GPU.
    Returns dict or None when nvidia-smi is unavailable.
    """
    g = nvidia_gpu()
    if not g:
        return None
    i = g["index"]
    rc, out, _ = run_cmd([
        "nvidia-smi", "-i", str(i),
        "--query-gpu=name,temperature.gpu,utilization.gpu,fan.speed,power.draw,"
        "power.limit,power.min_limit,power.max_limit,power.default_power.limit,"
        "clocks.current.graphics,clocks.max.graphics,clocks.current.memory,"
        "clocks.max.memory,memory.used,memory.total",
        "--format=csv,noheader,nounits",
    ], timeout=10)
    if rc != 0 or not out:
        return None

    def f(v):
        try:
            return float(str(v).strip())
        except Exception:
            return None

    p = [x.strip() for x in out.splitlines()[0].split(",")]
    if len(p) < 15:
        return None
    return {
        "index": i,
        "name": p[0],
        "temp_c": f(p[1]),
        "util_percent": f(p[2]),
        "fan_percent": f(p[3]),
        "power_w": f(p[4]),
        "power_limit_w": f(p[5]),
        "power_min_w": f(p[6]),
        "power_max_w": f(p[7]),
        "power_default_w": f(p[8]) or f(p[5]),
        "core_clock_mhz": f(p[9]),
        "core_clock_max_mhz": f(p[10]),
        "mem_clock_mhz": f(p[11]),
        "mem_clock_max_mhz": f(p[12]),
        "vram_used_mb": f(p[13]),
        "vram_total_mb": f(p[14]),
    }


def apply_power_limit(index, watts):
    """Set GPU power limit in watts (undervolt/eco = lower, OC = higher)."""
    rc, out, err = run_cmd(["nvidia-smi", "-i", str(index), "-pl", str(int(watts))], timeout=20)
    if rc == 0:
        return True, f"Power limit set to {int(watts)} W"
    return False, _clean_err(out, err, "Cannot set power limit")


def lock_core_clock(index, mhz):
    """Lock GPU core clock to a fixed frequency (MHz). 0 = reset/unlock."""
    if not mhz or mhz <= 0:
        return reset_core_clock(index)
    rc, out, err = run_cmd(
        ["nvidia-smi", "-i", str(index), "-lgc", f"{int(mhz)},{int(mhz)}"], timeout=20)
    if rc == 0:
        return True, f"Core clock locked at {int(mhz)} MHz"
    return False, _clean_err(out, err, "Cannot lock core clock")


def lock_mem_clock(index, mhz):
    """Lock GPU memory clock (MHz). 0 = reset/unlock."""
    if not mhz or mhz <= 0:
        return reset_mem_clock(index)
    rc, out, err = run_cmd(
        ["nvidia-smi", "-i", str(index), "-lmc", f"{int(mhz)},{int(mhz)}"], timeout=20)
    if rc == 0:
        return True, f"Memory clock locked at {int(mhz)} MHz"
    return False, _clean_err(out, err, "Cannot lock memory clock")


def reset_core_clock(index):
    rc, out, err = run_cmd(["nvidia-smi", "-i", str(index), "-rgc"], timeout=20)
    return (True, "Core clock reset to default") if rc == 0 else \
        (False, _clean_err(out, err, "Cannot reset core clock"))


def reset_mem_clock(index):
    rc, out, err = run_cmd(["nvidia-smi", "-i", str(index), "-rmc"], timeout=20)
    return (True, "Memory clock reset to default") if rc == 0 else \
        (False, _clean_err(out, err, "Cannot reset memory clock"))


def reset_gpu_defaults(index):
    """Full reset: clocks + power limit back to default."""
    msgs = []
    ok_all = True
    for fn, label in ((reset_core_clock, "core clock"), (reset_mem_clock, "memory clock")):
        ok, msg = fn(index)
        ok_all &= ok
        msgs.append(msg if ok else f"{label}: {msg}")
    caps = gpu_caps()
    if caps and caps.get("power_default_w") and caps.get("power_limit_w") != caps["power_default_w"]:
        ok, msg = apply_power_limit(index, caps["power_default_w"])
        ok_all &= ok
        msgs.append(msg)
    return ok_all, " | ".join(msgs) if msgs else "Already at defaults"


def apply_profile(name, index=None):
    """
    One-click automatic profiles.
      eco        -> undervolt: power limit ~80% of default, clocks free
      balanced   -> factory defaults
      performance-> power limit at max allowed
    Returns (ok, message).
    """
    caps = gpu_caps()
    if not caps:
        return False, "nvidia-smi not found: automatic profiles need an NVIDIA GPU"
    i = caps["index"] if index is None else index
    dflt = caps.get("power_default_w") or caps.get("power_limit_w") or 0
    lo = caps.get("power_min_w") or 0
    hi = caps.get("power_max_w") or dflt
    if name == "eco":
        target = max(dflt * 0.8, lo) if dflt else None
        ok, msg = apply_power_limit(i, target) if target else (False, "Unknown power limits")
        msg += "  (undervolt profile: ~20% less power, cooler and quieter)"
        return ok, msg
    if name == "balanced":
        return reset_gpu_defaults(i)
    if name == "performance":
        if hi and dflt and hi > dflt:
            ok, msg = apply_power_limit(i, hi)
            return ok, msg + "  (max power headroom; watch temperatures!)"
        return True, "Max power limit already active"
    return False, f"Unknown profile: {name}"


def monitor_gpu(seconds=20, progress=None, stop_flag=None):
    """
    Sample temp/power/clock for N seconds (auto-tune validation).
    progress(dict) is called each second. Returns (max_temp, samples).
    """
    samples = []
    max_temp = 0.0
    t0 = time.time()
    while time.time() - t0 < seconds:
        if stop_flag is not None and stop_flag():
            break
        caps = gpu_caps()
        if caps:
            samples.append(caps)
            max_temp = max(max_temp, caps.get("temp_c") or 0)
            if progress:
                progress(caps)
        time.sleep(1)
    return max_temp, samples


def _clean_err(out, err, prefix):
    msg = err or out or "unknown error"
    if "Insufficient Permissions" in msg or "permissions" in msg.lower():
        return (prefix + ": not enough permissions.\n"
                "Restart PC Doctor Pro as Administrator and try again.")
    if "not supported" in msg.lower():
        return prefix + ": not supported by this GPU/driver (laptops often block it)."
    return prefix + ": " + msg.strip()[:300]


# --------------------------------------------------------------------- CPU
def _powercfg(*args, timeout=30):
    return run_cmd(["powercfg", *args], timeout=timeout)


def list_power_plans():
    """Parse `powercfg /list` -> [(guid, name, active_bool)]."""
    if not IS_WINDOWS:
        return []
    rc, out, _ = _powercfg("/list")
    plans = []
    if rc == 0 and out:
        import re
        for line in out.splitlines():
            m = re.search(r"([0-9a-fA-F-]{36})\s+\(?([^)]+?)\)?\s*$", line)
            if m:
                plans.append((m.group(1), m.group(2).strip("* ").strip(),
                              "*" in line))
    return plans


def set_power_plan(alias_or_guid):
    """
    Activate a power plan. Aliases:
      SCHEME_MIN   = High performance
      SCHEME_BALANCED = Balanced
      SCHEME_MAX   = Power saver
    """
    if not IS_WINDOWS:
        return False, "CPU power plans are Windows-only"
    rc, out, err = _powercfg("/setactive", alias_or_guid)
    if rc == 0:
        return True, f"Power plan activated: {alias_or_guid}"
    return False, (err or out or "Cannot change power plan")


def set_boost_mode(mode=2):
    """
    Processor boost mode: 0=disabled 1=enabled 2=aggressive
    3=efficient enabled 4=efficient aggressive (Intel SpeedShift / AMD CPPC).
    """
    if not IS_WINDOWS:
        return False, "Boost mode is Windows-only"
    labels = {0: "Disabled", 1: "Enabled", 2: "Aggressive",
              3: "Efficient Enabled", 4: "Efficient Aggressive"}
    _powercfg("/setacvalueindex", "SCHEME_CURRENT", "SUB_PROCESSOR",
              "PERFBOOSTMODE", str(mode))
    rc, _, err = _powercfg("/setactive", "SCHEME_CURRENT")
    if rc == 0:
        return True, f"CPU boost mode: {labels.get(mode, mode)}"
    return False, (err or "Cannot set boost mode")


def cpu_power_report():
    """Short powercfg report of active scheme (for the UI)."""
    if not IS_WINDOWS:
        return "Windows-only"
    rc, out, _ = _powercfg("/getactivescheme")
    return out if rc == 0 else "unknown"


VENDOR_TUNING_APPS = {
    "NVIDIA": {
        "app": "NVIDIA App / GeForce Experience",
        "url": "https://www.nvidia.com/en-us/software/nvidia-app/",
        "how": "System > GPU > Performance > Automatic tuning (OC scanner)",
    },
    "AMD": {
        "app": "AMD Adrenalin",
        "url": "https://www.amd.com/en/support",
        "how": "Performance > Tuning > Custom: GPU Tuning (clocks) or Auto Overclock / Undervolt",
    },
    "Intel": {
        "app": "Intel Graphics Software / XTU",
        "url": "https://www.intel.com/content/www/us/en/download-center/home.html",
        "how": "Performance Tuning: Core voltage offset (undervolt) or XTU for CPU",
    },
}
