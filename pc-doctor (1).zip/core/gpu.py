"""PC Doctor Pro - rilevamento GPU, driver, VRAM, immagini di marca."""
import os
import re
import json
import urllib.request

from .utils import (
    IS_WINDOWS, IS_LINUX, IS_MACOS, run_cmd, ps_json, parse_wmi_date,
    assets_dir, cache_dir,
)

# Mappa vendor PCI -> marca
PCI_VENDORS = {
    "10de": "NVIDIA",
    "1002": "AMD",
    "1022": "AMD",
    "8086": "Intel",
    "1414": "Microsoft",
    "15ad": "VMware",
    "1af4": "Red Hat (virtio)",
    "1234": "QEMU/Bochs",
    "1013": "Cirrus Logic",
    "1a03": "ASPEED",
}

WINGET_ASSISTANTS = {
    "NVIDIA": ["Nvidia.GeForceExperience", "Nvidia.App"],
    "AMD": ["AMD.RadeonSoftware", "AMD.RadeonSoftwareAdrenalin"],
    "Intel": ["Intel.IntelDriverAndSupportAssistant", "Intel.ArcControl"],
}

DRIVER_PAGES = {
    "NVIDIA": "https://www.nvidia.com/en-us/drivers/",
    "AMD": "https://www.amd.com/en/support",
    "Intel": "https://www.intel.com/content/www/us/en/download-center/home.html",
    "Microsoft": "https://support.microsoft.com/en-us/windows",
}

BRAND_COLORS = {
    "NVIDIA": "#76b900",
    "AMD": "#ed1c24",
    "Intel": "#00c7fd",
    "Microsoft": "#f25022",
    "Generic": "#2dd4bf",
}

_LOGO_URLS = {
    "NVIDIA": [
        "https://upload.wikimedia.org/wikipedia/commons/thumb/2/21/Nvidia_logo.svg/640px-Nvidia_logo.svg.png",
        "https://logos-world.net/wp-content/uploads/2020/09/Nvidia-Logo.png",
    ],
    "AMD": [
        "https://upload.wikimedia.org/wikipedia/commons/thumb/9/94/AMD_Logo.svg/640px-AMD_Logo.svg.png",
        "https://logos-world.net/wp-content/uploads/2020/11/AMD-Logo.png",
    ],
    "Intel": [
        "https://upload.wikimedia.org/wikipedia/commons/thumb/6/66/Intel_logo_%282020%2C_vertical%29.svg/400px-Intel_logo_%282020%2C_vertical%29.svg.png",
        "https://logos-world.net/wp-content/uploads/2020/11/Intel-Logo.png",
    ],
}


def vendor_from_name(name, pnp_id=""):
    """Indovina la marca dal nome GPU o dal PNPDeviceID (VEN_xxxx)."""
    text = f"{name} {pnp_id}".lower()
    if "nvidia" in text or "geforce" in text or "quadro" in text or "tesla" in text:
        return "NVIDIA"
    if "amd" in text or "radeon" in text or "ati " in text:
        return "AMD"
    if "intel" in text:
        return "Intel"
    if "vmware" in text:
        return "VMware"
    if "basic display" in text or "microsoft" in text:
        return "Microsoft"
    if pnp_id:
        m = re.search(r"ven_([0-9a-f]{4})", pnp_id, re.I)
        if m:
            return PCI_VENDORS.get(m.group(1).lower(), "Generic")
    return "Generic"


def art_for_vendor(vendor):
    """Percorso dell'immagine artwork di marca (file assets o embedded)."""
    names = {"NVIDIA": "art_nvidia", "AMD": "art_amd", "Intel": "art_intel"}
    key = names.get(vendor, "art_generic")
    p = os.path.join(assets_dir(), key + ".png")
    if os.path.exists(p):
        return p
    try:
        return asset_png(key)
    except NameError:
        return None


def logo_for_vendor(vendor, timeout=6):
    """
    Scarica (e mette in cache) il logo ufficiale della marca.
    Ritorna il percorso del file oppure None se offline.
    """
    cached = os.path.join(cache_dir(), f"logo_{vendor.lower()}.png")
    if os.path.exists(cached) and os.path.getsize(cached) > 1024:
        return cached
    urls = _LOGO_URLS.get(vendor, [])
    for url in urls:
        try:
            req = urllib.request.Request(
                url, headers={"User-Agent": "Mozilla/5.0 (PCDoctorPro)"}
            )
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read()
            if len(data) > 1024 and data[:8] == b"\x89PNG\r\n\x1a\n":
                with open(cached, "wb") as f:
                    f.write(data)
                return cached
        except Exception:
            continue
    return None


def _nvidia_smi_data():
    """Dati da nvidia-smi (temperatura, utilizzo, clock, PCIe, consumo)."""
    if not IS_WINDOWS and not IS_LINUX:
        return []
    cmd = [
        "nvidia-smi",
        "--query-gpu=index,name,driver_version,memory.total,temperature.gpu,"
        "utilization.gpu,fan.speed,power.draw,memory.used,power.limit,"
        "clocks.current.graphics,clocks.max.graphics,clocks.current.memory,"
        "clocks.max.memory,pcie.link.gen.current,pcie.link.width.current,pstate",
        "--format=csv,noheader,nounits",
    ]
    rc, out, _ = run_cmd(cmd, timeout=10)
    gpus = []
    if rc == 0 and out:
        for line in out.splitlines():
            parts = [p.strip() for p in line.split(",")]
            if len(parts) >= 17:
                def to_float(x):
                    try:
                        return float(x)
                    except Exception:
                        return None
                def to_int(x):
                    try:
                        return int(float(x))
                    except Exception:
                        return None
                pstate = parts[16]
                gpus.append({
                    "index": to_int(parts[0]) or 0,
                    "name": parts[1],
                    "driver_version": parts[2],
                    "vram_mb": to_float(parts[3]),
                    "temp_c": to_float(parts[4]),
                    "util_percent": to_float(parts[5]),
                    "fan_percent": to_float(parts[6]),
                    "power_w": to_float(parts[7]),
                    "vram_used_mb": to_float(parts[8]),
                    "power_limit_w": to_float(parts[9]),
                    "clock_gpu_mhz": to_int(parts[10]),
                    "clock_gpu_max_mhz": to_int(parts[11]),
                    "clock_mem_mhz": to_int(parts[12]),
                    "clock_mem_max_mhz": to_int(parts[13]),
                    "pcie_gen": to_int(parts[14]),
                    "pcie_width": to_int(parts[15]),
                    "pstate": ("P" + pstate.replace("P", "")) if pstate else None,
                })
    return gpus


def _gpus_windows():
    gpus = []
    data = ps_json(
        "Get-CimInstance Win32_VideoController | Select-Object Name, "
        "AdapterCompatibility, PNPDeviceID, DriverVersion, DriverDate, AdapterRAM, "
        "VideoModeDescription, Status, VideoProcessor, CurrentRefreshRate"
    )
    if not data:
        return gpus
    # VRAM precisa dal registro (AdapterRAM e' limitato a 4GB)
    vram_registry = _vram_from_registry()
    for d in data:
        name = d.get("Name") or "Unknown graphics card"
        pnp = d.get("PNPDeviceID") or ""
        vendor = vendor_from_name(name, pnp)
        vram_mb = None
        if pnp and pnp in vram_registry:
            vram_mb = round(vram_registry[pnp] / (1024 * 1024))
        if not vram_mb:
            try:
                ram = int(d.get("AdapterRAM") or 0)
                vram_mb = round(ram / (1024 * 1024)) if ram > 0 else None
            except Exception:
                pass
        date = parse_wmi_date(d.get("DriverDate"))
        mode = d.get("VideoModeDescription") or ""
        res = None
        if " x " in mode:
            seg = mode.split(" x ")
            res = f"{seg[0]} x {seg[1]}" if len(seg) >= 2 else None
        gpus.append({
            "name": name,
            "vendor": vendor,
            "vram_mb": vram_mb,
            "driver_version": d.get("DriverVersion") or "N/A",
            "driver_date": date.isoformat() if date else None,
            "resolution": res,
            "refresh_rate": d.get("CurrentRefreshRate") or None,
            "status": d.get("Status") or "N/A",
            "pnp_id": pnp,
        })
    return gpus


def _vram_from_registry():
    """Legge HardwareInformation.qwMemorySize dal registro di Windows."""
    out = {}
    try:
        import winreg
        base = r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
        for idx in range(10):
            try:
                key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, f"{base}\\{idx:04d}")
            except OSError:
                break
            try:
                try:
                    pnp, _ = winreg.QueryValueEx(key, "MatchingDeviceId")
                except OSError:
                    pnp = ""
                size = None
                for val in ("HardwareInformation.qwMemorySize",
                            "HardwareInformation.MemorySize"):
                    try:
                        size, _ = winreg.QueryValueEx(key, val)
                        if isinstance(size, bytes) and len(size) >= 8:
                            size = int.from_bytes(size[:8], "little")
                        if isinstance(size, int) and size > 0:
                            break
                        size = None
                    except OSError:
                        continue
            finally:
                winreg.CloseKey(key)
            if size and pnp:
                pnp_up = pnp.upper()
                out[pnp_up] = size
                m = re.search(r"VEN_([0-9A-F]{4})&DEV_([0-9A-F]{4})", pnp_up)
                if m:
                    out[f"VEN_{m.group(1)}&DEV_{m.group(2)}"] = size
    except Exception:
        pass
    return out


def _gpus_linux():
    gpus = []
    rc, out, _ = run_cmd(["bash", "-c", "lspci -nnk | grep -Ei 'vga|3d|display'"])
    if rc == 0 and out:
        for line in out.splitlines():
            slot = line.split(" ", 1)[0]
            m = re.search(r"\[([0-9a-f]{4}):([0-9a-f]{4})\]", line)
            vendor_id = m.group(1) if m else ""
            dev_id = m.group(2) if m else ""
            name_part = re.sub(r"\[.*?\]", "", line).split(":", 1)[-1].strip()
            vendor = PCI_VENDORS.get(vendor_id.lower(), "Generic")
            driver = None
            rc2, out2, _ = run_cmd(["lspci", "-k", "-s", slot])
            if rc2 == 0:
                for l in out2.splitlines():
                    if "Kernel driver in use:" in l:
                        driver = l.split(":", 1)[1].strip()
            gpus.append({
                "name": name_part or "Graphics card",
                "vendor": vendor_from_name(name_part, f"VEN_{vendor_id}"),
                "vram_mb": None,
                "driver_version": driver or "N/A",
                "driver_date": None,
                "resolution": None,
                "refresh_rate": None,
                "status": "N/A",
                "pnp_id": f"{vendor_id}:{dev_id}",
            })
    return gpus


def _gpus_macos():
    rc, out, _ = run_cmd(
        ["system_profiler", "SPDisplaysDataType", "-json"], timeout=20
    )
    gpus = []
    if rc == 0 and out:
        try:
            data = json.loads(out)
            items = data.get("SPDisplaysDataType", [])
            for item in items:
                name = item.get("sppci_model") or item.get("_name") or "GPU"
                vram = item.get("spdisplays_vram_shared") or item.get("spdisplays_vram")
                vram_mb = None
                if vram and str(vram).endswith("MB"):
                    try:
                        vram_mb = int(str(vram).replace("MB", ""))
                    except Exception:
                        pass
                gpus.append({
                    "name": name,
                    "vendor": vendor_from_name(name),
                    "vram_mb": vram_mb,
                    "driver_version": "N/A",
                    "driver_date": None,
                    "resolution": None,
                    "refresh_rate": None,
                    "status": "N/A",
                    "pnp_id": "",
                })
        except Exception:
            pass
    return gpus


def get_gpus():
    """Rileva tutte le GPU con driver, VRAM e dati live NVIDIA."""
    if IS_WINDOWS:
        gpus = _gpus_windows()
    elif IS_LINUX:
        gpus = _gpus_linux()
    elif IS_MACOS:
        gpus = _gpus_macos()
    else:
        gpus = []
    # Arricchisce con dati nvidia-smi ( temperatura, utilizzo, VRAM esatta)
    nv = _nvidia_smi_data()
    if nv:
        for g in gpus:
            for n in nv:
                if n["name"].lower() in g["name"].lower() or g["name"].lower() in n["name"].lower():
                    g["nvidia_live"] = n
                    if n.get("vram_mb"):
                        g["vram_mb"] = int(n["vram_mb"])
                    if n.get("driver_version") and g["driver_version"] == "N/A":
                        g["driver_version"] = n["driver_version"]
                    break
        # GPU NVIDIA non rilevate da WMI (raro)
        for n in nv:
            if not any(n["name"].lower() in g["name"].lower() for g in gpus):
                gpus.append({
                    "name": n["name"],
                    "vendor": "NVIDIA",
                    "vram_mb": int(n["vram_mb"]) if n.get("vram_mb") else None,
                    "driver_version": n.get("driver_version") or "N/A",
                    "driver_date": None,
                    "resolution": None,
                    "refresh_rate": None,
                    "status": "OK",
                    "pnp_id": "",
                    "nvidia_live": n,
                })
    for g in gpus:
        g["art"] = art_for_vendor(g["vendor"])
        g["brand_color"] = BRAND_COLORS.get(g["vendor"], BRAND_COLORS["Generic"])
        g["driver_page"] = DRIVER_PAGES.get(g["vendor"])
        g["assistant_winget"] = WINGET_ASSISTANTS.get(g["vendor"], [])
        date = g.get("driver_date")
        if date:
            try:
                import datetime as _dt
                years = (_dt.date.today() - _dt.date.fromisoformat(date)).days / 365.25
                g["driver_age_years"] = round(years, 1)
            except Exception:
                g["driver_age_years"] = None
        else:
            g["driver_age_years"] = None
    return gpus


def vram_label(vram_mb):
    if not vram_mb:
        return "N/A"
    if vram_mb >= 1024:
        return f"{round(vram_mb / 1024)} GB"
    return f"{vram_mb} MB"
