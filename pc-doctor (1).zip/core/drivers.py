"""PC Doctor Pro - gestione driver: scansione, aggiornamento, ripristino."""
import datetime

from .utils import (
    IS_WINDOWS, run_cmd, run_powershell, ps_json, parse_wmi_date,
)

OLD_DRIVER_YEARS = 3  # a driver older than N years is marked "Outdated"


def scan_drivers(progress=None):
    """
    Scansiona i driver installati (Win32_PnPSignedDriver).
    Ritorna (lista_driver, errore). progress(msg) opzionale per la GUI.
    """
    if not IS_WINDOWS:
        return [], "Driver management is only available on Windows"
    if progress:
        progress("Reading signed drivers from Windows (this can take 10-30 seconds)...")
    data = ps_json(
        "Get-CimInstance Win32_PnPSignedDriver | Where-Object { $_.DeviceName -and "
        "$_.DriverVersion } | Select-Object DeviceName, Manufacturer, "
        "DriverProviderName, DriverVersion, DriverDate, IsSigned, DeviceClass",
        timeout=120,
    )
    if data is None:
        return [], "Could not read drivers (try starting as administrator)"
    if progress:
        progress(f"Analysing {len(data)} entries...")
    seen = set()
    drivers = []
    today = datetime.date.today()
    for d in data:
        name = (d.get("DeviceName") or "").strip()
        version = (d.get("DriverVersion") or "").strip()
        if not name or not version:
            continue
        key = (name, version)
        if key in seen:
            continue
        seen.add(key)
        date = parse_wmi_date(d.get("DriverDate"))
        age = round((today - date).days / 365.25, 1) if date else None
        signed = bool(d.get("IsSigned")) if d.get("IsSigned") is not None else True
        drivers.append({
            "device": name,
            "manufacturer": d.get("Manufacturer") or d.get("DriverProviderName") or "N/A",
            "provider": d.get("DriverProviderName") or "N/A",
            "version": version,
            "date": date.isoformat() if date else None,
            "age_years": age,
            "signed": signed,
            "device_class": d.get("DeviceClass") or "",
            "status": "Outdated" if (age and age > OLD_DRIVER_YEARS) else "OK",
        })
    drivers.sort(key=lambda x: (x["status"] != "Outdated", -(x["age_years"] or 0), x["device"].lower()))
    return drivers, None


def driver_stats(drivers):
    total = len(drivers)
    signed = sum(1 for d in drivers if d["signed"])
    old = sum(1 for d in drivers if d["status"] == "Outdated")
    return {"total": total, "signed": signed, "old": old}


def create_restore_point():
    """
    Crea un punto di ripristino di Windows (richiede admin).
    Ritorna (ok, messaggio).
    """
    if not IS_WINDOWS:
        return False, "Windows only"
    rc, out, err = run_powershell(
        'Checkpoint-Computer -Description "PC Doctor Pro - prima aggiornamento driver" '
        "-RestorePointType MODIFY_SETTINGS",
        timeout=180,
    )
    if rc == 0:
        return True, "Restore point created"
    return False, (
        "Could not create the restore point (administrator required or System Restore "
        "is disabled). Continue anyway?"
    )


def _wua_search_drivers():
    """Searches Windows Update for driver updates via COM (native PowerShell)."""
    script = r"""
$ErrorActionPreference = 'Stop'
$session = New-Object -ComObject Microsoft.Update.Session
$searcher = $session.CreateUpdateSearcher()
$result = $searcher.Search("IsInstalled=0 and Type='Driver'")
$list = @()
foreach ($u in $result.Updates) {
    $list += [pscustomobject]@{ Title = $u.Title; DriverVerDate = $u.DriverVerDate; SizeMB = [math]::Round($u.MaxDownloadSize/1MB,1) }
}
$list | ConvertTo-Json -Compress
"""
    rc, out, err = run_powershell(script, timeout=600)
    if rc != 0:
        return None, (err or "Update search failed")
    if not out or out == "":
        return [], None
    import json
    try:
        data = json.loads(out)
    except Exception:
        return [], None
    if isinstance(data, dict):
        data = [data]
    return data, None


def search_driver_updates():
    """Searches Windows Update for driver updates. Returns (list, error)."""
    if not IS_WINDOWS:
        return [], "Windows only"
    return _wua_search_drivers()


def install_driver_updates(progress=None):
    """
    Installa gli aggiornamenti driver trovati su Windows Update (admin).
    Ritorna (ok, messaggio_riepilogo).
    """
    script = r"""
$ErrorActionPreference = 'Stop'
$session = New-Object -ComObject Microsoft.Update.Session
$searcher = $session.CreateUpdateSearcher()
$result = $searcher.Search("IsInstalled=0 and Type='Driver'")
if ($result.Updates.Count -eq 0) { Write-Output 'NO_UPDATES'; exit }
$coll = New-Object -ComObject Microsoft.Update.UpdateColl
foreach ($u in $result.Updates) {
    try { if ($u.EulaAccepted -eq $false) { $u.AcceptEula() } } catch {}
    [void]$coll.Add($u)
}
$installer = $session.CreateUpdateInstaller()
$installer.Updates = $coll
$res = $installer.Install()
Write-Output ("RESULT=" + $res.ResultCode)
Write-Output ("HRESULT=" + $res.HResult)
for ($i=0; $i -lt $res.GetUpdateResult($coll.Count).ResultCode; $i++) {}
"""
    if progress:
        progress("Installing drivers (this can take several minutes)...")
    rc, out, err = run_powershell(script, timeout=3600)
    if "NO_UPDATES" in out:
        return True, "No driver updates to install"
    if rc != 0:
        return False, (err or "Installation failed (administrator rights required)")
    if "RESULT=2" in out or "RESULT=3" in out:
        return True, "Driver update completed successfully"
    return False, f"Installation finished with result: {out or err}"


def rescan_devices():
    """Rescans hardware devices (pnputil /scan-devices, admin required)."""
    if not IS_WINDOWS:
        return False, "Windows only"
    rc, out, err = run_cmd(["pnputil", "/scan-devices"], timeout=120)
    if rc == 0:
        return True, "Hardware rescan complete"
    return False, (err or "Rescan failed (try as administrator)")


def open_device_manager():
    rc, _, err = run_cmd(["cmd", "/c", "start", "", "devmgmt.msc"], shell=False, timeout=10)
    return rc == 0, err


def linux_autoinstall_drivers(progress=None):
    """On Linux tries 'ubuntu-drivers autoinstall' when available."""
    if not IS_LINUX:
        return False, "Linux only"
    rc, out, _ = run_cmd(["bash", "-c", "which ubuntu-drivers"])
    if rc != 0:
        return False, "'ubuntu-drivers' is not available on this system"
    if progress:
        progress("Installing recommended drivers (ubuntu-drivers)...")
    rc, out, err = run_cmd(["bash", "-c", "sudo ubuntu-drivers autoinstall"], timeout=1800)
    if rc == 0:
        return True, "Recommended drivers installed (reboot to activate them)"
    return False, (err or "Installation failed")
