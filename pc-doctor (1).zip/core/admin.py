"""PC Doctor Pro - gestione privilegi amministratore (elevazione UAC)."""
import os
import sys

from .utils import IS_WINDOWS


def is_admin():
    """True se il processo ha diritti da amministratore/root."""
    try:
        if IS_WINDOWS:
            import ctypes
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        return os.geteuid() == 0
    except Exception:
        return False


def elevate():
    """
    Riavvia l'app come amministratore (UAC su Windows).
    Ritorna True se la nuova istanza e' stata avviata (e questa deve uscire).
    """
    if not IS_WINDOWS:
        return False
    try:
        import ctypes
        script = os.path.abspath(sys.argv[0])
        params = f'"{script}"'
        args = [a for a in sys.argv[1:] if a != "--elevated"]
        if args:
            params += " " + " ".join(f'"{a}"' for a in args)
        ret = ctypes.windll.shell32.ShellExecuteW(
            None, "runas", sys.executable, params, None, 1
        )
        return ret > 32
    except Exception:
        return False
