"""PC Doctor Pro - utility comuni (comandi, formati, percorsi)."""
import os
import re
import sys
import json
import base64
import shutil
import tempfile
import platform
import subprocess
import datetime

IS_WINDOWS = platform.system() == "Windows"
IS_LINUX = platform.system() == "Linux"
IS_MACOS = platform.system() == "Darwin"

APP_NAME = "PC Doctor Pro"
APP_VERSION = "2.1.0"


def app_dir() -> str:
    """App base folder (where main.py lives)."""
    base = getattr(sys, "_MEIPASS", None)  # compatibilità PyInstaller
    if base:
        return base
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def assets_dir() -> str:
    return os.path.join(app_dir(), "assets")


def cache_dir() -> str:
    d = os.path.join(app_dir(), "assets", "cache")
    try:
        os.makedirs(d, exist_ok=True)
        if os.access(d, os.W_OK):
            return d
    except Exception:
        pass
    d = os.path.join(tempfile.gettempdir(), "PCDoctor_cache")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


# Immagini embedded (versione file singolo; vuota nella versione multi-file)
_ASSETS = {}


def asset_png(name):
    """Extracts an embedded PNG asset to disk (temp cache)."""
    data = _ASSETS.get(name)
    if not data:
        return None
    try:
        d = os.path.join(tempfile.gettempdir(), "PCDoctor_assets")
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, name + ".png")
        if not os.path.exists(p) or os.path.getsize(p) == 0:
            with open(p, "wb") as f:
                f.write(base64.b64decode(data))
        return p
    except Exception:
        return None


def run_cmd(cmd, timeout=30, shell=False):
    """Runs a command and returns (returncode, stdout, stderr). Never raises."""
    try:
        res = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            shell=shell,
            encoding="utf-8",
            errors="ignore",
        )
        return res.returncode, (res.stdout or "").strip(), (res.stderr or "").strip()
    except FileNotFoundError:
        return -1, "", f"command not found: {cmd}"
    except subprocess.TimeoutExpired:
        return -2, "", f"timeout dopo {timeout}s: {cmd}"
    except Exception as e:  # pragma: no cover
        return -1, "", str(e)


def run_powershell(script, timeout=60):
    """Runs a PowerShell script (Windows only) and returns (rc, stdout, stderr)."""
    if not IS_WINDOWS:
        return -1, "", "PowerShell disponibile solo su Windows"
    cmd = [
        "powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
        "-Command", script,
    ]
    return run_cmd(cmd, timeout=timeout)


def ps_json(script, timeout=60):
    """Runs PowerShell and parses ConvertTo-Json output. Returns a list or None."""
    rc, out, err = run_powershell(
        script + " | ConvertTo-Json -Depth 3 -Compress", timeout=timeout
    )
    if rc != 0 or not out:
        return None
    try:
        data = json.loads(out)
    except Exception:
        return None
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        return [data]
    return None


_WMI_DATE_RE = re.compile(r"/Date\((-?\d+)\)/")


def parse_wmi_date(value):
    """Converts WMI/CIM dates ('/Date(ms)/' or ISO) to datetime.date."""
    if not value:
        return None
    if isinstance(value, (int, float)):
        try:
            return datetime.datetime.fromtimestamp(value / 1000.0).date()
        except Exception:
            return None
    s = str(value).strip()
    m = _WMI_DATE_RE.search(s)
    if m:
        try:
            return datetime.datetime.fromtimestamp(int(m.group(1)) / 1000.0).date()
        except Exception:
            return None
    s = s.split(".")[0].replace("T", " ")
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y%m%d%H%M%S", "%Y-%m-%d"):
        try:
            return datetime.datetime.strptime(s[: len(fmt) + 2], fmt).date()
        except Exception:
            continue
    return None


def fmt_bytes(num):
    """Formats bytes into a readable string."""
    if num is None:
        return "N/A"
    try:
        num = float(num)
    except Exception:
        return "N/A"
    for unit in ("B", "KB", "MB", "GB", "TB", "PB"):
        if num < 1024.0 or unit == "PB":
            if unit == "B":
                return f"{int(num)} {unit}"
            return f"{num:.1f} {unit}"
        num /= 1024.0
    return "N/A"


def gb(num_bytes, decimals=1):
    try:
        return round(float(num_bytes) / (1024 ** 3), decimals)
    except Exception:
        return 0.0


def safe_open_folder(path):
    """Opens a folder in the system file manager."""
    try:
        if IS_WINDOWS:
            os.startfile(path)  # type: ignore[attr-defined]
        elif IS_MACOS:
            run_cmd(["open", path])
        else:
            run_cmd(["xdg-open", path])
        return True
    except Exception:
        return False


def which(prog):
    return shutil.which(prog)


def timestamp_name(prefix, ext):
    now = datetime.datetime.now()
    return f"{prefix}_{now.strftime('%Y%m%d_%H%M%S')}.{ext}"


def desktop_dir():
    candidates = [
        os.path.join(os.path.expanduser("~"), "Desktop"),
        os.path.join(os.path.expanduser("~"), "Scrivania"),
        os.path.expanduser("~"),
    ]
    for c in candidates:
        if os.path.isdir(c):
            return c
    return os.path.expanduser("~")


ERROR_LOG = "pcdoctor_error.log"


def log_error(text):
    """Logs errors to a file (never crash silently)."""
    lines = []
    try:
        lines.append(os.path.join(app_dir(), ERROR_LOG))
        with open(lines[0], "a", encoding="utf-8") as f:
            f.write(f"\n[{datetime.datetime.now().strftime('%d/%m/%Y %H:%M:%S')}]\n")
            f.write(text.rstrip() + "\n")
    except Exception:
        pass
    try:
        if not lines:
            lines.append(os.path.join(tempfile.gettempdir(), ERROR_LOG))
        if len(lines) == 1 and not os.path.exists(lines[0]):
            with open(lines[0], "a", encoding="utf-8") as f:
                f.write(f"\n[{datetime.datetime.now()}]\n{text.rstrip()}\n")
    except Exception:
        pass
    return lines[0] if lines else None


def install_crash_guard(tk_root, app_name=APP_NAME):
    """
    Installa il gestore globale degli errori Tkinter:
    mostra una finestra con il dettaglio e NON chiude l'app.
    """
    import traceback
    from tkinter import messagebox

    def handler(etype, evalue, etb):
        msg = "".join(traceback.format_exception(etype, evalue, etb))
        path = log_error(msg)
        try:
            messagebox.showerror(
                app_name + " - recovered error",
                "An error occurred, but the app keeps running.\n\n"
                f"{msg[-1100:]}\n\n"
                f"Dettagli salvati in: {path}",
            )
        except Exception:
            pass

    tk_root.report_callback_exception = handler
    return handler
