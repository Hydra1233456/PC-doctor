"""PC Doctor Pro - HTML / TXT / JSON report generation."""
import os
import json
import base64
import datetime

from .utils import APP_NAME, APP_VERSION, desktop_dir, timestamp_name, fmt_bytes, gb

CSS = """
body { background:#0b0e14; color:#e2e8f0; font-family:'Segoe UI',Arial,sans-serif; margin:0; padding:32px; }
.wrap { max-width:960px; margin:0 auto; }
h1 { color:#34d399; margin-bottom:4px; }
h2 { color:#34d399; border-bottom:1px solid #1f2937; padding-bottom:6px; margin-top:36px; }
.sub { color:#94a3b8; margin-bottom:24px; }
.grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(280px,1fr)); gap:16px; }
.card { background:#111827; border:1px solid #1f2937; border-radius:12px; padding:16px; }
.card h3 { margin:0 0 10px 0; color:#34d399; font-size:15px; }
.row { display:flex; justify-content:space-between; padding:4px 0; border-bottom:1px dashed #1f2937; }
.row:last-child { border-bottom:none; }
.k { color:#94a3b8; } .v { font-weight:600; text-align:right; }
table { width:100%; border-collapse:collapse; font-size:13px; }
th { text-align:left; color:#34d399; border-bottom:1px solid #1f2937; padding:8px 6px; }
td { padding:6px; border-bottom:1px solid #141b29; }
.tag { padding:2px 8px; border-radius:99px; font-size:11px; font-weight:700; }
.ok { background:#064e3b; color:#6ee7b7; }
.old { background:#451a03; color:#fbbf24; }
.gpu-art { max-width:100%; border-radius:12px; border:1px solid #1f2937; }
.footer { color:#64748b; margin-top:40px; font-size:12px; text-align:center; }
"""


def _b64(path):
    try:
        with open(path, "rb") as f:
            return base64.b64encode(f.read()).decode()
    except Exception:
        return None


def _row(k, v):
    return f'<div class="row"><span class="k">{k}</span><span class="v">{v}</span></div>'


def build_report_data(system, gpus, drivers, benchmarks, maintenance):
    return {
        "app": {"name": APP_NAME, "version": APP_VERSION},
        "generated_at": datetime.datetime.now().isoformat(timespec="seconds"),
        "system": system,
        "gpus": gpus,
        "drivers": drivers or [],
        "benchmarks": benchmarks or {},
        "maintenance": maintenance or {},
    }


def export_json(data, path=None):
    path = path or os.path.join(desktop_dir(), timestamp_name("PCDoctor_Report", "json"))
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False, default=str)
    return path


def export_txt(data, path=None):
    path = path or os.path.join(desktop_dir(), timestamp_name("PCDoctor_Report", "txt"))
    lines = []
    s = data.get("system", {})
    os_i = s.get("os", {})
    cpu = s.get("cpu", {})
    ram = s.get("ram", {})
    lines.append("=" * 62)
    lines.append(f"  {APP_NAME} v{APP_VERSION} - HARDWARE REPORT")
    lines.append(f"  Generated on: {data.get('generated_at', '')}")
    lines.append("=" * 62)
    lines.append("")
    lines.append("[ OPERATING SYSTEM ]")
    lines.append(f"  System       : {os_i.get('edition', 'N/A')} ({os_i.get('arch', '')})")
    lines.append(f"  Build        : {os_i.get('build', 'N/A')}")
    lines.append(f"  Hostname     : {os_i.get('hostname', 'N/A')}")
    lines.append(f"  Last boot    : {os_i.get('boot_time', 'N/A')} (uptime {os_i.get('uptime_hours', 'N/A')} h)")
    lines.append("")
    lines.append("[ PROCESSOR ]")
    lines.append(f"  Model        : {cpu.get('name', 'N/A')}")
    lines.append(f"  Cores        : {cpu.get('cores_physical', 'N/A')} physical / {cpu.get('cores_logical', 'N/A')} logical")
    lines.append(f"  Clock        : {cpu.get('current_ghz', 'N/A')} GHz (max {cpu.get('max_ghz', 'N/A')} GHz)")
    lines.append(f"  Usage        : {cpu.get('usage_percent', 'N/A')}%")
    lines.append("")
    lines.append("[ MEMORY (RAM) ]")
    lines.append(f"  Total        : {ram.get('total_gb', 'N/A')} GB")
    lines.append(f"  Used         : {ram.get('used_gb', 'N/A')} GB ({ram.get('percent', 'N/A')}%)")
    if ram.get("speeds"):
        lines.append(f"  Modules      : {ram.get('modules', 'N/A')} - {ram.get('speeds')}")
    lines.append("")
    lines.append("[ GRAPHICS CARDS ]")
    for g in data.get("gpus", []):
        lines.append(f"  - {g.get('name')} [{g.get('vendor')}]")
        lines.append(f"      VRAM: {gb((g.get('vram_mb') or 0) * 1024 * 1024)} GB | Driver: {g.get('driver_version')} "
                     f"({g.get('driver_date') or 'N/A'})")
        if g.get("nvidia_live"):
            nv = g["nvidia_live"]
            lines.append(f"      Live: {nv.get('temp_c')} C | usage {nv.get('util_percent')}% | fan {nv.get('fan_percent')}%")
    lines.append("")
    lines.append("[ DISKS ]")
    for d in s.get("disks", []):
        lines.append(f"  - {d.get('device')} {d.get('total_gb')} GB - used {d.get('percent')}% "
                     f"({d.get('fstype', '')} {d.get('media', '')})")
    board = s.get("board", {})
    bios = s.get("bios", {})
    if board or bios:
        lines.append("")
        lines.append("[ MOTHERBOARD / BIOS ]")
        lines.append(f"  Motherboard  : {board.get('manufacturer', 'N/A')} {board.get('product', '')}")
        lines.append(f"  BIOS         : {bios.get('vendor', 'N/A')} {bios.get('version', '')} ({bios.get('date', 'N/A')})")
    bat = s.get("battery")
    if bat:
        lines.append("")
        lines.append("[ BATTERY ]")
        lines.append(f"  Charge       : {bat.get('percent')}% ({'charging' if bat.get('plugged') else bat.get('time_left')})")
    bench = data.get("benchmarks") or {}
    if bench:
        lines.append("")
        lines.append("[ BENCHMARK ]")
        c = bench.get("cpu", {})
        if c:
            lines.append(f"  CPU          : {c.get('single_score')} (mono) / {c.get('multi_score')} (multi)")
        dk = bench.get("disk", {})
        if dk:
            lines.append(f"  Disk         : read {dk.get('read_mbps')} MB/s - write {dk.get('write_mbps')} MB/s")
        rm = bench.get("ram", {})
        if rm:
            lines.append(f"  RAM          : {rm.get('avg_gbps')} GB/s average")
    drivers = data.get("drivers") or []
    if drivers:
        old = [d for d in drivers if d.get("status") == "Outdated"]
        lines.append("")
        lines.append(f"[ DRIVERS ]  total {len(drivers)} | signed {sum(1 for d in drivers if d.get('signed'))} | outdated {len(old)}")
        for d in old[:20]:
            lines.append(f"  ! {d.get('device')} v{d.get('version')} ({d.get('date') or 'N/A'})")
    lines.append("")
    lines.append(f"Report generated by {APP_NAME} v{APP_VERSION}")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    return path


def export_html(data, path=None):
    path = path or os.path.join(desktop_dir(), timestamp_name("PCDoctor_Report", "html"))
    s = data.get("system", {})
    os_i = s.get("os", {})
    cpu = s.get("cpu", {})
    ram = s.get("ram", {})
    net = s.get("network", {})
    board = s.get("board", {})
    bios = s.get("bios", {})
    bat = s.get("battery")

    gpu_cards = ""
    for g in data.get("gpus", []):
        art = _b64(g.get("art")) if g.get("art") else None
        img = f'<img class="gpu-art" src="data:image/png;base64,{art}" alt="{g.get("name")}"/>' if art else ""
        nv = g.get("nvidia_live") or {}
        live = (
            _row("Temperature", f"{nv.get('temp_c')} &deg;C")
            + _row("Usage", f"{nv.get('util_percent')}%")
            + _row("Fan", f"{nv.get('fan_percent')}%")
            + _row("Power draw", f"{nv.get('power_w')} W")
            if nv else ""
        )
        gpu_cards += (
            '<div class="card"><h3>&#127918; ' + g.get("name", "") + "</h3>" + img
            + _row("Brand", g.get("vendor", "N/A"))
            + _row("VRAM", f"{g.get('vram_mb') or 'N/A'} MB")
            + _row("Driver", f"{g.get('driver_version', 'N/A')} ({g.get('driver_date') or 'N/A'})")
            + _row("Resolution", g.get("resolution") or "N/A")
            + live
            + "</div>"
        )

    disk_rows = "".join(
        f"<tr><td>{d.get('device')}</td><td>{d.get('total_gb')} GB</td>"
        f"<td>{d.get('percent')}%</td><td>{d.get('fstype', '')} {d.get('media', '')}</td>"
        f"<td>{d.get('health', '')}</td></tr>"
        for d in s.get("disks", [])
    )

    drv_rows = ""
    old_drivers = [d for d in (data.get("drivers") or []) if d.get("status") == "Outdated"][:100]
    for d in old_drivers:
        drv_rows += (
            f"<tr><td>{d.get('device')}</td><td>{d.get('manufacturer')}</td>"
            f"<td>{d.get('version')}</td><td>{d.get('date') or 'N/A'}</td>"
            f'<td><span class="tag old">Outdated ({d.get("age_years")} years)</span></td></tr>'
        )

    bench = data.get("benchmarks") or {}
    bench_html = ""
    if bench:
        c, dk, rm = bench.get("cpu", {}), bench.get("disk", {}), bench.get("ram", {})
        bench_html = "<h2>&#9889; Benchmark</h2><div class='card'>"
        if c:
            bench_html += _row("CPU mono-core", c.get("single_score")) + _row("CPU multi-core", c.get("multi_score"))
        if dk:
            bench_html += _row("Disk read", f"{dk.get('read_mbps')} MB/s") + _row("Disk write", f"{dk.get('write_mbps')} MB/s")
        if rm:
            bench_html += _row("RAM average", f"{rm.get('avg_gbps')} GB/s")
        bench_html += "</div>"

    maint = data.get("maintenance") or {}
    maint_html = ""
    if maint.get("steps"):
        maint_html = "<h2>&#129529; Maintenance</h2><div class='card'>"
        for name, msg in maint["steps"]:
            maint_html += _row(name, msg)
        maint_html += "</div>"

    bat_html = ""
    if bat:
        bat_html = (
            "<div class='card'><h3>&#128267; Battery</h3>"
            + _row("Charge", f"{bat.get('percent')}%")
            + _row("Status", "Charging" if bat.get("plugged") else bat.get("time_left", "N/A"))
            + "</div>"
        )

    temp_rows = "".join(_row(k, f"{v} &deg;C") for k, v in (s.get("temperatures") or {}).items())
    temps_html = f"<div class='card'><h3>&#127782; Temperatures</h3>{temp_rows or _row('Sensors', 'N/A')}</div>" if temp_rows or True else ""

    audio = s.get("audio") or []
    audio_html = ""
    if audio:
        audio_html = "<div class='card'><h3>&#128266; Audio</h3>" + "".join(_row("Device", a) for a in audio[:5]) + "</div>"

    html = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>{APP_NAME} - Report</title><style>{CSS}</style></head>
<body><div class="wrap">
<h1>&#129302; {APP_NAME}</h1>
<div class="sub">Full hardware report - generated on {data.get('generated_at', '')} &middot; version {APP_VERSION}</div>

<h2>&#128421; System</h2>
<div class="grid">
<div class="card"><h3>Operating system</h3>
{_row('System', os_i.get('edition', 'N/A'))}
{_row('Architecture', os_i.get('arch', 'N/A'))}
{_row('Build', os_i.get('build', 'N/A'))}
{_row('Hostname', os_i.get('hostname', 'N/A'))}
{_row('Last boot', os_i.get('boot_time', 'N/A'))}
{_row('Uptime', f"{os_i.get('uptime_hours', 'N/A')} h")}</div>
<div class="card"><h3>Processor</h3>
{_row('Model', cpu.get('name', 'N/A'))}
{_row('Physical cores', cpu.get('cores_physical', 'N/A'))}
{_row('Logical cores', cpu.get('cores_logical', 'N/A'))}
{_row('Clock', f"{cpu.get('current_ghz', 'N/A')} GHz" )}
{_row('Usage', f"{cpu.get('usage_percent', 'N/A')}%")}</div>
<div class="card"><h3>Memory (RAM)</h3>
{_row('Total', f"{ram.get('total_gb', 'N/A')} GB")}
{_row('Used', f"{ram.get('used_gb', 'N/A')} GB ({ram.get('percent', 'N/A')}%)")}
{_row('Available', f"{ram.get('available_gb', 'N/A')} GB")}
{_row('Modules', ram.get('modules', 'N/A'))}
{_row('Speed', ram.get('speeds', 'N/A'))}</div>
<div class="card"><h3>Motherboard / BIOS</h3>
{_row('Manufacturer', board.get('manufacturer', 'N/A'))}
{_row('Model', board.get('product', 'N/A'))}
{_row('BIOS', bios.get('vendor', 'N/A'))}
{_row('BIOS version', bios.get('version', 'N/A'))}
{_row('BIOS date', bios.get('date', 'N/A'))}</div>
<div class="card"><h3>Network</h3>
{_row('Public IP', net.get('public_ip') or 'N/A')}
{_row('Total sent', f"{net.get('total_sent_mb', 'N/A')} MB")}
{_row('Total received', f"{net.get('total_recv_mb', 'N/A')} MB")}</div>
{bat_html}{temps_html}{audio_html}
</div>

<h2>&#127918; Graphics cards</h2>
<div class="grid">{gpu_cards or '<div class="card">No GPU detected</div>'}</div>

<h2>&#128190; Disks</h2>
<div class="card"><table>
<tr><th>Disk</th><th>Capacity</th><th>Used</th><th>Type</th><th>Health</th></tr>
{disk_rows or '<tr><td colspan="5">No disks detected</td></tr>'}
</table></div>

{bench_html}{maint_html}

<h2>&#129520; Outdated drivers (last 100)</h2>
<div class="card"><table>
<tr><th>Device</th><th>Manufacturer</th><th>Version</th><th>Date</th><th>Status</th></tr>
{drv_rows or '<tr><td colspan="5">No outdated drivers detected (or scan not run)</td></tr>'}
</table></div>

<div class="footer">Report generated by {APP_NAME} v{APP_VERSION} &middot; Python + Tkinter</div>
</div></body></html>"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    return path


def export_all(data, formats=("html", "txt", "json"), out_dir=None):
    """Exports the report in the requested formats. Returns the list of paths."""
    out_dir = out_dir or desktop_dir()
    paths = []
    if "json" in formats:
        paths.append(export_json(data, os.path.join(out_dir, timestamp_name("PCDoctor_Report", "json"))))
    if "txt" in formats:
        paths.append(export_txt(data, os.path.join(out_dir, timestamp_name("PCDoctor_Report", "txt"))))
    if "html" in formats:
        paths.append(export_html(data, os.path.join(out_dir, timestamp_name("PCDoctor_Report", "html"))))
    return paths
