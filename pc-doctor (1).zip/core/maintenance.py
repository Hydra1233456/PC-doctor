"""PC Doctor Pro - maintenance: cleanup, DNS, startup programs, disk health."""
import os
import shutil
import tempfile

from .utils import IS_WINDOWS, IS_LINUX, IS_MACOS, run_cmd, run_powershell, ps_json, fmt_bytes
from . import drivers as _drivers

TEMP_DIRS_WINDOWS = [
    os.path.join(os.environ.get("TEMP", ""), "") if os.environ.get("TEMP") else None,
    r"C:\Windows\Temp",
]
TEMP_DIRS_LINUX = ["/tmp", os.path.expanduser("~/.cache")]
TEMP_DIRS_MACOS = [tempfile.gettempdir()]


def _temp_dirs():
    if IS_WINDOWS:
        dirs = [d for d in TEMP_DIRS_WINDOWS if d and os.path.isdir(d)]
    elif IS_LINUX:
        dirs = [d for d in TEMP_DIRS_LINUX if os.path.isdir(d)]
    else:
        dirs = [d for d in TEMP_DIRS_MACOS if os.path.isdir(d)]
    return dirs or [tempfile.gettempdir()]


def temp_usage():
    """Calculates how much space temp files use."""
    total = 0
    count = 0
    for d in _temp_dirs():
        for root, _dirs, files in os.walk(d, onerror=lambda e: None):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(root, f))
                    count += 1
                except OSError:
                    pass
    return {"bytes": total, "files": count, "dirs": _temp_dirs()}


def clean_temp(progress=None):
    """Cleans temp files. Returns a summary."""
    freed = 0
    removed = 0
    errors = 0
    dirs = _temp_dirs()
    if progress:
        progress(f"Cleaning {len(dirs)} temporary folders...")
    for d in dirs:
        for root, _sub, files in os.walk(d, onerror=lambda e: None):
            for f in files:
                path = os.path.join(root, f)
                try:
                    size = os.path.getsize(path)
                except OSError:
                    continue
                # Salta i file dell'app stessa
                if "PCDoctor" in f or "pc-doctor" in path:
                    continue
                try:
                    os.remove(path)
                    freed += size
                    removed += 1
                except OSError:
                    errors += 1
            for _s in _sub:
                sub_path = os.path.join(root, _s)
                if not os.listdir(sub_path):
                    try:
                        os.rmdir(sub_path)
                    except OSError:
                        pass
    return {
        "ok": True,
        "bytes_freed": freed,
        "bytes_freed_label": fmt_bytes(freed),
        "files_removed": removed,
        "errors": errors,
        "dirs": dirs,
    }


def flush_dns():
    """Flushes the system DNS cache."""
    if IS_WINDOWS:
        rc, _, err = run_cmd(["ipconfig", "/flushdns"], timeout=20)
    elif IS_LINUX:
        rc, _, _ = run_cmd(["resolvectl", "flush-caches"], timeout=15)
        if rc != 0:
            rc, _, _ = run_cmd(["systemd-resolve", "--flush-caches"], timeout=15)
        if rc != 0:
            return True, "DNS cache not present or already empty"
    elif IS_MACOS:
        rc, _, err = run_cmd(["dscacheutil", "-flushcache"], timeout=15)
        run_cmd(["bash", "-c", "sudo killall -HUP mDNSResponder"], timeout=15)
    else:
        return False, "Unsupported platform"
    if rc == 0:
        return True, "DNS cache flushed"
    return False, (err or "Command failed")


# ---------------- Startup programs (Windows) ----------------

if IS_WINDOWS:
    import winreg

    RUN_PATH = r"Software\Microsoft\Windows\CurrentVersion\Run"
    BACKUP_PATH = r"Software\Microsoft\Windows\CurrentVersion\Run_PCDoctorBackup"

    def _iter_run_values(hive, path, view64=True):
        items = []
        access = winreg.KEY_READ | (winreg.KEY_WOW64_64KEY if view64 else winreg.KEY_WOW64_32KEY)
        try:
            key = winreg.OpenKey(hive, path, 0, access)
        except OSError:
            return items
        try:
            i = 0
            while True:
                try:
                    name, value, _type = winreg.EnumValue(key, i)
                    items.append({"name": name, "command": value})
                    i += 1
                except OSError:
                    break
        finally:
            winreg.CloseKey(key)
        return items

    def list_startup():
        """Lists startup programs (registry + Startup folder)."""
        items = []
        sources = [
            ("HKCU", winreg.HKEY_CURRENT_USER, RUN_PATH, True),
            ("HKCU (32bit)", winreg.HKEY_CURRENT_USER, RUN_PATH, False),
            ("HKLM", winreg.HKEY_LOCAL_MACHINE, RUN_PATH, True),
            ("HKLM (32bit)", winreg.HKEY_LOCAL_MACHINE, RUN_PATH, False),
        ]
        for label, hive, path, v64 in sources:
            for it in _iter_run_values(hive, path, v64):
                it["location"] = label
                it["hive"] = hive
                it["path"] = path
                it["view64"] = v64
                items.append(it)
        backup_names = set()
        for _l, hive, _p, v64 in sources:
            for it in _iter_run_values(hive, BACKUP_PATH, v64):
                backup_names.add((hive, it["name"], v64))
        for it in items:
            it["enabled"] = (it["hive"], it["name"], it["view64"]) not in backup_names
        # Cartella Startup
        startup_dirs = [
            os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs\Startup"),
            os.path.join(os.environ.get("PROGRAMDATA", ""), r"Microsoft\Windows\Start Menu\Programs\Startup"),
        ]
        for sd in startup_dirs:
            if os.path.isdir(sd):
                for f in os.listdir(sd):
                    items.append({
                        "name": f, "command": os.path.join(sd, f),
                        "location": "Startup folder", "enabled": True,
                        "hive": None, "path": sd, "view64": True, "is_file": True,
                    })
        return items

    def set_startup_enabled(item, enable):
        """Disables/re-enables a startup entry (moving it to a backup registry key)."""
        hive, name, v64 = item.get("hive"), item.get("name"), item.get("view64", True)
        if hive is None:
            return False, "Startup folder entries must be managed manually"
        try:
            access = winreg.KEY_ALL_ACCESS | (winreg.KEY_WOW64_64KEY if v64 else winreg.KEY_WOW64_32KEY)
            if enable:
                bk = winreg.OpenKey(hive, BACKUP_PATH, 0, access)
                value, _t = winreg.QueryValueEx(bk, name)
                winreg.CloseKey(bk)
                dst = winreg.OpenKey(hive, item["path"], 0, access)
                winreg.SetValueEx(dst, name, 0, winreg.REG_SZ, value)
                winreg.CloseKey(dst)
                bk = winreg.OpenKey(hive, BACKUP_PATH, 0, access)
                winreg.DeleteValue(bk, name)
                winreg.CloseKey(bk)
            else:
                src = winreg.OpenKey(hive, item["path"], 0, access)
                value, _t = winreg.QueryValueEx(src, name)
                winreg.CloseKey(src)
                bk = winreg.CreateKey(hive, BACKUP_PATH)
                winreg.SetValueEx(bk, name, 0, winreg.REG_SZ, value)
                winreg.CloseKey(bk)
                src = winreg.OpenKey(hive, item["path"], 0, access)
                winreg.DeleteValue(src, name)
                winreg.CloseKey(src)
            return True, "Done"
        except OSError as e:
            return False, str(e)

else:

    def list_startup():
        items = []
        if IS_LINUX:
            for d in [os.path.expanduser("~/.config/autostart"), "/etc/xdg/autostart"]:
                if os.path.isdir(d):
                    for f in os.listdir(d):
                        if f.endswith(".desktop"):
                            items.append({
                                "name": f, "command": os.path.join(d, f),
                                "location": "autostart", "enabled": True,
                            })
        return items

    def set_startup_enabled(item, enable):
        return False, "Not supported on this system"


def disk_health():
    """Physical disk health status (Windows: Get-PhysicalDisk)."""
    if IS_WINDOWS:
        data = ps_json(
            "Get-PhysicalDisk | Select-Object FriendlyName, MediaType, BusType, "
            "HealthStatus, OperationalStatus, @{n='SizeGB';e={[math]::Round($_.Size/1GB,1)}}"
        )
        if not data:
            return [], "No information available"
        out = []
        for d in data:
            out.append({
                "name": d.get("FriendlyName") or "Disk",
                "media": d.get("MediaType") or "N/A",
                "bus": d.get("BusType") or "N/A",
                "health": d.get("HealthStatus") or "N/A",
                "status": d.get("OperationalStatus") or "N/A",
                "size_gb": d.get("SizeGB"),
            })
        return out, None
    if IS_LINUX:
        rc, out, _ = run_cmd(["bash", "-c", "which smartctl"])
        if rc == 0:
            rc, out, _ = run_cmd(["bash", "-c", "lsblk -d -n -o NAME,SIZE,MODEL"], timeout=15)
            if rc == 0:
                disks = []
                for line in out.splitlines():
                    parts = line.split(None, 2)
                    if len(parts) >= 2:
                        disks.append({
                            "name": parts[0], "media": "N/A", "bus": "N/A",
                            "health": "See SMART", "status": "OK",
                            "size_gb": parts[1],
                        })
                return disks, None
        return [], "smartctl (smartmontools) is not installed"
    return [], "Not available on this system"


def battery_report():
    """Generates the Windows battery report (powercfg)."""
    if not IS_WINDOWS:
        return False, "Windows only", None
    out_path = os.path.join(tempfile.gettempdir(), "PCDoctor_battery_report.html")
    rc, _, err = run_cmd(["powercfg", "/batteryreport", "/output", out_path], timeout=60)
    if rc == 0 and os.path.exists(out_path):
        return True, "Battery report generated", out_path
    return False, (err or "Battery report failed"), None


def windows_update_scan():
    """Starts a Windows Update check (USOClient)."""
    if not IS_WINDOWS:
        return False, "Windows only"
    rc, _, err = run_cmd(["UsoClient", "StartScan"], timeout=30)
    if rc != 0:
        rc, _, err = run_cmd(["cmd", "/c", "start", "", "ms-settings:windowsupdate"], timeout=10)
        return True, "Opened Settings > Windows Update"
    return True, "Windows Update scan started"


def auto_maintenance(progress=None):
    """Full automatic maintenance: cleanup + DNS + rescan + update scan."""
    steps = []
    if progress:
        progress("1/4 - Cleaning temp files...")
    try:
        c = clean_temp()
        steps.append(("Temp file cleanup", f"{c['bytes_freed_label']} freed ({c['files_removed']} files)"))
    except Exception as e:
        steps.append(("Temp file cleanup", f"Error: {e}"))
    if progress:
        progress("2/4 - Flushing DNS cache...")
    ok, msg = flush_dns()
    steps.append(("DNS cache", msg if ok else f"Skipped: {msg}"))
    if IS_WINDOWS:
        if progress:
            progress("3/4 - Rescanning hardware...")
        ok, msg = _drivers.rescan_devices()
        steps.append(("Hardware rescan", msg if ok else f"Admin required: {msg}"))
        if progress:
            progress("4/4 - Checking Windows Update...")
        ok, msg = windows_update_scan()
        steps.append(("Windows Update", msg if ok else f"Skipped: {msg}"))
    else:
        steps.append(("Hardware rescan", "Windows only"))
        steps.append(("Windows Update", "Windows only"))
    return {"ok": True, "steps": steps}
