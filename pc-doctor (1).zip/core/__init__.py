"""
PC Doctor Pro - moduli core
Analisi hardware, driver, manutenzione, benchmark e report.
"""
