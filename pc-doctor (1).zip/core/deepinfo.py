"""PC Doctor Pro - deep hardware specs (CPU-Z / GPU-Z level detail).

Every collector is best-effort: each step is wrapped in try/except, the
module never raises and imports cleanly on Linux/macOS too (Windows-only
APIs are guarded at call time).
"""
import re
import datetime

from .utils import IS_WINDOWS, IS_LINUX, run_cmd, ps_json, parse_wmi_date, fmt_bytes

_NA = "N/A"

_CPU_VENDOR_MAP = {"GenuineIntel": "Intel", "AuthenticAMD": "AMD"}

# SMBIOS memory type codes (Win32_PhysicalMemory.SMBIOSMemoryType)
_MEM_TYPES = {20: "DDR", 21: "DDR2", 24: "DDR3", 26: "DDR4", 34: "DDR5"}

_PCI_VENDORS = {
    "0x10de": "NVIDIA",
    "0x1002": "AMD",
    "0x8086": "Intel",
}


def _txt(value):
    """Safe trimmed string, or N/A."""
    try:
        s = str(value).strip()
    except Exception:
        return _NA
    return s or _NA


def _num(value):
    """Safe int (accepts '24576 MiB' style strings) or None."""
    try:
        m = re.search(r"-?\d+(?:\.\d+)?", str(value))
        if not m:
            return None
        return int(float(m.group(0)))
    except Exception:
        return None


def _name_match(a, b):
    """Case-insensitive substring match used to pair nvidia-smi/WMI names."""
    try:
        a, b = (a or "").lower().strip(), (b or "").lower().strip()
        return bool(a) and bool(b) and (a in b or b in a)
    except Exception:
        return False


def vram_label(mb):
    if not mb:
        return _NA
    try:
        mb = int(mb)
    except Exception:
        return _NA
    return f"{round(mb / 1024)} GB" if mb >= 1024 else f"{mb} MB"


# =====================================================================
# CPU
# =====================================================================
def get_cpu_deep():
    """CPU-Z style CPU details. Never raises; missing values stay N/A."""
    info = {
        "name": _NA, "vendor": _NA, "architecture": _NA, "bits": _NA,
        "cores_physical": _NA, "cores_logical": _NA,
        "base_clock": _NA, "max_clock": _NA, "advertised_clock": _NA,
        "socket": _NA, "tdp": _NA,
        "l1_data": _NA, "l1_instruction": _NA, "l2_cache": _NA, "l3_cache": _NA,
        "flags": [],
        "sse42": False, "avx": False, "avx2": False, "avx512": False,
        "aes_ni": False, "fma3": False,
        "virtualization": _NA,
        "source": "unavailable",
    }

    # ---- py-cpuinfo (optional dependency, guarded import) ----
    py = {}
    try:
        from cpuinfo import get_cpu_info as _py_cpu_info
        py = _py_cpu_info() or {}
    except Exception:
        py = {}

    flags = []
    try:
        flags = [str(f).lower() for f in (py.get("flags") or [])]
    except Exception:
        flags = []
    info["flags"] = flags
    info["sse42"] = "sse4_2" in flags
    info["avx"] = "avx" in flags
    info["avx2"] = "avx2" in flags
    info["avx512"] = any(f.startswith("avx512") for f in flags)
    info["aes_ni"] = "aes" in flags
    info["fma3"] = "fma3" in flags
    if "vmx" in flags:
        info["virtualization"] = "Yes (Intel VT-x)"
    elif "svm" in flags:
        info["virtualization"] = "Yes (AMD-V)"
    elif flags:
        info["virtualization"] = "No"

    try:
        brand = py.get("brand_raw") or py.get("brand")
        if brand:
            info["name"] = _txt(re.sub(r"\s+", " ", brand))
            info["source"] = "py-cpuinfo"
    except Exception:
        pass
    try:
        if py.get("vendor_id"):
            info["vendor"] = _CPU_VENDOR_MAP.get(
                py.get("vendor_id"), _txt(py.get("vendor_id")))
    except Exception:
        pass
    try:
        if py.get("arch"):
            info["architecture"] = _txt(py.get("arch"))
    except Exception:
        pass
    try:
        if py.get("bits"):
            info["bits"] = f"{_num(py.get('bits'))}-bit"
    except Exception:
        pass
    try:
        adv = py.get("hz_advertised_friendly")
        if adv:
            info["advertised_clock"] = _txt(adv)
            if info["max_clock"] == _NA:
                info["max_clock"] = info["advertised_clock"]
    except Exception:
        pass
    for key, src in (("l1_data", "l1_data_cache_size"),
                     ("l1_instruction", "l1_instruction_cache_size"),
                     ("l2_cache", "l2_cache_size"),
                     ("l3_cache", "l3_cache_size")):
        try:
            val = py.get(src)
            if val:
                info[key] = fmt_bytes(val)
        except Exception:
            pass
    try:
        if py.get("count"):
            info["cores_logical"] = _num(py.get("count"))
    except Exception:
        pass

    # ---- WMI merge (Windows; ps_json is a safe no-op elsewhere) ----
    if IS_WINDOWS:
        try:
            data = ps_json(
                "Get-CimInstance Win32_Processor | Select-Object Name, "
                "Manufacturer, MaxClockSpeed, NumberOfCores, "
                "NumberOfLogicalProcessors, L2CacheSize, L3CacheSize, "
                "SocketDesignation"
            )
            if data:
                d = data[0]
                if d.get("Name") and info["name"] == _NA:
                    info["name"] = _txt(d.get("Name"))
                    info["source"] = "WMI"
                if d.get("Manufacturer"):
                    info["vendor"] = _txt(d.get("Manufacturer"))
                mhz = _num(d.get("MaxClockSpeed"))
                if mhz:
                    info["base_clock"] = f"{mhz / 1000:.2f} GHz"
                cores = _num(d.get("NumberOfCores"))
                if cores:
                    info["cores_physical"] = cores
                logical = _num(d.get("NumberOfLogicalProcessors"))
                if logical:
                    info["cores_logical"] = logical
                l2 = _num(d.get("L2CacheSize"))
                if l2 and info["l2_cache"] == _NA:
                    info["l2_cache"] = (f"{round(l2 / 1024, 1)} MB"
                                        if l2 >= 1024 else f"{l2} KB")
                l3 = _num(d.get("L3CacheSize"))
                if l3 and info["l3_cache"] == _NA:
                    info["l3_cache"] = (f"{round(l3 / 1024, 1)} MB"
                                        if l3 >= 1024 else f"{l3} KB")
                if d.get("SocketDesignation"):
                    info["socket"] = _txt(d.get("SocketDesignation"))
        except Exception:
            pass

    # ---- Linux extras (lscpu + /proc/cpuinfo) ----
    if IS_LINUX:
        try:
            rc, out, _err = run_cmd(["lscpu"], timeout=10)
            if rc == 0 and out:
                fields = {}
                for line in out.splitlines():
                    if ":" in line:
                        k, v = line.split(":", 1)
                        fields[k.strip().lower()] = v.strip()
                if info["name"] == _NA and fields.get("model name"):
                    info["name"] = fields["model name"]
                    info["source"] = "lscpu"
                if info["architecture"] == _NA and fields.get("architecture"):
                    info["architecture"] = fields["architecture"]
                max_mhz = _num(fields.get("cpu max mhz"))
                if max_mhz:
                    info["max_clock"] = f"{max_mhz / 1000:.2f} GHz"
                sockets = _num(fields.get("socket(s)")) or 1
                per_socket = _num(fields.get("core(s) per socket"))
                if per_socket and info["cores_physical"] == _NA:
                    info["cores_physical"] = per_socket * sockets
                if info["cores_logical"] == _NA and fields.get("cpu(s)"):
                    info["cores_logical"] = _num(fields.get("cpu(s)"))
                for key, lkey in (("l1_data", "l1d cache"),
                                  ("l1_instruction", "l1i cache"),
                                  ("l2_cache", "l2 cache"),
                                  ("l3_cache", "l3 cache")):
                    if info[key] == _NA and fields.get(lkey):
                        info[key] = fields[lkey].split("(")[0].strip()
        except Exception:
            pass

    return info


# =====================================================================
# GPU
# =====================================================================
def _nvidia_xml_gpus():
    """Full live detail from `nvidia-smi -q -x` (XML). Never raises."""
    gpus = []
    rc, out, _err = run_cmd(["nvidia-smi", "-q", "-x"], timeout=15)
    if rc != 0 or not out:
        return gpus
    try:
        import xml.etree.ElementTree as ET
        root = ET.fromstring(out)
    except Exception:
        return gpus

    for g in root.findall("gpu"):
        try:
            def val(path):
                el = g.find(path)
                if el is None or el.text is None:
                    return None
                t = el.text.strip()
                return t or None

            def num(path):
                v = val(path)
                return _num(v) if v else None

            fan = num("fan_speed/current")
            if fan is None:
                fan = num("fans/fan/speed")
            gpus.append({
                "name": val("product_name") or "NVIDIA GPU",
                "driver_version": val("driver_version"),
                "cuda_version": val("cuda_version"),
                "vbios": val("vbios_version"),
                "pstate": val("performance_state"),
                "clock_graphics_mhz": num("clocks/graphics_clock"),
                "clock_mem_mhz": num("clocks/mem_clock"),
                "clock_graphics_default_mhz": num(
                    "clocks_applications/graphics_clock"),
                "clock_mem_default_mhz": num("clocks_applications/memory_clock"),
                "clock_graphics_max_mhz": num("max_clocks/graphics_clock"),
                "clock_mem_max_mhz": num("max_clocks/mem_clock"),
                "power_draw_w": num("power_readings/power_draw"),
                "power_limit_w": num("power_readings/power_limit"),
                "power_default_limit_w": num(
                    "power_readings/default_power_limit"),
                "power_min_limit_w": num("power_readings/min_power_limit"),
                "power_max_limit_w": num("power_readings/max_power_limit"),
                "temp_c": num("temperature/gpu_temp"),
                "temp_max_c": num("temperature/gpu_temp_max"),
                "temp_slowdown_c": num("temperature/gpu_slowdown_temp"),
                "temp_shutdown_c": num("temperature/gpu_shutdown_temp"),
                "pcie_gen_current": num("pci/pcie_link_gen_current"),
                "pcie_width_current": num("pci/pcie_link_width_current"),
                "pcie_gen_max": num("pci/pcie_link_gen_max"),
                "pcie_width_max": num("pci/pcie_link_width_max"),
                "fan_percent": fan,
                "util_gpu_percent": num("utilization/gpu_util"),
                "util_mem_percent": num("utilization/memory_util"),
                "vram_used_mb": num("fb_memory_usage/used"),
                "vram_total_mb": num("fb_memory_usage/total"),
            })
        except Exception:
            continue
    return gpus


def _vendor_from_pnp(pnp_id):
    """(vendor, vendor_id) from a PNPDeviceID like PCI\\VEN_10DE&DEV_2684..."""
    try:
        m = re.search(r"ven_([0-9a-f]{4})", pnp_id or "", re.I)
        if m:
            vid = "0x" + m.group(1).lower()
            return _PCI_VENDORS.get(vid, "Generic"), vid
    except Exception:
        pass
    return None, None


def _vendor_from_name(name):
    try:
        low = (name or "").lower()
        if "nvidia" in low or "geforce" in low or "quadro" in low:
            return "NVIDIA"
        if "radeon" in low or "amd" in low or "ati " in low:
            return "AMD"
        if "intel" in low:
            return "Intel"
    except Exception:
        pass
    return "Generic"


def _vram_registry_bytes():
    """Precise VRAM in bytes, keyed by PNP id (HardwareInformation.qwMemorySize).

    Reuses core.gpu._vram_from_registry when importable, otherwise falls
    back to a minimal winreg re-implementation.
    """
    try:
        from .gpu import _vram_from_registry  # noqa: SLF001
        return _vram_from_registry() or {}
    except Exception:
        pass
    out = {}
    if not IS_WINDOWS:
        return out
    try:
        import winreg
        base = (r"SYSTEM\CurrentControlSet\Control\Class"
                r"\{4d36e968-e325-11ce-bfc1-08002be10318}")
        for idx in range(10):
            try:
                key = winreg.OpenKey(
                    winreg.HKEY_LOCAL_MACHINE, f"{base}\\{idx:04d}")
            except OSError:
                break
            try:
                try:
                    pnp, _ = winreg.QueryValueEx(key, "MatchingDeviceId")
                except OSError:
                    pnp = ""
                size = None
                for name in ("HardwareInformation.qwMemorySize",
                             "HardwareInformation.MemorySize"):
                    try:
                        size, _ = winreg.QueryValueEx(key, name)
                        if isinstance(size, bytes) and len(size) >= 8:
                            size = int.from_bytes(size[:8], "little")
                        if isinstance(size, int) and size > 0:
                            break
                        size = None
                    except OSError:
                        continue
            finally:
                winreg.CloseKey(key)
            if size and pnp:
                pnp_up = str(pnp).upper()
                out[pnp_up] = size
                m = re.search(r"VEN_([0-9A-F]{4})&DEV_([0-9A-F]{4})", pnp_up)
                if m:
                    out[f"VEN_{m.group(1)}&DEV_{m.group(2)}"] = size
    except Exception:
        pass
    return out


def get_gpu_deep():
    """GPU-Z style details for every GPU. Never raises; returns [] on failure."""
    gpus = []
    try:
        nv = _nvidia_xml_gpus()
    except Exception:
        nv = []
    try:
        registry = _vram_registry_bytes()
    except Exception:
        registry = {}

    if IS_WINDOWS:
        try:
            data = ps_json(
                "Get-CimInstance Win32_VideoController | Select-Object Name, "
                "AdapterCompatibility, PNPDeviceID, DriverVersion, DriverDate, "
                "VideoProcessor, VideoModeDescription, CurrentRefreshRate, "
                "CurrentHorizontalResolution, CurrentVerticalResolution, "
                "AdapterRAM"
            )
            for d in (data or []):
                try:
                    name = _txt(d.get("Name"))
                    if name == _NA:
                        name = "Unknown graphics card"
                    pnp = _txt(d.get("PNPDeviceID"))
                    if pnp == _NA:
                        pnp = ""
                    vendor, vid = _vendor_from_pnp(pnp)
                    if vendor is None:
                        vendor, vid = _vendor_from_name(name), _NA
                    res = None
                    w, h = _num(d.get("CurrentHorizontalResolution")), \
                        _num(d.get("CurrentVerticalResolution"))
                    if w and h:
                        res = f"{w} x {h}"
                    else:
                        mode = d.get("VideoModeDescription") or ""
                        if " x " in mode:
                            seg = mode.split(" x ")
                            res = f"{seg[0]} x {seg[1]}"
                    date = parse_wmi_date(d.get("DriverDate"))
                    gpus.append({
                        "name": name,
                        "vendor": vendor,
                        "vendor_id": vid,
                        "vram_mb": None,
                        "vram_source": None,
                        "driver_version": _txt(d.get("DriverVersion")),
                        "driver_date": date.isoformat() if date else None,
                        "resolution": res,
                        "refresh_rate": _num(d.get("CurrentRefreshRate")),
                        "video_processor": (_txt(d.get("VideoProcessor"))
                                            if d.get("VideoProcessor")
                                            else None),
                        "pnp_id": pnp,
                    })
                except Exception:
                    continue
        except Exception:
            pass
    else:
        # Cross-platform fallback: reuse the existing GPU collector.
        try:
            from .gpu import get_gpus as _get_gpus
            for g in (_get_gpus() or []):
                try:
                    gpus.append({
                        "name": g.get("name") or "Unknown graphics card",
                        "vendor": g.get("vendor") or "Generic",
                        "vendor_id": _NA,
                        "vram_mb": g.get("vram_mb"),
                        "vram_source": "driver" if g.get("vram_mb") else None,
                        "driver_version": g.get("driver_version") or _NA,
                        "driver_date": g.get("driver_date"),
                        "resolution": g.get("resolution"),
                        "refresh_rate": g.get("refresh_rate"),
                        "video_processor": None,
                        "pnp_id": g.get("pnp_id") or "",
                    })
                except Exception:
                    continue
        except Exception:
            gpus = []

    for g in gpus:
        # Live NVIDIA data (matched by name, same policy as core.gpu)
        try:
            for n in nv:
                if _name_match(n["name"], g["name"]):
                    g["nvidia"] = n
                    if n.get("vram_total_mb"):
                        g["vram_mb"] = n["vram_total_mb"]
                        g["vram_source"] = "nvidia-smi"
                    if n.get("driver_version") and (
                            not g.get("driver_version")
                            or g["driver_version"] == _NA):
                        g["driver_version"] = n["driver_version"]
                    break
        except Exception:
            pass

        # VRAM from the registry (exact, avoids the 4 GB AdapterRAM cap)
        try:
            if not g.get("vram_mb"):
                pnp_up = (g.get("pnp_id") or "").upper()
                size = registry.get(pnp_up)
                if not size:
                    m = re.search(
                        r"VEN_([0-9A-F]{4})&DEV_([0-9A-F]{4})", pnp_up)
                    if m:
                        size = registry.get(
                            f"VEN_{m.group(1)}&DEV_{m.group(2)}")
                if size:
                    g["vram_mb"] = round(size / (1024 * 1024))
                    g["vram_source"] = "registry"
        except Exception:
            pass

        # Reference spec table
        try:
            spec, key = match_gpu_spec(g.get("name"))
            g["spec"] = spec
            g["spec_matched"] = key
        except Exception:
            g["spec"] = None
            g["spec_matched"] = None

    # NVIDIA cards missed by WMI/lspci (rare) are appended from nvidia-smi
    try:
        for n in nv:
            if not any(_name_match(n["name"], g["name"]) for g in gpus):
                spec, key = match_gpu_spec(n["name"])
                gpus.append({
                    "name": n["name"],
                    "vendor": "NVIDIA",
                    "vendor_id": "0x10de",
                    "vram_mb": n.get("vram_total_mb"),
                    "vram_source": "nvidia-smi" if n.get("vram_total_mb") else None,
                    "driver_version": n.get("driver_version") or _NA,
                    "driver_date": None,
                    "resolution": None,
                    "refresh_rate": None,
                    "video_processor": None,
                    "pnp_id": "",
                    "spec": spec,
                    "spec_matched": key,
                    "nvidia": n,
                })
    except Exception:
        pass

    return gpus


# =====================================================================
# Reference GPU database (founders-edition figures, most specific first)
# Fields: architecture, shader_cores, mem_type, mem_bus, boost_mhz, tdp_w
# =====================================================================
GPU_SPECS_DB = [
    {"key": "RTX 5090", "architecture": "Blackwell", "shader_cores": 21760,
     "mem_type": "GDDR7", "mem_bus": "512-bit", "boost_mhz": 2407, "tdp_w": 575},
    {"key": "RTX 5080", "architecture": "Blackwell", "shader_cores": 10752,
     "mem_type": "GDDR7", "mem_bus": "256-bit", "boost_mhz": 2617, "tdp_w": 360},
    {"key": "RTX 5070 Ti", "architecture": "Blackwell", "shader_cores": 8960,
     "mem_type": "GDDR7", "mem_bus": "256-bit", "boost_mhz": 2452, "tdp_w": 300},
    {"key": "RTX 5070", "architecture": "Blackwell", "shader_cores": 6144,
     "mem_type": "GDDR6", "mem_bus": "192-bit", "boost_mhz": 2512, "tdp_w": 250},
    {"key": "RTX 4090", "architecture": "Ada Lovelace", "shader_cores": 16384,
     "mem_type": "GDDR6X", "mem_bus": "384-bit", "boost_mhz": 2520, "tdp_w": 450},
    {"key": "RTX 4080 SUPER", "architecture": "Ada Lovelace", "shader_cores": 10240,
     "mem_type": "GDDR6X", "mem_bus": "256-bit", "boost_mhz": 2550, "tdp_w": 320},
    {"key": "RTX 4070 Ti SUPER", "architecture": "Ada Lovelace", "shader_cores": 8448,
     "mem_type": "GDDR6X", "mem_bus": "256-bit", "boost_mhz": 2610, "tdp_w": 285},
    {"key": "RTX 4070 Ti", "architecture": "Ada Lovelace", "shader_cores": 7680,
     "mem_type": "GDDR6X", "mem_bus": "192-bit", "boost_mhz": 2610, "tdp_w": 285},
    {"key": "RTX 4070", "architecture": "Ada Lovelace", "shader_cores": 5888,
     "mem_type": "GDDR6X", "mem_bus": "192-bit", "boost_mhz": 2475, "tdp_w": 200},
    {"key": "RTX 4060", "architecture": "Ada Lovelace", "shader_cores": 3072,
     "mem_type": "GDDR6", "mem_bus": "128-bit", "boost_mhz": 2460, "tdp_w": 115},
    {"key": "RTX 3090 Ti", "architecture": "Ampere", "shader_cores": 10752,
     "mem_type": "GDDR6X", "mem_bus": "384-bit", "boost_mhz": 1860, "tdp_w": 450},
    {"key": "RTX 3090", "architecture": "Ampere", "shader_cores": 10496,
     "mem_type": "GDDR6X", "mem_bus": "384-bit", "boost_mhz": 1695, "tdp_w": 350},
    {"key": "RTX 3080", "architecture": "Ampere", "shader_cores": 8704,
     "mem_type": "GDDR6X", "mem_bus": "320-bit", "boost_mhz": 1710, "tdp_w": 320},
    {"key": "RTX 3070", "architecture": "Ampere", "shader_cores": 5888,
     "mem_type": "GDDR6", "mem_bus": "256-bit", "boost_mhz": 1725, "tdp_w": 220},
    {"key": "RTX 3060", "architecture": "Ampere", "shader_cores": 3584,
     "mem_type": "GDDR6", "mem_bus": "192-bit", "boost_mhz": 1777, "tdp_w": 170},
    {"key": "RTX 2060", "architecture": "Turing", "shader_cores": 1920,
     "mem_type": "GDDR6", "mem_bus": "192-bit", "boost_mhz": 1680, "tdp_w": 160},
    {"key": "GTX 1660 Ti", "architecture": "Turing", "shader_cores": 1536,
     "mem_type": "GDDR6", "mem_bus": "192-bit", "boost_mhz": 1770, "tdp_w": 120},
    {"key": "GTX 1080 Ti", "architecture": "Pascal", "shader_cores": 3584,
     "mem_type": "GDDR5X", "mem_bus": "352-bit", "boost_mhz": 1582, "tdp_w": 250},
    {"key": "GTX 1060", "architecture": "Pascal", "shader_cores": 1280,
     "mem_type": "GDDR5", "mem_bus": "192-bit", "boost_mhz": 1708, "tdp_w": 120},
    {"key": "RX 9070 XT", "architecture": "RDNA 4", "shader_cores": 4096,
     "mem_type": "GDDR6", "mem_bus": "256-bit", "boost_mhz": 2970, "tdp_w": 304},
    {"key": "RX 7900 XTX", "architecture": "RDNA 3", "shader_cores": 6144,
     "mem_type": "GDDR6", "mem_bus": "384-bit", "boost_mhz": 2500, "tdp_w": 355},
    {"key": "RX 7800 XT", "architecture": "RDNA 3", "shader_cores": 3840,
     "mem_type": "GDDR6", "mem_bus": "256-bit", "boost_mhz": 2430, "tdp_w": 263},
    {"key": "RX 6800 XT", "architecture": "RDNA 2", "shader_cores": 4608,
     "mem_type": "GDDR6", "mem_bus": "256-bit", "boost_mhz": 2250, "tdp_w": 300},
    {"key": "RX 6700 XT", "architecture": "RDNA 2", "shader_cores": 2560,
     "mem_type": "GDDR6", "mem_bus": "192-bit", "boost_mhz": 2581, "tdp_w": 230},
    {"key": "RX 6600", "architecture": "RDNA 2", "shader_cores": 1792,
     "mem_type": "GDDR6", "mem_bus": "128-bit", "boost_mhz": 2491, "tdp_w": 132},
    {"key": "Arc B580", "architecture": "Xe HPG (Battlemage)", "shader_cores": 2560,
     "mem_type": "GDDR6", "mem_bus": "192-bit", "boost_mhz": 2670, "tdp_w": 190},
    {"key": "Arc A770", "architecture": "Xe HPG (Alchemist)", "shader_cores": 4096,
     "mem_type": "GDDR6", "mem_bus": "256-bit", "boost_mhz": 2100, "tdp_w": 225},
    {"key": "Arc A750", "architecture": "Xe HPG (Alchemist)", "shader_cores": 3584,
     "mem_type": "GDDR6", "mem_bus": "256-bit", "boost_mhz": 2050, "tdp_w": 225},
]


def _normalize_gpu_name(name):
    """Lowercase + strip (R)/(TM)/(C)/®/™ markers so WMI-style names
    like 'Intel(R) Arc(TM) A770 Graphics' match the reference DB."""
    try:
        n = str(name or "").lower()
        n = re.sub(r"\((?:r|tm|c)\)", " ", n)
        n = re.sub(r"[®™©\u00ae\u2122\u00a9]", " ", n)
        return re.sub(r"\s+", " ", n).strip()
    except Exception:
        return ""


def match_gpu_spec(name):
    """Finds a GPU in the reference DB (case-insensitive substring).

    Returns (spec_dict, matched_key) or (None, None).
    """
    n = _normalize_gpu_name(name)
    if not n:
        return None, None
    try:
        for spec in GPU_SPECS_DB:
            if _normalize_gpu_name(spec.get("key", "")) in n:
                return spec, spec.get("key")
    except Exception:
        return None, None
    return None, None


# =====================================================================
# RAM
# =====================================================================
def get_ram_deep():
    """Per-stick memory details (SPD style) + slot layout. Never raises."""
    info = {
        "total_gb": None, "sticks": 0, "slots": None, "free_slots": None,
        "modules": [], "speeds": [], "mismatch": None, "source": "unavailable",
    }
    if IS_WINDOWS:
        data = []
        try:
            data = ps_json(
                "Get-CimInstance Win32_PhysicalMemory | Select-Object "
                "DeviceLocator, BankLabel, Capacity, Speed, "
                "ConfiguredClockSpeed, Manufacturer, PartNumber, "
                "SMBIOSMemoryType"
            ) or []
        except Exception:
            data = []
        arrays = []
        try:
            arrays = ps_json(
                "Get-CimInstance Win32_PhysicalMemoryArray | Select-Object "
                "MemoryDevices"
            ) or []
        except Exception:
            arrays = []
        slots = 0
        for a in arrays:
            slots += _num(a.get("MemoryDevices")) or 0

        modules, speeds = [], []
        total_bytes = 0
        for d in data:
            try:
                cap = int(d.get("Capacity") or 0)
            except Exception:
                cap = 0
            total_bytes += cap
            configured = _num(d.get("ConfiguredClockSpeed"))
            speed = _num(d.get("Speed"))
            effective = configured or speed
            if effective:
                speeds.append(effective)
            try:
                part = (d.get("PartNumber") or "").strip()
            except Exception:
                part = ""
            modules.append({
                "slot": _txt(d.get("DeviceLocator"))
                if d.get("DeviceLocator")
                else (_txt(d.get("BankLabel"))
                      if d.get("BankLabel") else "?"),
                "size_gb": round(cap / (1024 ** 3), 1) if cap else None,
                "speed_mhz": speed,
                "configured_mhz": configured,
                "type": _MEM_TYPES.get(d.get("SMBIOSMemoryType")) or _NA,
                "manufacturer": _txt(d.get("Manufacturer")),
                "part_number": part or _NA,
            })
        info["sticks"] = len(modules)
        info["modules"] = modules
        if total_bytes:
            info["total_gb"] = round(total_bytes / (1024 ** 3), 1)
        if slots:
            info["slots"] = slots
            info["free_slots"] = max(slots - len(modules), 0)
        info["speeds"] = sorted(set(speeds))
        if len(info["speeds"]) > 1:
            info["mismatch"] = (
                "Modules run at different speeds: "
                + ", ".join(f"{s} MHz" for s in info["speeds"])
                + ". The system runs all sticks at the lowest common rate."
            )
        info["source"] = "WMI" if data else "unavailable"
    elif IS_LINUX:
        try:
            with open("/proc/meminfo", "r", encoding="utf-8",
                      errors="ignore") as f:
                for line in f:
                    if line.startswith("MemTotal:"):
                        kb = _num(line.split(":", 1)[1])
                        if kb:
                            info["total_gb"] = round(kb / (1024 ** 2), 1)
                        break
            info["source"] = "/proc/meminfo"
        except Exception:
            pass
    return info


# =====================================================================
# Summary + plain-text report
# =====================================================================
def get_deep_summary():
    """Aggregates CPU/GPU/RAM deep specs; each section is guarded."""
    summary = {
        "generated": _NA,
        "cpu": {"source": "unavailable"},
        "gpus": [],
        "ram": {"source": "unavailable"},
    }
    try:
        summary["generated"] = datetime.datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S")
    except Exception:
        pass
    try:
        summary["cpu"] = get_cpu_deep()
    except Exception:
        pass
    try:
        summary["gpus"] = get_gpu_deep()
    except Exception:
        summary["gpus"] = []
    try:
        summary["ram"] = get_ram_deep()
    except Exception:
        pass
    return summary


def build_report_text(summary):
    """Plain-text deep specs report (clipboard / report friendly)."""
    lines = ["PC Doctor Pro - Tech Specs report",
             f"Generated: {_txt(summary.get('generated'))}",
             "-" * 60]
    try:
        cpu = summary.get("cpu") or {}
        lines += ["", "PROCESSOR",
                  f"  Name:            {cpu.get('name', _NA)}",
                  f"  Vendor:          {cpu.get('vendor', _NA)}",
                  f"  Cores/Threads:   {cpu.get('cores_physical', _NA)} / "
                  f"{cpu.get('cores_logical', _NA)}",
                  f"  Base clock:      {cpu.get('base_clock', _NA)}",
                  f"  Max clock:       {cpu.get('max_clock', _NA)}",
                  f"  Socket:          {cpu.get('socket', _NA)}",
                  f"  L1 (data/inst):  {cpu.get('l1_data', _NA)} / "
                  f"{cpu.get('l1_instruction', _NA)}",
                  f"  L2 cache:        {cpu.get('l2_cache', _NA)}",
                  f"  L3 cache:        {cpu.get('l3_cache', _NA)}",
                  f"  TDP:             {cpu.get('tdp', _NA)}",
                  f"  Architecture:    {cpu.get('architecture', _NA)} "
                  f"{cpu.get('bits', _NA)}",
                  f"  Virtualization:  {cpu.get('virtualization', _NA)}",
                  "  Instruction sets: "
                  + ", ".join(k for k, ok in (
                      ("SSE4.2", cpu.get("sse42")),
                      ("AVX", cpu.get("avx")),
                      ("AVX2", cpu.get("avx2")),
                      ("AVX-512", cpu.get("avx512")),
                      ("AES-NI", cpu.get("aes_ni")),
                      ("FMA3", cpu.get("fma3"))) if ok) or "none detected"]
    except Exception:
        lines += ["", "PROCESSOR: unavailable"]

    try:
        gpus = summary.get("gpus") or []
        for i, g in enumerate(gpus, 1):
            nv = g.get("nvidia") or {}
            spec = g.get("spec") or {}
            lines += ["", f"GPU {i}",
                      f"  Name:            {g.get('name', _NA)}",
                      f"  Vendor:          {g.get('vendor', _NA)} "
                      f"({g.get('vendor_id', _NA)})",
                      f"  VRAM:            {vram_label(g.get('vram_mb'))}"
                      + (f" ({g.get('vram_source')})" if g.get("vram_source") else ""),
                      f"  Driver:          {g.get('driver_version', _NA)}"
                      + (f" ({g.get('driver_date')})" if g.get("driver_date") else ""),
                      f"  Resolution:      {g.get('resolution') or _NA}"
                      + (f" @ {g.get('refresh_rate')} Hz"
                         if g.get("refresh_rate") else "")]
            if spec:
                lines += [
                    f"  Architecture:    {spec.get('architecture', _NA)}",
                    f"  Shader cores:    {spec.get('shader_cores', '-')}",
                    f"  Memory:          {spec.get('mem_type', '-')} "
                    f"{spec.get('mem_bus', '-')}",
                    f"  Boost clock:     {spec.get('boost_mhz', '-')} MHz",
                    f"  Board power:     {spec.get('tdp_w', '-')} W"]
            else:
                lines += ["  Spec table:      no entry in the local database"]
            if nv:
                lines += [
                    f"  GPU clock:       {nv.get('clock_graphics_mhz', _NA)} MHz "
                    f"(max {nv.get('clock_graphics_max_mhz', _NA)} MHz)",
                    f"  Memory clock:    {nv.get('clock_mem_mhz', _NA)} MHz "
                    f"(max {nv.get('clock_mem_max_mhz', _NA)} MHz)",
                    f"  Temperature:     {nv.get('temp_c', _NA)} C "
                    f"(slowdown {nv.get('temp_slowdown_c', _NA)}, "
                    f"shutdown {nv.get('temp_shutdown_c', _NA)})",
                    f"  Power:           {nv.get('power_draw_w', _NA)} W "
                    f"(limits {nv.get('power_min_limit_w', _NA)}/"
                    f"{nv.get('power_default_limit_w', _NA)}/"
                    f"{nv.get('power_max_limit_w', _NA)} W)",
                    f"  PCIe:            Gen {nv.get('pcie_gen_current', _NA)} "
                    f"x{nv.get('pcie_width_current', _NA)} "
                    f"(max Gen {nv.get('pcie_gen_max', _NA)} "
                    f"x{nv.get('pcie_width_max', _NA)})",
                    f"  Fan:             {nv.get('fan_percent', _NA)} %",
                    f"  Utilization:     {nv.get('util_gpu_percent', _NA)} %",
                    f"  CUDA version:    {nv.get('cuda_version', _NA)}"]
    except Exception:
        lines += ["", "GPUS: unavailable"]

    try:
        ram = summary.get("ram") or {}
        lines += ["", "MEMORY",
                  f"  Total installed: {ram.get('total_gb', _NA)} GB",
                  f"  Modules:         {ram.get('sticks', 0) or _NA}"]
        if ram.get("slots"):
            lines.append(f"  Slots:           {ram.get('slots')} "
                         f"(free {ram.get('free_slots', _NA)})")
        for m in (ram.get("modules") or []):
            speed = m.get("configured_mhz") or m.get("speed_mhz")
            lines.append(
                f"  Stick [{m.get('slot', '?')}]:        "
                f"{m.get('size_gb', _NA)} GB {m.get('type', _NA)} @ "
                f"{speed if speed else _NA} MHz "
                f"({m.get('manufacturer', _NA)} {m.get('part_number', _NA)})")
        if ram.get("mismatch"):
            lines.append(f"  WARNING: {ram.get('mismatch')}")
    except Exception:
        lines += ["", "MEMORY: unavailable"]

    return "\n".join(lines)
