# PC Doctor Pro

**PC Doctor Pro** is a free **Python** desktop app for Windows (works partially on Linux/macOS) that analyses your PC **CPU-Z + GPU-Z style** — and adds what they don't have: safe automatic driver updates, one-click maintenance, benchmarks, an **Overclock & Undervolt** center and a **self-repair tool**.

## Quick start (Windows)

1. Extract the whole folder (keep all files together)
2. Double-click **`run_windows.bat`** — it checks Python, installs dependencies and starts the app
3. If **anything** goes wrong → double-click **`FIX_PC_DOCTOR.bat`**

Manual start: `python main.py` (needs `pip install psutil Pillow`)

## The one-click repair tool

**`pc_doctor_fixer.py`** fixes everything by itself:

```
python pc_doctor_fixer.py              # fix everything + menu
python pc_doctor_fixer.py --auto       # fix everything, no questions
python pc_doctor_fixer.py --check-only # diagnose only
python pc_doctor_fixer.py --repl-fix   # fix the Python >>> terminal crash
```

It: checks the environment → installs/repairs **psutil + Pillow** → cleans corrupted caches → **verifies every app file** → **analyses `pcdoctor_error.log`** and explains the last crash → applies quick fixes (Python REPL crash guard, missing launchers, desktop shortcut) → self-tests all modules → relaunches the app.

## What's inside (9 pages)

| Page | Description |
|---|---|
| 🏠 **Dashboard** | Live hardware overview, CPU/RAM usage, per-core bars |
| 🎮 **Graphics Card** | Brand **artwork** (NVIDIA/AMD/Intel), VRAM, driver + date, live temperature/usage/clocks (NVIDIA), official driver buttons |
| 📊 **Tech Specs** | **CPU-Z/GPU-Z level detail**: architecture, shader cores, memory type/bus/boost (spec table of 28+ GPUs), caches L1/L2/L3, instruction sets (AVX/AVX2/AVX-512), socket, PCIe link, RAM sticks SPD (slot, DDR type, speed, part number), free slots |
| 🎚 **Overclock & UV** | **Automatic one-click profiles** (ECO/under volt, Balanced, Performance) + **manual mode** (power limit / core / memory via nvidia-smi) + 20s stability monitor with live charts, one-click reset, restore point |
| 🧰 **Drivers** | Full scan, outdated-driver highlights, automatic updates via **Windows Update** with **restore point** |
| 🧹 **Maintenance** | Temp cleanup, DNS flush, startup manager, disk health, battery report |
| ⚡ **Benchmark** | CPU single/multi-core, RAM, disk + class tier |
| 📄 **Report** | Export everything to **HTML** (with images), TXT, JSON |
| ℹ️ **Info & System** | System details + **Repair & fix** buttons (runs the repair tool from inside the app) |

## Terminal mode

```bash
python main.py --cli       # full report
python main.py --json      # JSON report
python main.py --gpu       # GPU only
python main.py --drivers   # driver scan (Windows)
python main.py --bench     # benchmarks
```

## Safety

- Nothing changes without **explicit confirmation**
- A **restore point** is created before driver updates
- Driver installs come only from **official Windows Update**
- Tuning changes revert with **one click** and reset on reboot
- If an error happens the app does **not** close: it shows the problem and logs to `pcdoctor_error.log`

## Compatibility

- **Python 3.10+** (Windows 10/11 for full features)
- Linux/macOS: hardware analysis, Tech Specs, benchmarks, reports (drivers/tuning read-only or disabled)
- No telemetry, no ads, no accounts. Works offline.

## Folder contents

```
main.py               entry point (GUI + CLI)
pc_doctor_fixer.py    one-click repair tool
FIX_PC_DOCTOR.bat     double-click repair (Windows)
run_windows.bat       dependency check + launch (Windows)
core/                 analysis, drivers, tuning, deepinfo, benchmarks...
gui/                  dark-themed interface (Tkinter)
assets/               GPU artwork + icon
requirements.txt      psutil, Pillow, py-cpuinfo
LICENSE               MIT license
```

## License

Released under the **MIT License** (see the `LICENSE` file): you can use, copy, modify and share the app freely — just keep the copyright notice.

Third-party libraries, all MIT-compatible: psutil (BSD-3-Clause), Pillow (HPND + MIT-CMU), py-cpuinfo (MIT).
