"""PC Doctor Pro - entry point.

Usage:
    python main.py              -> starts the graphical interface
    python main.py --cli        -> full report in the terminal
    python main.py --json       -> full report in JSON
    python main.py --gpu        -> GPU info only
    python main.py --drivers    -> scan drivers (Windows only)
    python main.py --bench      -> run benchmarks

License: MIT - see the LICENSE file.
"""
import sys
import argparse


def _cli(args):
    import json as _json
    from core import system_info, gpu as gpu_mod
    from core import drivers as drv_mod, benchmark as bench_mod
    from core.utils import fmt_bytes, gb

    def header(title):
        print(f"\n{'=' * 62}\n  {title}\n{'=' * 62}")

    if args.bench:
        header("BENCHMARK")
        res = bench_mod.run_all_benchmarks(progress=lambda m: print("  *", m))
        print(_json.dumps(res, indent=2, ensure_ascii=False))
        return

    if args.gpu:
        gpus = gpu_mod.get_gpus()
        for g in gpus:
            print(f"\nGPU: {g['name']}")
            for k in ("vendor", "vram_mb", "driver_version", "driver_date",
                      "resolution", "status"):
                print(f"  {k:14}: {g.get(k)}")
            if g.get("nvidia_live"):
                print(f"  live          : {g['nvidia_live']}")
            print(f"  art           : {g.get('art')}")
        return

    if args.drivers:
        drivers, err = drv_mod.scan_drivers(progress=lambda m: print("  *", m))
        if err:
            print("ERROR:", err)
            return
        stats = drv_mod.driver_stats(drivers)
        print(f"\nTotal drivers: {stats['total']} | signed: {stats['signed']} "
              f"| outdated: {stats['old']}")
        for d in drivers[:30]:
            print(f"  [{d['status']:8}] {d['device'][:50]:50} v{d['version'][:20]:20} {d['date'] or ''}")
        return

    header("PC DOCTOR PRO - SYSTEM REPORT")
    if args.json:
        s = system_info.get_full_system_info()
        gpus = gpu_mod.get_gpus()
        print(_json.dumps({"system": s, "gpus": gpus}, indent=2,
                          ensure_ascii=False, default=str))
        return

    s = system_info.get_full_system_info()
    os_i, cpu, ram = s["os"], s["cpu"], s["ram"]
    print(f"\n  System       : {os_i['edition']} ({os_i['arch']})  build {os_i['build']}")
    print(f"  Hostname     : {os_i['hostname']}   uptime: {os_i['uptime_hours']} h")
    print(f"  CPU          : {cpu['name']}")
    print(f"  Cores        : {cpu['cores_physical']} physical / {cpu['cores_logical']} logical "
          f"- {cpu.get('current_ghz', '?')} GHz")
    print(f"  RAM          : {ram['total_gb']} GB total, {ram['used_gb']} GB used ({ram['percent']}%)")
    if ram.get("speeds"):
        print(f"  RAM modules  : {ram.get('modules')} x {ram.get('speeds')}")
    for d in s["disks"]:
        print(f"  Disk         : {d['device']} {d['total_gb']} GB - used {d['percent']}%")
    board = s.get("board", {})
    bios = s.get("bios", {})
    if board:
        print(f"  Motherboard  : {board.get('manufacturer', 'N/A')} {board.get('product', '')}")
    if bios:
        print(f"  BIOS         : {bios.get('vendor', 'N/A')} {bios.get('version', '')}")
    net = s["network"]
    print(f"  Network      : public IP {net.get('public_ip') or 'N/A'}, "
          f"sent {net['total_sent_mb']} MB, received {net['total_recv_mb']} MB")
    bat = s.get("battery")
    if bat:
        print(f"  Battery      : {bat['percent']}% "
              + ("(charging)" if bat["plugged"] else f"({bat['time_left']})"))
    if s.get("audio"):
        print(f"  Audio        : {', '.join(s['audio'][:3])}")

    header("GRAPHICS CARDS")
    gpus = gpu_mod.get_gpus()
    if not gpus:
        print("  No GPU detected")
    for g in gpus:
        print(f"\n  {g['name']}  [{g['vendor']}]")
        print(f"    VRAM        : {gpu_mod.vram_label(g.get('vram_mb'))}")
        print(f"    Driver      : {g.get('driver_version')}  "
              f"({g.get('driver_date') or 'N/A'})")
        if g.get("driver_age_years") is not None:
            print(f"    Driver age  : {g['driver_age_years']} years")
        if g.get("nvidia_live"):
            nv = g["nvidia_live"]
            print(f"    Live        : {nv.get('temp_c')} C | usage {nv.get('util_percent')}% "
                  f"| fan {nv.get('fan_percent')}%")
        if g.get("driver_page"):
            print(f"    Driver page : {g['driver_page']}")
        print(f"    Artwork     : {g.get('art') or 'N/A'}")


def main():
    parser = argparse.ArgumentParser(
        prog="PC Doctor Pro",
        description="Hardware analysis, drivers, maintenance and benchmarks for your PC.",
    )
    parser.add_argument("--cli", action="store_true", help="terminal report (no GUI)")
    parser.add_argument("--json", action="store_true", help="JSON output (with --cli)")
    parser.add_argument("--gpu", action="store_true", help="GPU info only (with --cli)")
    parser.add_argument("--drivers", action="store_true", help="driver scan (with --cli)")
    parser.add_argument("--bench", action="store_true", help="benchmarks (with --cli)")
    args = parser.parse_args()

    if args.cli or args.json or args.gpu or args.drivers or args.bench:
        _cli(args)
        return

    # GUI
    try:
        import psutil  # noqa: F401
    except ImportError:
        print("The psutil library is missing. Install dependencies with:")
        print("    pip install -r requirements.txt")
        sys.exit(1)
    try:
        from gui.app import run_gui
        run_gui()
    except Exception as e:
        print(f"Error starting the GUI: {e}")
        print("Tip: on headless Linux servers you need a graphical environment (X11/Wayland).")
        sys.exit(1)


if __name__ == "__main__":
    # Required for multiprocessing on Windows (multi-core benchmark)
    main()
