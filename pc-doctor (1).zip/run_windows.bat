@echo off
title PC Doctor Pro
cd /d "%~dp0"

echo ============================================
echo   PC Doctor Pro - starting...
echo ============================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python not found! Install Python from python.org
    echo         and check "Add Python to PATH" during setup.
    pause
    exit /b 1
)

echo Checking dependencies (psutil, Pillow)...
python -c "import psutil" >nul 2>nul
if errorlevel 1 (
    echo Installing missing dependencies...
    python -m pip install psutil Pillow
)

echo Starting PC Doctor Pro...
python main.py
if errorlevel 1 pause
